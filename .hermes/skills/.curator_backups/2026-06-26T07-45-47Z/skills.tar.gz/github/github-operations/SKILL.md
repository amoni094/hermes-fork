---
name: github-operations
description: Broad GitHub workflow skill for authentication, repository bootstrap, PR lifecycle, code review, follow-up automation, and issue triage.
version: 1.0.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  tags: [github, gh, git, auth, clone, fork, pull-request, review, issues, workflow]
---

# GitHub Operations

Use this when the task involves GitHub as a workflow surface rather than a single narrow action: logging in, cloning or forking repositories, creating or reviewing pull requests, triaging issues, or automating follow-up around a PR.

## Core idea
Treat GitHub work as one lifecycle:
1. authenticate
2. locate or bootstrap the repository
3. make a scoped branch change
4. open or review the PR
5. monitor CI/review state
6. follow up until the branch is stable

## When to use
- User needs GitHub auth or `gh` setup.
- User wants to clone, fork, or manage remotes.
- User wants to open, review, or follow up on a PR.
- User wants issue triage or repository hygiene around GitHub objects.
- User wants a single playbook that spans repo setup, review, and delivery.

## Workflow

### 1) Authenticate first
- Prefer the narrowest working auth path for the environment.
- Verify `gh auth status` or the equivalent git credential path before assuming access.
- If a credential helper or token is missing, solve that before blaming GitHub APIs.

### 2) Bootstrap or inspect the repository
- Clone/fetch the repo.
- Confirm remotes, default branch, and working branch state.
- Read repo instructions before modifying anything.
- If the user wants a fork-based workflow, keep upstream and origin separate and explicit.
- For a brand-new local project that needs a GitHub home, check whether the target repo already exists before creating it.
- If the user wants the repository private, create it with an explicit private flag and verify privacy after push instead of assuming the default.

#### New private repository bootstrap
Use this when a local workspace already exists and the user wants it published as a new private GitHub repo.
1. Verify auth first with `gh auth status`.
2. Check whether the target repo already exists, e.g. `gh repo view OWNER/NAME`.
3. Inspect local git state before publishing so you know whether you are creating a fresh root commit or pushing an existing history.
4. Create and push in one step with `gh repo create OWNER/NAME --private --source=. --remote=origin --push`.
5. Verify the result with `gh repo view OWNER/NAME --json name,visibility,isPrivate,url,defaultBranchRef`.
6. Re-check `git status --short --branch` and `git remote -v` so the final report names the tracked branch and remote, not just the GitHub URL.

### 3) PR lifecycle
- Create a branch with a scoped change.
- Commit only intended files.
- Open the PR or locate the existing PR.
- Re-read review comments after every push.
- Separate branch regressions from baseline repository failures.

### 4) Code review and follow-up
- Review the diff and surrounding context, not just the comment thread.
- Validate review comments against the live branch state.
- Keep generated or unrelated files out of follow-up commits.
- If the user wants automation, use a follow-up loop that checks for new comments, reruns CI, and reports only the new actionable items.

### 5) Issues
- Use issues for triage, scope, and lightweight tracking.
- Keep issue work separate from branch patching unless the issue explicitly drives a PR.
- When an issue references a PR, verify whether the live branch or the historical PR snapshot is the source of truth.

## Practical rules
- Always confirm the live ref/branch state before concluding a PR is fixed.
- Do not assume historical PR metadata still matches the current branch tip.
- Do not widen scope to unrelated repo failures.
- Do not push without verifying the branch contains only the intended changes.
- Do not confuse auth problems with repository or CI failures.

## Repository automation and CI hardening
When the task involves GitHub-hosted repository automation rather than application code, inspect the workflows themselves before proposing changes.

Preferred low-friction hardening moves:
- set top-level workflow permissions to read-only by default
- grant write permission only on the exact job that must push or mutate repo state
- pin third-party actions to immutable commit SHAs rather than floating tags
- add `concurrency` to workflows that auto-commit or update generated files
- add explicit branch/event guards for write-capable jobs
- if CI contains inline validation logic that duplicates a repo script, prefer calling the repo-local validator/tool directly so local and CI behavior cannot drift
- when frontmatter or workflow metadata is YAML, prefer `yaml.safe_load` over regex parsing if a parser is available

Common pitfall:
- Do not maintain two validators with different rules (for example, a local script and a separate inline Actions regex validator). This causes false positives, contributor confusion, and security/quality blind spots.

See also: `references/github-actions-hardening.md`, `references/private-repo-bootstrap.md`

## Verification
- Auth works.
- Repo state is known.
- Branch/PR identity is verified.
- Review or issue state is re-queried after changes.
- For CI/workflow hardening, read back the changed workflow files and run the canonical local validator/tool.
- Final report names the exact PR, branch, or issue state that was observed.

## Preflight before commit/push
When a coding task ends with a commit or push, do a quick repo preflight before mutating git state:
1. inspect `git status --short` so you know the exact tracked/untracked scope
2. inspect `git diff --stat` and, when needed, targeted `git diff -- <files>` so only intended files are included
3. run the repo quality gates that actually apply (`npm run build`, `npm run lint`, tests, project validators)
4. if it is a local web app, prefer a lightweight runtime probe as well: start the dev/preview server, then verify localhost serves HTML with a shell HTTP request if browser tooling is flaky
5. for browser-compatibility or legacy-bundle changes in Vite/SPA repos, inspect the served HTML as part of preflight and confirm the expected loader path is present (for example both the modern module script and the `nomodule` / legacy entry tags when `@vitejs/plugin-legacy` is enabled)
6. if a refresh or generation step touched multiple derived files, inspect the generated diff and stage the intended generated artifacts explicitly so the commit stays scoped to the requested change
7. if you ran package-manager commands during verification (`npm install`, `pnpm install`, etc.), inspect lockfile and manifest diffs before staging. Revert incidental lockfile-only churn when it does not represent an intended dependency/runtime change.
8. for scraped/generated ranking surfaces, sample the regenerated output for source quality before commit. Prefer direct per-profile artifacts over generic party/channel fallback if the broader fallback pollutes a person-level summary with irrelevant content.
9. only then `git add` the intended paths, commit, and push

Pitfall:
- Do not rely on a successful build alone when the task explicitly asked for runtime verification. For local dashboards or SPAs, a served-HTML check is a cheap extra guard even if richer browser automation is unavailable.

## Notes
More specific GitHub workflows that fit under this umbrella include auth setup, repository management, PR workflow, code review, PR follow-up automation, and GitHub Actions hardening for repo-maintenance workflows.
