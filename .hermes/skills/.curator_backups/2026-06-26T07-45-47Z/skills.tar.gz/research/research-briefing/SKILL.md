---
name: research-briefing
description: Broad current-events and trend briefing skill covering news synthesis, blindspot scanning, and live source coverage setup.
version: 1.0.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  tags: [research, briefing, news, trends, live-search, blindspots, source-coverage]
---

# Research Briefing

Use this when the user wants a current, synthesized briefing rather than a raw search dump: latest developments, topic monitoring, trend scanning, or a "what am I missing?" pass across multiple domains.

## Core idea
A good briefing has three layers:
1. enough live source coverage to trust the run
2. narrow category query packs instead of one huge search
3. synthesis that highlights the dominant signal, not the top ranked noise

## When to use
- User wants the latest developments across one or more topics.
- User wants a live trend or current-events briefing.
- User wants blindspots or adjacent signals.
- User wants to improve source coverage for a research workflow.

## Workflow

### 1) Verify coverage before synthesis
- Identify what sources are actually available.
- Separate "the tool exists" from "the tool has enough live source coverage."
- If a source is missing, use a compact fallback instead of pretending it is covered.

### 2) Split into narrow query packs
- Build separate probes per topic/category.
- Keep categories distinct: politics, macro/finance, geopolitics, tech/AI, culture, autos, GitHub, etc.
- Avoid an omnibus query unless you explicitly want broad noise.

### 3) Add blindspot scanning
- Surface adjacent items that are popular or important but not centered in the main ranking.
- Treat blindspots as secondary signals, not the main conclusion.
- Use a second pass when the first pass is too narrow or too noisy.

### 4) Synthesize by topic
- State the main development first.
- Then give 2–4 supporting bullets.
- Call out weak or noisy buckets instead of padding them.
- Keep the output concise and readable.

### 5) Include setup improvements when needed
- If the workflow is source-limited, improve the search/extract/auth stack before blaming the briefing logic.
- Distinguish a general live-news workflow from source-specific signals such as GitHub trends or account-derived personalization.
- When the user wants recurring briefings, preserve their established output shape rather than inventing a new one each time.

## Practical rules
- Prefer the local Firecrawl instance for page retrieval and extraction when the task involves crawling, scraping, or turning URLs into clean text.
- Use search to discover candidate URLs, then use Firecrawl to fetch/extract them; do not rely on search snippets alone when full-page extraction is feasible.
- For one page or a small URL set, prefer Firecrawl scrape/extract-style calls; for site-wide or multi-page work, prefer Firecrawl crawl/map-style calls.
- Verify the local Firecrawl service first with `GET http://127.0.0.1:3002/`; do not rely on `/v1/health` because this self-host image does not expose that route.
- Keep fallback behavior honest: if Firecrawl is down or a target blocks extraction, fall back to `web_search`/`web_extract` and label the limitation plainly.
- Do not claim comprehensive coverage when the source mix is thin.
- Do not pad a briefing with irrelevant recent items.
- Do not merge blindspots into the main ranked story.
- Do not confuse search success with good coverage.
- Do not forget to label caveats plainly when a source path is missing.

## Verification
- Live sources were checked.
- Query packs were narrowed by topic.
- Briefing output is synthesized, not dumped raw.
- Blindspots or weak buckets are labeled honestly.

## Evaluating external source stacks
Use this when the user asks whether a new retrieval/integration layer would improve news, recommendations, or research coverage.

- Compare the proposed stack against the current local stack before recommending installation.
- Separate access-layer gains from reasoning gains: better source reach can improve inputs without improving synthesis quality by itself.
- Distinguish discussion-layer value from structured-metadata value. Social/community sources can improve sentiment, buzz, and recommendations even when they do not improve canonical metadata lookup.
- Prefer a low-risk trial first: isolated venv or other reversible install path, plus dry-run/status commands before any real setup.
- Check for hidden side effects in verification commands. If an upstream `doctor` or `setup` command writes skills/config automatically, prefer the least side-effecting variant during evaluation.
- Report current gaps in the existing stack separately from the proposed tool's strengths. Sometimes the fastest win is fixing the current extract/search configuration rather than adding a second stack.
- When judging fit for recurring briefings, prioritize source coverage, auth burden, and reversibility over feature-list breadth.
- See `references/external-source-stack-evaluation.md` for a concrete comparison pattern and low-risk trial checklist.

## WorldMonitor augmentation
When a briefing touches geopolitics, conflict, infrastructure, macro stress, shipping, aviation, cyber, or weather-linked disruption:
- Use WorldMonitor as a secondary context layer, not a sole source of truth.
- Check `https://api.worldmonitor.app/api/health` first to confirm the relevant source stack is fresh enough to trust.
- Prefer the public discovery surfaces when you only need capability/source context: `https://worldmonitor.app/llms-full.txt`, `https://worldmonitor.app/.well-known/api-catalog`, and `https://worldmonitor.app/.well-known/agent-skills/index.json`.
- Treat premium/API-key-gated endpoints such as country briefs as optional enrichments; do not imply you used them unless you actually had working access.
- Expect some direct API calls to be bot-blocked from generic CLI clients; if so, fall back to the public docs/discovery/health surfaces and corroborating mainstream sources.
- For local experimentation, app-only dev (`npm ci && npm run dev -- --host 127.0.0.1`) is enough for UI/feed inspection; full local `/api/*` behavior requires the self-hosted Podman/Docker stack and seeders.
- For local verification, prefer `http://127.0.0.1:3000/api/health` over judging the app by `/` alone; the root can return a static 403 while the API is healthy enough to test.
- Use `/var/home/rainbow/.hermes/scripts/worldmonitor_news_signal.py --format text` to inject a compact WorldMonitor status block into the briefing workflow before synthesis.
- If a full seeder pass is slow, validate the stack with one or two targeted seeders first (for example earthquakes or weather alerts) and confirm that `/api/health` moves those checks from `EMPTY`/`STALE_SEED` to `OK`.
- See `references/worldmonitor-news-augmentation.md` for concrete usage notes.

## Fast-briefing fallback rules
When the user asks for a quick news update and the environment has thin extraction coverage:
- Try live search first across a few narrow topic buckets rather than blocking on full-page extraction.
- If a bucket returns stale, generic, or weakly-related results, immediately rerun that bucket with explicit date terms and trusted-source constraints instead of accepting noisy rankings.
- If URL extraction fails because the configured backend is search-only, fall back to search snippets and say so plainly.
- If high-value sources such as Reuters are bot-blocked in the browser, use corroborating search results from Reuters/AP/other mainstream sources instead of pretending you read the full article.
- Stamp the briefing with the current local time and clearly separate "24h signal", "7-day trend", and "weak/noisy buckets".
- When personalization is useful and local browser history is available, add a small separate "personalized signal" section rather than contaminating the main public-news ranking.
- If browser-history signal is mostly entertainment or general browsing rather than news consumption, say that plainly and keep it as lightweight context rather than forcing it into the main briefing.

## Notes
More specific workflows that fit under this umbrella include recent-news briefings, signal-oriented briefings, and live research source-coverage setup.
When the task specifically needs URL retrieval, crawling, or page extraction, load `firecrawl-research` first and treat it as the retrieval-layer companion to this skill.
