---
name: hermes-role-pipelines
description: Multi-agent role pipeline patterns adapted from the opencode-hermes-multiagent role catalog for Hermes delegate_task.
version: 1.0.0
author: Hermes
---

# Hermes Role Pipelines

Use this when a task benefits from explicit specialist roles rather than a single worker.

Installed source catalog:
- `/var/home/rainbow/.hermes/integrations/opencode-hermes-multiagent/agent/subagents/`

## Recommended Hermes mapping

Research:
- finder -> fast file scout
- analyst -> dependency/risk analysis
- researcher -> external docs

Planning:
- architect -> solution shape
- planner -> task decomposition

Implementation:
- coder -> new code
- editor -> safe edits
- fixer -> bug fix
- refactorer -> structure cleanup

Quality:
- reviewer -> review findings
- tester -> focused tests
- security -> auth/secrets/data review
- debugger -> root cause analysis

Infrastructure:
- devops -> CI/CD, containers, deployment
- optimizer -> performance

## Example pipelines

Bug fix, unknown cause:
1. finder
2. debugger
3. fixer
4. reviewer
5. tester

Feature with security impact:
1. finder
2. analyst
3. researcher
4. architect
5. planner
6. coder
7. reviewer
8. security
9. tester

## Hermes execution pattern

Use parallel delegation for independent discovery, then a second wave for implementation and review.
Keep each subtask self-contained and pass compact context packets only.

## Local note

The upstream role catalog was designed for OpenCode AI. In Hermes, treat it as a role prompt library and map the roles into `delegate_task` goals rather than copying OpenCode config directly.
