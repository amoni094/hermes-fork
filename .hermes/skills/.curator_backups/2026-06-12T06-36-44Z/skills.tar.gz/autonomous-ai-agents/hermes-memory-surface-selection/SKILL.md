---
name: hermes-memory-surface-selection
description: Choose between Hermes durable memory, session_search, qmd, and MemPalace based on scope, mutability, and retrieval needs.
created_by: agent
---

# Hermes memory surface selection

Use this when deciding where information should live in a Hermes-centered workflow, or which retrieval surface to query first.

## Goal
Keep durable facts small and high-signal in Hermes memory, use transcript search for prior conversations, use qmd for curated local knowledge, and use MemPalace for richer external/project memory retrieval without overloading Hermes core memory.

## Default decision order
1. Hermes durable memory (`memory` tool)
2. `session_search`
3. qmd (`mcp_qmd_*`)
4. MemPalace MCP tools

Choose the smallest surface that can answer the question well.

## Use Hermes durable memory for
- Stable user preferences
- Long-lived environment facts
- Recurring conventions the user should not have to repeat
- Small declarative facts that will still matter in weeks

Do not use Hermes durable memory for:
- task progress
- large notes
- bulk transcripts
- changing research findings
- raw document storage

## Use `session_search` for
- "What did we decide about X?"
- finding prior attempts, errors, or resolutions from old chats
- recovering context before asking the user to repeat themselves

Prefer this before adding new durable memory when the fact may already exist in prior session history.

## Use qmd for
- curated local notes and documents
- Obsidian/vault-style knowledge bases
- page/heading/path-oriented retrieval
- workflows where the canonical answer should live in a maintained document

qmd is usually the best first stop for local knowledge that has already been organized.

## Use MemPalace for
- larger memory corpora that should stay outside Hermes core prompt memory
- project or archive retrieval where embeddings/graph/tunnel-style lookup help
- optional exploratory recall over a body of notes or extracted material
- adjunct memory services exposed cleanly over MCP

Treat MemPalace as an extension layer, not a replacement for Hermes memory semantics.

## Decision rules
- If the fact should auto-influence future chats and fits in one compact sentence, save it to Hermes durable memory.
- If the answer probably exists in a past Hermes conversation, use `session_search` first.
- If the answer belongs to a maintained local document or vault note, use qmd.
- If the material is broader, more exploratory, or better kept outside Hermes built-ins, use MemPalace.

## Priority and trust
- Canonical user/profile facts: Hermes durable memory
- Canonical workspace knowledge docs: qmd-backed files
- Historical conversation evidence: `session_search`
- Supplemental/archive/project retrieval: MemPalace

When sources disagree:
1. live files / current system state
2. explicit user instruction
3. Hermes durable memory for user preferences and stable facts
4. curated qmd docs
5. session history
6. MemPalace recall

## Pitfalls
- Do not dump large blobs into Hermes memory.
- Do not save stale task artifacts as durable memory.
- Do not use MemPalace just because it exists; prefer qmd for curated local canonical notes.
- Do not treat compressed session summaries as canonical memory.

## Quick examples
- "Remember I prefer concise answers" → Hermes durable memory
- "What did we do last week for MCP auth?" → `session_search`
- "Find the note about local retrieval routing" → qmd
- "Search a broad imported archive of project notes" → MemPalace

## Support files
- `references/memory-surface-matrix.md` — compact comparison table and routing examples.
- `references/mempalace-adjunct-pattern.md` — concise decision pattern for treating MemPalace-style MCP systems as adjunct retrieval layers.
