---
name: hermes-obsidian-rollups
description: Curate Hermes config/runtime changes into Obsidian daily and live-sync notes with activation-state caveats.
created_by: agent
version: 1.0.0
---

# Hermes Obsidian Rollups

Use this when the user asks to document Hermes work in Obsidian, summarize today's Hermes progress, or update the durable live-sync note after config/runtime changes.

## Trigger conditions

- User asks to document today's progress in Obsidian.
- Hermes config, routing, delegation, gateway, dashboard, cron, or memory settings were changed and the result should be written into the vault.
- A daily note and a rolling summary note both need to stay aligned.

## Goal

Write concise, durable notes that capture verified Hermes state changes without copying chat transcripts or leaking sensitive detail.

## What to update

1. Update the rolling summary note first.
   - Record durable changes only: config changes, verified service/routing changes, stable caveats, and next follow-ups.
   - Prefer operational facts over narrative.
2. Update the same-day daily note second.
   - Add a short "Hermes Chat Sync" section or refresh it.
   - Point back to the rolling summary note with a wikilink.
3. Verify both files after writing.

## Required content rules

- Include what changed.
- Include what was verified.
- Include what still requires activation.
- Include the next concrete follow-up if one is obvious.
- Exclude raw transcripts, long logs, and secrets.

## Activation-state pitfall

When documenting Hermes config changes, distinguish between:

- config state: what is written in `~/.hermes/config.yaml`
- managed-service state: what has taken effect in the restarted gateway/systemd service
- current-session state: whether the active CLI conversation is still using old in-memory settings

Do not write "X is active" unless it was actually verified in the relevant runtime.

## Rollout checklist for config/routing changes

1. Confirm the config change exists.
2. If the user asks to make it take effect, restart the relevant managed Hermes service instead of assuming config writes are enough.
3. Verify the restart with a concrete runtime marker such as a new PID or active service status.
4. In the Obsidian note, explicitly state if the current CLI chat still needs `/reset` or a fresh session.

## Recommended note shape

For the rolling note:
- durable runtime/service state
- config and performance tuning
- maintenance/automation state
- caveats
- follow-ups

For the daily note:
- last synced time
- summary-note link
- 3-5 bullets of today's most important verified Hermes changes
- 1 bullet for the next focus

## Good examples of durable caveats

- delegation routing is configured but still needs a fresh Hermes session or service restart to take effect
- a managed gateway service was restarted and verified with a new PID
- a local model context limit is still too low for dependable ACP-style delegation

## Avoid

- claiming rollout completion based only on config edits
- copying full command output into Obsidian
- storing credentials, tokens, or private IDs
- bloating daily notes with one-off debugging chatter
