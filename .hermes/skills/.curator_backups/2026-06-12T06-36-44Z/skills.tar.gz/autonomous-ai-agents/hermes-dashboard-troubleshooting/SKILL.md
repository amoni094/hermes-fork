---
name: hermes-dashboard-troubleshooting
description: Troubleshoot Hermes dashboard/WebUI startup, chat sidebar, and event-feed issues with build-first and websocket verification steps.
version: 1.0.0
author: Hermes Agent
license: CC0-1.0
created_by: agent
---

# Hermes Dashboard Troubleshooting

Use when the Hermes dashboard/WebUI is up but partially broken, fails to start cleanly, or the embedded chat/sidebar says the event feed is disconnected and tool calls are missing.

## Durable pitfall: `/chat` 1006 with an existing built TUI

If dashboard `/chat` dies with websocket code `1006` and the dashboard logs show `npm install failed.` during PTY startup, check whether `ui-tui/dist/entry.js` already exists.

Why this happens:
- `/api/pty` reaches `_resolve_chat_argv()`
- `_resolve_chat_argv()` calls `_make_tui_argv()`
- `_make_tui_argv()` may decide it needs an npm install/build at connect time
- on lightweight hosts, that path can fail because native build tooling for optional Node dependencies is missing
- the browser then surfaces the PTY startup failure as `session ended (code 1006)`

Durable fix pattern:
1. In `hermes_cli/web_server.py::_resolve_chat_argv()`, prefer an already-built `ui-tui/dist/entry.js` bundle when it exists.
2. Launch it directly with `node --expose-gc <dist/entry.js>`.
3. Fall back to `_make_tui_argv()` only when no usable dist bundle exists.
4. Restart the dashboard.
5. Verify `/api/pty` directly; successful verification is receiving PTY bytes on connect instead of an immediate close.

This is the durable lesson: dashboard chat should prefer a known-good built TUI bundle over an unnecessary reinstall/rebuild path during websocket startup.

## Triggers

- `hermes dashboard` fails during startup or exits before binding.
- The dashboard loads but the chat sidebar says `events feed disconnected — tool calls may not appear`.
- Embedded chat works only partially: terminal pane renders, but tool-call events do not show in the sidebar.
- You need to verify whether `/api/pub` → `/api/events` rebroadcasting is healthy.

## Core rule

Do not stop after reading code or logs. Restore a working dashboard and verify the event path with a real round-trip.

## Workflow

1. Confirm the dashboard state.
   - Check whether a dashboard process is already running.
   - Check whether the default port (`127.0.0.1:9119`) is listening.
   - If startup recently failed, inspect the dashboard process output first.

2. Treat build/runtime separately.
   - If `hermes dashboard` reports Web UI build or npm-install failures, fix the frontend assets first.
   - From the repo root's `web/` directory:
     - `npm install`
     - `npm run build`
   - Hermes writes the built bundle into `hermes_cli/web_dist/`.

3. Relaunch without rebuilding when the assets are already known-good.
   - Start with:
     - `hermes dashboard --no-open --skip-build`
   - Use `--skip-build` after a successful manual build to avoid repeating build-time failures during service recovery.

4. Verify the browser-facing dashboard.
   - Confirm the page loads at `http://127.0.0.1:9119`.
   - Confirm the Chat page renders and the sidebar reaches `live` state.

5. Verify the event-feed path directly.
   - The structured tool-call sidebar depends on a websocket rebroadcast chain:
     - PTY child publishes to `/api/pub?channel=...`
     - browser sidebar subscribes to `/api/events?channel=...`
   - If the UI still looks suspicious, perform a direct websocket round-trip:
     - connect a subscriber to `/api/events`
     - connect a publisher to `/api/pub`
     - send a JSON frame like `{"method":"event","params":{"type":"tool.start",...}}`
     - confirm the subscriber receives the same frame
   - This proves the sidebar transport is healthy even if the visual UI is lagging or the session is idle.

## Pitfalls

- A user systemd autostart unit can keep re-triggering the same unnecessary npm-install path at every boot. When built dashboard/TUI assets already exist, patch the unit's `ExecStart=` to add `--skip-build`, then `systemctl --user daemon-reload && systemctl --user restart hermes-dashboard.service`.

- `hermes dashboard` can fail only because the frontend dependencies/assets are missing or stale. In that case the backend/websocket code may be fine; rebuild first instead of patching server code immediately.
- A startup-side `Installing TUI dependencies…` → `npm install failed.` message does not, by itself, prove the dashboard failed to come up. If prebuilt assets already exist (`ui-tui/dist/entry.js`, `hermes_cli/web_dist/index.html`), verify the live HTTP listener and `/chat` before treating it as a real outage.
- A working dashboard page does not prove the tool-call sidebar transport is working. Verify `/api/pub` and `/api/events`, not just `/`.
- After confirming built assets exist, prefer `hermes dashboard --skip-build` as the smallest recovery path. This avoids unnecessary workspace-root npm installs that can drag in unrelated native dependencies.
- If manual npm reproduction is needed, distinguish workspace scopes: root-level installs can fail on optional/native deps from unrelated workspaces (for example `node-pty`) even when the dashboard/web assets are already good enough to run.
- After a manual successful build, prefer `--skip-build` for recovery and verification runs. It reduces moving parts.
- If you intentionally kill a broken dashboard and restart it, Hermes may later surface an `[IMPORTANT: Background process ... completed]` notice for the old tracked launcher. Do not treat that notice as proof the current dashboard died. Verify the live listener and current PID with `ss` + `ps`, then check `/chat` again.
- When diagnosing the sidebar banner, distinguish these layers:
  - page load / static assets
  - PTY websocket (`/api/pty`)
  - sidecar gateway websocket (`/api/ws`)
  - event rebroadcast websocket (`/api/pub` + `/api/events`)

## References

- `references/event-feed-recovery.md` — websocket rebroadcast recovery recipe for missing tool-call events.
- `references/webui-chat-1006-built-dist.md` — durable fix for `/chat` code 1006 when PTY startup tries to rebuild instead of reusing an existing built TUI.
- `references/dashboard-restart-process-noise.md` — how to tell a stale process-completion notice from the current live dashboard state.
- `references/systemd-autostart-skip-build.md` — user-systemd recovery pattern for dashboard autostart when prebuilt assets exist and rebuilds are unnecessary.
- `references/dashboard-skip-build-with-prebuilt-assets.md` — recovery pattern when startup prints npm-install failure even though existing dashboard/TUI assets are usable.

## Verification checklist

- Dashboard is listening on the expected host/port.
- The main page loads.
- Chat page renders.
- Sidebar no longer shows the disconnected banner.
- A direct `/api/pub` → `/api/events` websocket test succeeds.

## Reference

- `references/event-feed-recovery.md` — concise recovery and websocket verification recipe for the disconnected event-feed symptom.
