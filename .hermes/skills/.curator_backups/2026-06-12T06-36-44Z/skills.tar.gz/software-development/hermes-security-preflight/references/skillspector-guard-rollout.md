# SkillSpector guard rollout for Hermes skill libraries

Use this pattern when adding SkillSpector (or a similarly aggressive skill scanner) to an already-populated local Hermes skill library.

## Why

In practice, SkillSpector can assign HIGH/CRITICAL scores to legitimate tool-heavy or admin-oriented skills while returning no concrete `findings` array. Treat it as a coarse gate, not an autonomous remediator.

## Recommended rollout

1. Run scans in static-only mode first:
   - `skillspector scan <skill-or-library> --no-llm --format json`
2. Save per-skill reports so the score history is inspectable later.
3. Baseline the current library by content hash.
4. Mark the current installed set as trusted-by-hash rather than auto-quarantining it immediately.
5. Enable quarantine only for future new or changed non-bundled skills whose score crosses the chosen threshold.
6. Keep bundled and hub-installed skills out of automatic edits/quarantine unless the user explicitly asks for that policy.

## Good default enforcement shape

- Baseline file: map `relative_skill_path -> content_hash`
- Report directory: one JSON report per skill
- Enforcement trigger: new skill, changed hash, or newly added local skill
- Quarantine target: move the whole skill directory to a dated quarantine root
- Quiet runs: produce no output when nothing new requires action

## Useful thresholding lesson

A score threshold around 60 is a reasonable first pass for quarantine when the scanner uses a 0-100 risk score and frequently over-flags. Review false positives before tightening further.

## Concrete lesson from this session

The safer rollout was:
- initialize a baseline of the current Hermes library by hash
- keep current flagged skills as reviewed baseline state
- schedule a recurring enforcement job
- quarantine only future risky, changed, non-bundled skills

That preserves the working library while still catching suspicious future additions or drift.
