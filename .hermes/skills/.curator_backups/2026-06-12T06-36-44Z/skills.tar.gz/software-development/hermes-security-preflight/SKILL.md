---
name: hermes-security-preflight
description: "Use when you need the Hermes security preflight for external code, workflow bundles, plugins, or shared-surface changes."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, security, preflight, external-code, plugins]
    related_skills: [hermes-agent, requesting-code-review, systematic-debugging, hermes-workflow-optimization, hermes-coding-review-loop]
---

# Hermes Security Preflight

## Overview

Use this skill when importing external code, evaluating workflow bundles, or widening a shared surface.

The goal is to separate raw source from conclusions, scan for obvious risk, and only adopt the parts that materially reduce repeated context, token spend, or re-explanation.

## When to Use

- You are reviewing code copied from the web or another repository.
- You are evaluating a plugin, skill, or workflow bundle.
- You are about to expose a shared channel, tool surface, or control surface.
- You need a quick security scan before adoption.

## Security Scan

Check for:

- shell execution
- dynamic evaluation
- destructive file operations
- secret handling
- network calls
- unsafe dependency usage
- unsafe archive handling (zip/tar extraction, path traversal, symlink extraction)

For tools that ingest untrusted artifacts, inspect the input path first, not just the analyzer logic. In particular, treat raw `extractall`-style archive extraction without member validation as a real blocker until path traversal and special-file handling are checked.

Then ask:

- Does this actually reduce future work?
- Is the permission surface justified?
- Can the useful part be adopted without the broad bundle?
- Is the raw source kept separate from the conclusion?

## Adoption Rules

- Prefer small reusable pieces over whole suites.
- Pin versions where possible.
- Avoid broad permission surfaces.
- Keep control-plane style capabilities off by default.
- Use hooks or other deterministic enforcement points when a rule must be enforced consistently instead of only remembered.
- Treat external workflow bundles like untrusted packages until proven otherwise.
- For scanners or review tools that can call remote LLMs or APIs, verify a local/static-only mode first and prefer that as the default when reviewing sensitive inputs.
- When rolling out a scanner across an existing local skill library, baseline the current installed set by content hash first, then enforce quarantine only on future new or changed non-bundled skills that cross the risk threshold.

## Skill Library Rollout Pattern

For a local Hermes skill library, do not let a newly introduced scanner immediately auto-quarantine the current estate on first run. Many skill scanners score high on legitimate admin, automation, or tool-heavy skills even when they produce no concrete findings payload.

Use this rollout sequence instead:

1. Run the scanner in local/static-only mode and capture per-skill reports.
2. Record a trusted baseline of the current installed skills by hash.
3. Review the current high-score set manually or keep it as a flagged baseline.
4. Turn on automated quarantine only for future new or modified non-bundled skills above threshold.
5. Keep bundled or hub-installed skills out of automatic mutation unless the user explicitly wants them managed.

Reference: `references/skillspector-guard-rollout.md`

## Common Pitfalls

1. Skipping the scan because the source looks reputable.
2. Copying a whole bundle when only one pattern is useful.
3. Mixing source text and conclusions together.
4. Widening shared surfaces before checking whether it is really necessary.

## Verification Checklist

- [ ] External source was inspected before adoption.
- [ ] Security risks were checked explicitly.
- [ ] Only the useful parts were kept.
- [ ] Permission surface stayed as small as possible.
- [ ] The conclusion is separated from the raw source.
