#!/usr/bin/env bash
set -euo pipefail

# Template: user-space Wi-Fi/VPN recovery launcher.
# Adjust WIFI_DEVICE if the host uses a different wireless interface.

PATH=/usr/bin:/usr/sbin:/bin:/sbin:${HOME}/.local/bin
WIFI_DEVICE="wlp0s20f3"
VPN_SERVICE="protonvpn-autostart.service"
LOG_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/network-recovery"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/recover-internet.log"
exec > >(tee -a "$LOG_FILE") 2>&1

ts() { date '+%Y-%m-%d %H:%M:%S'; }
log() { printf '[%s] %s\n' "$(ts)" "$*"; }
try() {
  log "+ $*"
  if "$@"; then
    return 0
  fi
  rc=$?
  log "command failed with exit $rc (continuing)"
  return $rc
}
notify() {
  command -v notify-send >/dev/null 2>&1 && notify-send "$1" "$2" || true
}

log "Starting recovery"
notify "Internet recovery" "Trying Wi-Fi/VPN reset"

current_wifi="$(nmcli -t -f NAME,TYPE connection show --active | awk -F: '$2=="802-11-wireless" {print $1; exit}')"
current_vpn="$(nmcli -t -f NAME,TYPE connection show --active | awk -F: '$2 ~ /wireguard|vpn/ {print $1; exit}')"
log "Active Wi-Fi: ${current_wifi:-<none>}"
log "Active VPN: ${current_vpn:-<none>}"

[[ -n "$current_vpn" ]] && try nmcli connection down "$current_vpn"
try systemctl --user restart "$VPN_SERVICE"
try nmcli radio wifi off
sleep 3
try nmcli radio wifi on
sleep 2

if [[ -n "$current_wifi" ]]; then
  try nmcli connection up "$current_wifi"
else
  try nmcli device wifi rescan
fi

for _ in {1..20}; do
  state="$(nmcli -t -f GENERAL.STATE device show "$WIFI_DEVICE" 2>/dev/null | head -n1 | cut -d: -f2- || true)"
  [[ "$state" == "100 (connected)" ]] && break
  sleep 1
done

try nmcli general status
try nmcli device status
try nmcli -t -f NAME,TYPE,DEVICE connection show --active

if nmcli -t -f GENERAL.STATE device show "$WIFI_DEVICE" 2>/dev/null | grep -q '100 (connected)'; then
  [[ -n "$current_vpn" ]] && try nmcli connection up "$current_vpn"
  notify "Internet recovery" "Recovery finished. Check the terminal window for details."
  read -r -p "Done. Press Enter to close..." _
  exit 0
fi

notify "Internet recovery" "Wi-Fi still not connected. You may need to restart NetworkManager or reboot."
printf '\nIf this did not fix it, try:\n'
printf '  sudo systemctl restart NetworkManager\n\n'
read -r -p "Press Enter to close..." _
exit 1
