---
name: linux-vpn-autostart
description: Automate VPN client startup on Linux desktops with network-aware launch ordering, client-specific autoconnect settings, and verifiable user-session hooks.
---

# Linux VPN autostart

Use this when the user wants a VPN client to launch automatically at login/boot and connect without manual clicks, especially on Linux desktops using systemd user sessions, XDG autostart, Flatpak apps, or NetworkManager-backed VPN clients.

## What this skill is for

This skill covers the class of work where the app already knows how to connect, but startup behavior is unreliable or not fully configured. The job is to make launch timing explicit, make autoconnect settings durable, and verify the real startup path instead of assuming a toggle in the UI is sufficient.

Typical cases:
- Start a VPN GUI at login and connect automatically.
- Delay VPN startup until network is actually online.
- Wrap a Flatpak or desktop app with a helper script.
- Enforce a client config such as fastest-server autoconnect or minimized startup.
- Replace brittle login hooks with a verifiable user-session entry point.

## Default approach

1. Discover the real launch path.
   - Check whether the VPN is packaged as native RPM/DEB, Flatpak, or a custom script.
   - Inspect existing XDG autostart entries, systemd user units, and wrapper scripts before writing anything.
   - Prefer extending an existing working startup hook over inventing a second one.

2. Find the client's durable autoconnect setting.
   - Look for a config file or documented setting that controls startup connection behavior.
   - Prefer setting the client to autoconnect itself rather than simulating clicks.
   - For GUI apps, look for JSON/YAML config under the app's config directory.

3. Add network readiness gating.
   - If NetworkManager is present, use `nm-online -q -s -t <seconds>` before launch.
   - Log timeout cases, then continue rather than failing silently.
   - This avoids the common race where the VPN app starts before the session has usable connectivity.

4. Use a single-entry wrapper script.
   - Put all startup logic in one small shell script.
   - Responsibilities: set PATH, acquire a lock, wait for network, normalize config, log actions, launch the app.
   - Keep the script idempotent so repeated login triggers do not spawn duplicates.

5. Keep the user-session integration simple.
   - XDG autostart (`~/.config/autostart/*.desktop`) is usually enough for GUI VPN apps.
   - Use a user systemd service when the user explicitly wants systemd management or when the app is not desktop-session-oriented.

6. Verify with real outputs.
   - Syntax-check the script.
   - Dry-run the wrapper if possible.
   - Read back the config file to confirm the expected autoconnect values were actually written.
   - Confirm the desktop entry or systemd unit points at the wrapper you updated.

## Implementation pattern

Recommended shell wrapper structure:
- `set -euo pipefail`
- deterministic `PATH`
- lock directory under `XDG_RUNTIME_DIR` or a user-owned state dir
- logs under `XDG_STATE_HOME` or `~/.local/state`
- `nm-online` wait if available
- small config-normalizing step using Python or jq
- final `exec` of the real client command

## Flatpak-specific notes

- For Flatpak GUI apps, the effective config often lives under `~/.var/app/<APP_ID>/config/...`.
- Launch via `flatpak run ...` and prefer the app's actual command if it differs from the app ID.
- If the Flatpak ships a native startup flag like `--start-minimized`, use that instead of desktop-environment-specific minimization hacks.

## Pitfalls

- Do not assume “start at login” also means “connect at login”; many clients store those as separate settings.
- Do not create both a user systemd service and an XDG autostart entry unless you deliberately want both; duplicate launch paths create race conditions.
- Do not rely on arbitrary sleeps when `nm-online` or another real readiness signal is available.
- Do not automate GUI clicks if the client has a persistent autoconnect config.
- Do not overwrite the whole app config blindly without preserving unrelated keys.

## Verification checklist

- Wrapper script exists, is executable, and passes `bash -n`.
- Config file contains the intended autoconnect/minimized values.
- Startup entry points to the wrapper script.
- Dry-run prints the exact final launch command, if the wrapper supports it.
- Log path is known so the user can inspect first-login failures.

## ProtonVPN Flatpak note

A concrete ProtonVPN Flatpak example from this workspace is captured in `references/protonvpn-flatpak-fastest-startup.md`.

## Recovery launcher pattern for NetworkManager-backed VPN desktops

When the user's real problem is not startup but a post-drop wedged VPN/Wi-Fi state, keep the same desktop/user-session mindset: provide a user-space recovery launcher before escalating to reboot instructions. For a concrete ProtonVPN + NetworkManager pattern, see `references/protonvpn-networkmanager-recovery-launcher.md`.

This is especially useful when the user wants a double-click desktop fix rather than a terminal-only recipe. The launcher should:
- disconnect the current VPN if active
- bounce Wi-Fi with `nmcli`
- reconnect the previous Wi-Fi profile
- attempt to reconnect the previous VPN
- log to `XDG_STATE_HOME`
- use a trusted `.desktop` file with `Terminal=true`

## VPN-driven forwarded-port consumers

If the user's VPN rotates a forwarded port that another app must consume (common with torrent clients), treat this as a synchronization problem rather than a one-time config edit.

Recommended pattern:
- source the live forwarded port from the VPN client's durable local state/log
- trigger reconciliation from both a `systemd --user` `.path` watcher and a periodic `.timer`
- update both persisted app config and live session state when possible
- keep an explicit managed-port state file so previous ports can be closed reliably
- make live-RPC update failures non-fatal when persisted config and firewall cleanup can still succeed
- verify the final firewall state is exactly one current forwarded port, with stale ports removed

Reference: `references/protonvpn-forwarded-port-sync-for-torrent-clients.md`.

## Recovery launchers for VPN/Wi-Fi wedges

When the user's problem is not startup automation but post-failure recovery, prefer a small user-space recovery launcher over telling them to reboot.

Recommended pattern:
- disconnect the active VPN first if one is active
- restart the user-level VPN autostart/helper service if the setup has one
- toggle Wi-Fi off/on with `nmcli radio wifi off/on`
- reconnect the previously active Wi-Fi profile
- reconnect the previous VPN only after Wi-Fi is back
- log to `~/.local/state/...` and keep the launcher terminal-visible so failures are readable
- if the stack is still wedged, print the privileged fallback (`sudo systemctl restart NetworkManager`) rather than trying to hide privilege boundaries

Desktop integration notes:
- for non-technical users or repeated incidents, ship both a shell wrapper and a `.desktop` launcher
- set `Terminal=true` so the user can see each recovery step and the final status
- mark the desktop launcher executable/trusted where the desktop environment requires it
- prefer user-space actions first; only escalate to privileged NetworkManager restart as the explicit fallback path

Support templates for this pattern live under:
- `templates/recover-internet.sh`
- `templates/recover-internet.desktop`

## When to add a support file

Add a reference file when you discover client-specific config keys, config paths, launch flags, or known-good wrapper patterns for a particular VPN vendor/package format.
