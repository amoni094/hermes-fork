# ProtonVPN forwarded-port sync for torrent clients

Use this when a torrent client (for example Fragments/Transmission) must always track ProtonVPN's current forwarded port, and stale firewall openings must be retired when the VPN rotates or drops the port.

## Durable pattern

1. Source of truth
- Read ProtonVPN's current forwarded port from the app log instead of hardcoding a port.
- Accept both observed log shapes:
  - `internal_port: <n>, external_port: <n>`
  - `forwarded_port: Some(<n>)`

2. Two triggers, not one
- Use a user `systemd` `.path` unit to react to ProtonVPN log updates immediately.
- Also use a periodic `.timer` as a backstop in case file-watch timing misses an event or the client rewrites state without a clean path signal.

3. Sync both persisted and live torrent-client state
- Update the saved config file (`peer-port`) so restarts keep the right port.
- If the client exposes a live RPC/session API, update the running session too.
- Treat temporary live-RPC unavailability as non-fatal when the persisted config and firewall can still be corrected.

4. Track prior ports explicitly
- Keep a small state file of managed ports.
- Add the torrent client's currently configured port to the cleanup set before changing it, so a manually-set previous port is retired even if it was not already in the state file.
- Keep any legacy/static historical ports in the managed set until they have been cleaned once.

5. Firewall policy
- Desired state is exactly one forwarded port open (TCP+UDP), both runtime and permanent.
- Remove every old managed port before adding/re-adding the current forwarded port.
- When ProtonVPN no longer reports a forwarded port, close all managed ports and disable live client port-forwarding if possible.

## Practical notes from this session
- Fragments stores Transmission-style settings in:
  `~/.var/app/de.haeckerfelix.Fragments/config/fragments/settings.json`
- A useful local state file pattern is:
  `~/.local/state/fragments-proton-port-sync.json`
- If live RPC on `127.0.0.1:9091/transmission/rpc` refuses connections briefly, do not fail the whole reconciliation if file-state and firewall-state can still be brought into sync.

## Verification checklist
- Syntax-check the sync script.
- Run the sync job once manually.
- Confirm torrent client config now matches ProtonVPN's latest forwarded port.
- Confirm only the current forwarded port is open in `firewalld` runtime and permanent state.
- Confirm the `.path` and `.timer` units are enabled/active.
