# ProtonVPN Flatpak fastest-startup reference

Use this note when automating ProtonVPN installed as the Flatpak `com.protonvpn.www`.

## Verified paths

Wrapper script used for login startup:
- `~/.local/bin/protonvpn-autostart`

XDG autostart entry:
- `~/.config/autostart/com.protonvpn.www.desktop`

Persistent app config:
- `~/.var/app/com.protonvpn.www/config/Proton/VPN/app-config.json`

Suggested log path:
- `~/.local/state/protonvpn-autostart/protonvpn-autostart.log`

## Verified config keys

`app-config.json` accepts:

```json
{
  "tray_pinned_servers": [],
  "connect_at_app_startup": "FASTEST",
  "start_app_minimized": true
}
```

Key behaviors:
- `connect_at_app_startup: "FASTEST"` tells the app to quick-connect to the fastest available server at startup.
- `start_app_minimized: true` suppresses unnecessary GUI noise at login.

## Verified launch command

Use the app's own binary via Flatpak and pass the minimize flag:

```bash
flatpak run --branch=stable --arch=x86_64 --command=protonvpn-app com.protonvpn.www --start-minimized
```

## Recommended wrapper behavior

1. Set a deterministic PATH.
2. Acquire a lock directory so duplicate login triggers exit cleanly.
3. Wait for NetworkManager readiness with:
   `nm-online -q -s -t 90`
4. Normalize `app-config.json` instead of assuming the UI already saved the right values.
5. `exec` the Flatpak command as the final step.

## Why this pattern matters

ProtonVPN's own startup flow will run autoconnect actions after launch, but only if the config is already set. The wrapper should therefore enforce the config before starting the app, rather than trying to trigger connection externally.
