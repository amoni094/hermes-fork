# ProtonVPN + NetworkManager recovery launcher

Use this when a Linux desktop with NetworkManager-backed ProtonVPN appears to lose internet until reboot, especially when:
- Wi-Fi association/authentication flaps or times out
- ProtonVPN killswitch interfaces remain active
- the VPN cannot reconnect cleanly after the underlying Wi-Fi drop

## Symptom pattern

Common journal signals:
- `supplicant-timeout`
- `link timed out`
- `psk mismatch reported by supplicant`
- `no secrets: No agents were available for this request`
- ProtonVPN retries like `VPN server NOT reachable` / `Timeout`
- dummy/killswitch interfaces become the default route while VPN reconnect is failing

Interpretation:
1. Wi-Fi auth/association entered a bad state.
2. ProtonVPN/killswitch continued managing routes while the VPN was unreachable.
3. User-space traffic remained blocked until the stack was reset.

A reboot fixes this because it restarts NetworkManager, wpa_supplicant, systemd-resolved, and ProtonVPN. A lighter-weight user workflow is often enough.

## Preferred user-facing recovery workflow

For easy reuse, create BOTH:
- a shell script on the desktop (or under `~/.local/bin/` with a desktop wrapper)
- a trusted `.desktop` launcher with `Terminal=true` so the user can double-click it

Keep it user-space first. Avoid requiring sudo for the primary launcher.

Recommended script flow:
1. detect the active Wi-Fi connection name with `nmcli`
2. detect the active VPN connection name with `nmcli`
3. disconnect the active VPN if present
4. restart the user's ProtonVPN autostart/reconnect service if one exists
5. toggle Wi-Fi off, then on
6. reconnect the previously active Wi-Fi profile if known
7. wait briefly for Wi-Fi to reach `GENERAL.STATE = 100 (connected)`
8. reconnect the previous VPN if Wi-Fi recovered
9. print/log current `nmcli general status`, `nmcli device status`, and active connections
10. if recovery fails, tell the user the next escalations explicitly (for example `sudo systemctl restart NetworkManager`)

## Implementation notes

Good defaults:
- log to `${XDG_STATE_HOME:-$HOME/.local/state}/network-recovery/`
- use `notify-send` opportunistically, but do not require it
- keep the launcher interactive with a final `Press Enter to close...`
- prefer idempotent steps and non-fatal retries (`try` wrapper) so partial failure still leaves useful output

Desktop launcher details:
- `Exec=/absolute/path/to/script.sh`
- `Terminal=true`
- mark the desktop entry executable
- set `metadata::trusted true` via `gio set` when the desktop environment expects trust metadata

## Verification checklist

After writing the recovery launcher:
- `bash -n` on the shell script
- `desktop-file-validate` on the `.desktop` file
- read back the launcher to confirm `Exec` points at the script
- read back trust metadata if applicable (`gio info -a metadata::trusted ...`)

## Scope boundary

This pattern is for recovery launchers and operator ergonomics, not for permanent autostart logic. Keep it as a support pattern under the VPN desktop/systemd umbrella rather than splitting into a one-off skill.