---
name: silverblue-desktop-ricing-adaptation
description: Safely adapt third-party Linux desktop ricing/dotfiles repos to Fedora Silverblue or other Fedora Atomic desktops using selective user-space staging, rpm-ostree verification, and pre/post reboot checks.
---

# When to use
Use when the user wants to evaluate, borrow from, or install a desktop ricing / dotfiles repo on Fedora Silverblue, Kinoite, Sway Atomic, or another Fedora Atomic variant.

Typical triggers:
- "Is this dotfiles repo compatible with my system?"
- "Can you adapt this Hyprland setup for Silverblue?"
- "Review this Fedora desktop installer before I reboot"
- Any repo that mixes `install.sh`, `dnf`, COPR, display-manager changes, and `~/.config` assets.

# Goals
1. Preserve Atomic / Silverblue safety.
2. Prefer small, reversible, user-space changes first.
3. Separate repo evaluation from system mutation.
4. Get to a bootable, verifiable desktop state before chasing extras.

# Core rules
1. Do not run third-party installer scripts wholesale on Atomic systems unless the user explicitly asks and the exact side effects are understood.
2. Treat mutable-system actions as high risk: `dnf`, `sudo cp` into `/etc`, COPR enablement, display-manager switching, systemctl enablement, and theme installs under `/usr`.
3. Prefer selective adoption of:
   - `~/.config/...`
   - wallpapers/assets
   - user scripts
   - modular config fragments
4. Before saying a repo is compatible, inspect its real structure. Look for:
   - flake/NixOS-only layouts
   - Home Manager assumptions
   - hardcoded paths/usernames
   - secrets handling
   - distro-specific install scripts
5. On Silverblue, stage packages with `rpm-ostree` and verify the pending deployment before claiming success.

# Workflow
## 1) Repo compatibility triage
Inspect the repo before touching the live system.

Check for:
- top-level `README.md`
- install scripts (`install.sh`, `copy.sh`, `setup.sh`, `bootstrap.sh`)
- packaging assumptions (`dnf`, `apt`, `pacman`, `zypper`, `nixos-rebuild`, `home-manager`)
- whether the useful content is mostly user-space config under `config/` or `~/.config`

Decision buckets:
- Drop-in compatible: mostly user-space config and mild package assumptions
- Adaptable: good config source, but installer is too distro/mutable-system specific
- Poor fit: NixOS-only, Home-Manager-only, hardcoded secrets/paths, or invasive system bootstrap

## 2) Separate config staging from package installation
Do these as separate phases.

Phase A: stage configs
- back up existing `~/.config` targets first
- copy only the relevant app dirs/files
- patch obvious machine-specific defaults:
  - terminal
  - file manager
  - wallpaper dir
  - optional startup commands
- trim dependency-heavy modules before first boot (Waybar widgets, AGS/Quickshell, custom daemons)

Phase B: stage packages
- check host availability with `rpm-ostree install -n --idempotent ...`
- if packages are missing from enabled host repos, inspect the repo’s packaging source
- avoid assuming `dnf` is usable on the host just because a toolbox/container has it
- if the user prefers Flatpak, check Flatpak availability early, but do not assume session helpers belong there

## 2a) Use Flatpak selectively, not dogmatically
On Silverblue, Flatpak is often the right first choice for normal desktop apps, but many ricing dependencies are not good Flatpak candidates.

Good Flatpak candidates:
- end-user GUI apps
- optional desktop utilities that do not need compositor/session integration
- standalone tools the user launches manually

Usually poor Flatpak candidates:
- compositor helpers and wallpaper daemons
- Hyprland session utilities started via `exec-once`
- tools that need unsandboxed access to the live Wayland session, theme-generation outputs, monitor state, or process control

Practical rule:
- check `flatpak search ...` / remote listings first when the user explicitly prefers Flatpak
- if components like `swww`, `wallust`, `hyprsunset`, or `mpvpaper` are absent there, treat that as a source-selection result, not a blocker to keep forcing
- then choose the narrowest non-Flatpak path for only the remaining session-critical pieces

## 3) Prefer guarded startup commands
When adopting Hyprland/Wayland configs, patch startup lines so missing pieces do not break the first session.

Use patterns like:
- `exec-once = sh -lc 'command -v waybar >/dev/null && waybar'`
- `exec-once = sh -lc 'command -v swaync >/dev/null && swaync'`
- `exec-once = sh -lc 'command -v hypridle >/dev/null && hypridle'`
- `exec-once = sh -lc 'command -v swww-daemon >/dev/null && swww-daemon --format xrgb'`
- wrap environment import helpers too when present, e.g. `dbus-update-activation-environment` and `systemctl --user import-environment`

This keeps the first boot resilient while components are still being staged.

## 3a) Identify the real source-of-truth config before patching helpers
Many ricing repos ship both vendor/default config fragments and user override fragments, but helper scripts often assume the wrong target. Before editing a script that toggles startup lines, themes, or wallpaper backends:
- inspect which file is actually included by the live Hyprland config
- confirm whether the active lines live under `configs/` or `UserConfigs/`
- patch the helper script to edit the active file, not the mostly-empty override stub
- broaden text matching if the live file uses guarded wrappers like `sh -lc 'command -v ... && ...'`

This avoids "script runs but nothing actually persists" failures.

## 3b) Harden helper scripts, not just startup lines
For wallpaper/theme/helper scripts copied from third-party repos:
- add explicit dependency checks for required binaries before the main action
- prefer a reusable helper that exits early with a desktop notification when a dependency is absent
- distinguish optional extras from session-critical components
- add empty-state guards for user content directories and generated state files (for example: no wallpapers found, no local music files, no current wallpaper state file)
- guard monitor/session assumptions before invoking compositor commands (for example: exit cleanly if no focused monitor is detected)
- when a helper launches an app from a free-form command string, prefer an explicit shell entry like `bash -lc "$APP"` over raw `$APP &` so command-style launch strings do not break as easily
- quote config/theme paths passed to launchers like rofi
- after patching shell scripts, run `bash -n` to verify syntax before declaring the fix done
- when a rice ships many helper scripts, run a full `bash -n` sweep across both `~/.config/hypr/scripts/*.sh` and `~/.config/hypr/UserScripts/*.sh`; a healthy session can still hide a single broken helper
- if a helper embeds a large free-form data list after `exit` (for example emoji/search payloads), remember that bash still parses the whole file; wrap the payload in a quoted no-op heredoc so shell-significant text inside the data block cannot break parsing while the script still self-extracts its payload

Audit the highest-risk user helpers first:
- wallpaper selectors, randomizers, effects, and auto-rotation helpers
- rofi wrappers for calculators, music pickers, theme switchers, clipboards, and search
- small dispatch helpers that call `hyprctl`, `jq`, or other compositor-facing tools

On Atomic desktops, this turns missing extras into quiet degradations instead of confusing first-boot breakage.

## 3c) Polish Waybar by editing the active group fragments, not only the top-level bar
When the task is to remove noise or change the visible bar text, inspect the included fragments as well as `config`:
- `Modules`
- `ModulesGroups`
- `ModulesCustom`
- any user override fragments pulled in by `include`

Useful patterns from this session:
- memory -> `Mem {percentage}%`
- battery -> `Bat {capacity}%`
- backlight -> `Bright {percent}%`
- remove power-profile and notification widgets when they add clutter
- repurpose a removed module slot (for example disk) for a useful live metric such as download speed
- prefer text labels over raw interface names or icons when the user wants a cleaner bar
- if a module still shows unwanted interface text, check alternate variants such as `network#speed` and update the fragment that actually renders it
- for Waybar app docks/taskbars, the visible app-name text usually comes from the shared `wlr/taskbar` module definition in `~/.config/waybar/Modules`, not from the active top-level bar config; switch `"format": "{icon} {name}"` to `"{icon}"` when the user wants icon-only buttons
- reduce taskbar crowding as a coordinated set: lower `wlr/taskbar` `icon-size`, tighten `#taskbar button` horizontal padding/margins/min-width in `style.css`, and only then widen `#taskbar` itself if needed to keep all apps on one row
- before editing layout-switcher helpers, verify whether `~/.config/waybar/config` is still a symlink into `configs/` or has become a standalone regular file; scripts like `WaybarLayout.sh` may assume symlink-based switching while the live session is reading a copied top-level config instead
- simplify the power button itself when the user wants a minimal anchor at the top-right corner
- for a true dropdown anchored to a Waybar module, prefer Waybar's built-in GTK menu support (`"menu": "on-click"`, `"menu-file"`, `"menu-actions"`) over launching a separate rofi/GTK popup; this preserves correct dropdown mechanics and anchoring under Wayland
- if the reported symptom is specifically "pressing the power button throws a rofi error", split the problem into two layers before changing the UI architecture: (1) validate the current rofi theme/launcher path directly, then (2) decide whether the user actually wants rofi repaired or wants a true anchored dropdown. Repairing the parse error alone is not the final fix when the requested UX is a real bar-attached dropdown
- when migrating a broken power button away from rofi, keep one stable action path and change only the launcher surface: route menu items through a single dispatcher script (for example `PowerAction.sh`) and let any legacy `Wlogout.sh` path become a thin fallback wrapper instead of duplicating lock/suspend/logout/reboot/shutdown logic in multiple launchers
- if the user wants a power/menu dropdown flush to the top-right edge, tune the active right-edge geometry as a set: bar `margin-right`, `.modules-right` right padding/margin/radius, the module's own right padding/margin/radius, and the GTK `menu` CSS `margin-top`/`margin-right`; exact alignment is usually a small negative-offset polish pass rather than a launcher rewrite
- once the user says the top toolbar or right-edge capsule is correct, freeze that geometry and stop editing the bar itself; continue the polish loop only in the attached popup/menu CSS unless the user explicitly asks to re-open toolbar placement
- keep the toolbar anchor and the popup offsets conceptually separate during micro-tuning. `#custom-power` / `.modules-right` edits move the visible top-right toolbar cluster; `menu` edits move the dropdown itself. If the user asks to move only the dropdown and the toolbar shifts instead, immediately restore the module anchor before continuing
- for right-edge Waybar tuning, be explicit about margin direction before iterating: on the right-side cluster and popup, a more negative `margin-right` usually pushes the element farther left into the screen, while a less negative / more positive value moves it back toward the physical right edge. Repeat the intended direction in the patch plan so you do not invert the user's request during micro-adjust loops
- when a user reports that a previous nudge moved the popup the wrong way, treat that as a workflow correction: restate the corrected direction mapping before the next patch instead of silently applying another guess
- do not overfit a single step into a universal direction rule when the popup is near the screen edge. Large horizontal shifts can trigger GTK/Waybar edge-avoidance and re-anchor the menu, which can look like an unexpected vertical jump. If a tiny requested vertical move appears to jump far in the opposite direction, first undo the last horizontal change and re-test with one-axis-only micro-moves
- when empirical movement contradicts the raw CSS signs, trust the live screen and switch to feedback-driven micro-steps. Near the top-right edge, users may report that increasing a margin moved the popup up or left instead of down or right because GTK re-anchored it. Capture the corrected observed mapping in the next patch plan instead of reusing the previous sign assumption
- keep user-facing placement iterations terse and pixel-oriented once the mechanics are correct: treat follow-ups like `3px left`, `1px down`, `5px right` as direct geometry edits rather than reopening the architecture decision
- when styling a Waybar GTK popup menu to match the toolbar capsule, add explicit `menu`, `menuitem`, `menuitem:hover`, and `separator` CSS in `style.css` using the same theme variables as the bar (`@theme_base_color`, `@surface0`, `@blue`, `@foreground`) instead of treating the popup as separately themed
- if a Waybar GTK power menu renders but clicking items does nothing, check the `menu-actions` shape against the live Waybar version before debugging the action scripts. On Waybar 0.15 the durable working pattern is an object mapping `GtkMenuItem` ids to commands (for example `"shutdown": "systemctl poweroff"`), not a positional array. A mismatched shape can produce GLib/GObject `invalid (NULL) pointer instance` / `g_signal_connect_data` errors during `waybar -l trace` even though the menu still appears visually
- after fixing a built-in Waybar menu, verify both layers separately: (1) run `waybar -c ... -s ... -l trace` and confirm the menu-binding errors disappear, then (2) reload the live bar and continue with CSS micro-tuning only after mechanics are clean
- when a power dropdown is both misaligned and non-functional, fix the event wiring first, then tighten the right-edge geometry by editing the active trio together: `.modules-right`, `#custom-power`, and `menu` offsets. Large stale `menu { margin-right: ... }` values are a common cause of a dropdown sitting far away from the right-edge toolbar capsule
- when a VPN app should live only in the tray, remove both `network` and `network#speed` from the active bar/groups instead of only editing one visible module; interface labels often survive in a grouped fragment
- if a Flatpak tray app is exporting a `StatusNotifierItem` on DBus but its icon is not visible in Waybar, enable tray passive items (for example `"show-passive-items": true`) before blaming the app or Hyprland
- when the user asks for a tighter top bar, reduce tray spacing and module margins together; shrinking only one of them often leaves the cluster looking loose
- `references/waybar-anchored-gtk-dropdowns.md` — Waybar built-in menu pattern for top-right anchored dropdowns, including the custom power-button migration away from separate popup launchers and the geometry/CSS polish loop
- `references/waybar-right-edge-dropdown-microtuning.md` — pixel-level alignment pattern for right-edge Waybar clusters and attached GTK menus, including the easy-to-reverse `margin-right` direction pitfall during visual polish loops
- `references/waybar-power-menu-migration-single-dispatch.md` — keep one power-action dispatcher while migrating the visible launcher surface from rofi/wlogout wrappers to a Waybar-anchored dropdown
- `references/waybar-menu-actions-id-mapping-and-trace-verification.md` — Waybar 0.15 built-in GTK menu repair pattern: `menu-actions` id-to-command mapping, GLib/GObject error signature, and verification with `waybar -l trace` before geometry polish
- `references/waybar-gtk-popup-edge-clamp.md` — popup edge-avoidance/re-anchoring behavior near the top-right screen edge, with the safer pattern of moving the module anchor first and only then doing one-axis micro-tuning on the GTK menu offsets
- `references/waybar-popup-vs-toolbar-anchor-separation.md` — keep `#custom-power` / `.modules-right` edits separate from `menu` edits so dropdown-only tuning does not accidentally shove the whole top-right toolbar cluster

Verify the final bar by re-reading the active fragments and reloading Waybar; the top-level config alone does not tell you which included group is actually drawing the visible widget.

## 3d) For Flatpak desktop utilities, distinguish "not launching" from "launching hidden/minimized"
When a GUI utility is part of the desktop experience but launched from user-session hooks or a wrapper script, do not assume a missing window means the app failed to start.

Triage sequence:
1. Inspect the real launch path first: user service, autostart desktop file, wrapper script, and the Flatpak app id/command.
2. Check the app's own persisted config for visibility flags such as `start_minimized`, tray-only behavior, or auto-connect-on-start settings.
3. If the wrapper passes flags like `--start-minimized`, remove that override before chasing compositor or sandbox theories.
4. Normalize the on-disk app config to match the intended visible-launch behavior.
5. Restart the user service, syntax-check any edited shell wrapper with `bash -n`, and verify the process is actually alive.
6. Confirm runtime state with process-level evidence (`flatpak ps`, process list, recent logs) before concluding the GUI still does not start.
7. If the process stays alive after a fresh visible launch but no window appears, pivot to workspace/focus/tray behavior in Hyprland rather than treating it as a generic Flatpak failure.

Practical rule:
- for VPN, chat, sync, and tray-oriented desktop apps, "launches but hidden" is often a config/wrapper issue, not an app-startup failure.
- prefer one authoritative launch path; disable duplicate desktop-autostart entries when a user service is the chosen source of truth.

Audit the highest-risk user helpers first:
- wallpaper selectors, randomizers, effects, and auto-rotation helpers
- rofi wrappers for calculators, music pickers, theme switchers, clipboards, and search
- small dispatch helpers that call `hyprctl`, `jq`, or other compositor-facing tools

On Atomic desktops, this turns missing extras into quiet degradations instead of confusing first-boot breakage.

## 3e) For dock-like Super launchers, preserve the trigger logic and replace only the launcher payload
When the user wants the Super/Windows key to open a cleaner dock-style launcher rather than a generic app grid, do not rewrite the whole keyboard workflow first.

Workflow:
1. Disambiguate what "dock" means in this rice before touching Waybar. Ask which trigger opens it or inspect the live keybinds/scripts first. In many Hyprland setups the visible "dock" is not Waybar's `wlr/taskbar` at all; it is a Super-key rofi launcher such as `~/.config/hypr/scripts/PinnedLauncher.sh` themed by `~/.config/rofi/config-app-launcher.rasi`.
2. Find the active Super binding and the real helper script it calls; Hyprland rice often routes `SUPER_L` through a wrapper that already handles single-tap vs double-tap timing.
3. Preserve that wrapper logic if it already provides useful behavior such as double-tap actions or workspace toggles.
4. Swap only the single-tap launcher payload to a dedicated pinned-launcher script instead of replacing the whole binding tree.
5. Keep the broad launcher on its separate shortcut if one already exists (for example `Super+D`) unless the user explicitly wants it removed.
6. Build the pinned launcher from verified desktop entry ids, not display names guessed from memory.
7. In rofi, force a single-row dock layout by setting `lines: 1` and matching `columns` to the pinned-count ceiling you want visible.
8. For icon-only pinned docks, hide `element-text`, reduce `element-icon` size, tighten `element` padding/spacing, and widen the rofi `window` before changing the pinned app list itself.
9. Keep the launcher dismissible by outside click / focus loss and retain the search bar so the dock stays minimal but still searchable.
10. After editing helper scripts, run `bash -n` on every touched script before claiming the keybinding change is safe.
11. If pressing Super shows a rofi error, validate the launcher theme directly before changing the bind:
   - `rofi -no-config -theme ~/.config/rofi/config-app-launcher.rasi -dump-theme`
   - if stderr reports `Failed to parse theme`, repair or replace the theme first
12. Verify the pinned launcher's desktop ids against live desktop-entry paths before blaming script logic.
13. Re-run `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf` after the launcher-theme repair.
14. If the `SUPER_L` wrapper is bound on key release (`bindr`) and single-tap should wait briefly for a possible second tap, prefer a detached delayed launcher (`nohup`/separate shell with a pending-state file) over an inline background subshell. The detached helper should:
   - record the tap timestamp in a runtime file
   - sleep for the double-tap threshold
   - re-check that the pending timestamp still matches
   - only then launch the pinned rofi dock
   This avoids the common failure where a release-triggered wrapper exits before the delayed single-tap launcher reliably appears.
15. If double-tap calls an optional overview backend (AGS/Quickshell), fail quietly when the backend is absent instead of surfacing a noisy popup on every missed dependency. Keep the dock UX working even when overview extras are not installed.
16. If the user says the Super-key dock feels delayed rather than broken, inspect the existing single-vs-double-tap timing first instead of redesigning the launcher. In wrappers like `~/.config/hypr/scripts/SuperLauncher.sh`, the perceived lag usually comes from values such as `threshold_ms` and `launch_delay_s`; tighten them into a faster-but-still-safe range (roughly 120-180ms) before changing keybind structure.
17. After tuning that timing window, verify both layers explicitly: `bash -n` on the launcher scripts and `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf` on the compositor config.

Practical rule:
- treat "change what Super opens" as a content-routing problem first, not a compositor-binding redesign.
- if the binding and wrapper scripts are already correct, treat a visible rofi popup error as a theme-parse problem before redesigning the launcher flow.
- if the user says "dock" but describes pressing the Windows/Super key to open it, stop and verify the trigger path before editing Waybar; in this rice that usually means a rofi pinned launcher, not the top toolbar/taskbar.
- if the dock opens correctly but feels slow, prefer tightening the wrapper's single/double-tap timing window before changing launcher architecture; conservative defaults around 320ms can feel like a multi-second lag in practice.
- for release-triggered Super wrappers, make the single-tap path detached and state-driven rather than relying on a fragile inline delayed subshell.
- if overview support is optional in the current rice, absence of AGS/Quickshell should degrade quietly instead of making the Super key feel broken.
- the safest polished result is usually: single Super = pinned/searchable dock, double Super = existing overview/workspace action, separate shortcut = full app launcher.
- if the top-right power button uses a rofi dropdown, treat click-away dismissal as part of the polish pass: preserve `-click-to-exit`, remove `-normal-window` / `-steal-focus`, and validate the theme separately with `rofi -dump-theme` before changing Waybar or Hyprland bindings.

- the safest polished result is usually: single Super = pinned/searchable dock, double Super = existing overview/workspace action, separate shortcut = full app launcher.

Reference: `references/hyprland-rofi-theme-parse-repair.md` — includes the rofi 2.0 `alpha(...)` parse-failure pitfall and the fixed-color substitution repair pattern.
Reference: `references/hyprland-super-launcher-double-tap-state-machine.md`.
Reference: `references/hyprland-super-launcher-timing-tuning.md` — tighten `threshold_ms` / `launch_delay_s` in release-triggered Super launcher wrappers when the dock works but feels laggy.
Additional reference: `references/rofi-power-menu-click-away-and-theme-parse.md` — rofi power-dropdown repair pattern covering rofi 2.0 theme parse failures plus the click-away dismissal fix (`-click-to-exit` kept, `-normal-window` / `-steal-focus` removed).
Reference: `references/quickshell-overview-staged-deployment-bridge.md` — staged-deployment wrapper + autostart pattern for getting Quickshell overview working on Silverblue before the reboot that finalizes `rpm-ostree install quickshell`.

## 3f) When customizing Hyprland keybinds, verify compositor key semantics and live conflicts before proposing a shortcut
For user requests like "bind this to Super+Shift" or "make this window take the big half," do not answer from generic Hyprland memory alone.

Workflow:
1. Read the live Hyprland source-of-truth files first, especially the root `hyprland.conf` include tree plus `UserConfigs/UserKeybinds.conf`.
2. Search both default and user keybind fragments for the requested key or nearby variants before proposing a new bind.
3. If the requested chord is modifiers-only (for example `Super+Shift` with no base key), say so explicitly: Hyprland needs a non-modifier key as the trigger.
4. Prefer user-local overrides/additions in `UserConfigs/UserKeybinds.conf` rather than editing vendor/default `configs/Keybinds.conf` unless there is a strong reason to replace a shipped bind.
5. If the desired behavior already exists under a different shortcut, point to the real dispatcher first instead of inventing a new script.
6. For master-layout requests phrased as "make this window take the big half" or "swap into the main pane," check whether `layoutmsg, swapwithmaster` is already available and explain that it promotes the focused window into the master slot while demoting the current master into the stack.
7. If the user wants to reuse an occupied chord (for example `Super+M`), call out the exact conflicting bind before recommending alternatives.

Practical rule:
- treat keybinding changes as a live-config audit, not a syntax-only suggestion task
- the durable value is confirming what this Hyprland config already does, where the override should live, and whether the requested chord is even legal in Hyprland

## 4) COPR / alternate package source handling on Atomic
Preferred order:
1. Native Fedora repos via `rpm-ostree`
2. Already-enabled host repos
3. If the repo depends on a COPR and host-level COPR enablement is awkward or sudo-gated, use published RPM artifacts directly with `rpm-ostree install` if they are trustworthy and version-appropriate
4. Defer non-essential extras instead of piling on many new repos before first boot

Good use of direct RPM staging:
- compositor/session-critical packages unavailable in current host repos
- published COPR artifacts are inspectable and versioned
- the goal is one controlled pending deployment, not a permanent mutable repo reconfiguration during triage

## 4a) Verify direct COPR artifacts before treating them as a viable Atomic staging path
When Fedora repos miss a small set of Hyprland extras (for example `swww`, `hyprsunset`, or similar compositor-adjacent helpers), do not jump straight from “package missing” to “enable random COPR globally.”

Verification sequence:
1. Confirm the package is really absent from enabled host repos.
2. Query the COPR project metadata/API and capture the project description / intended scope.
3. Inspect live COPR repodata, not just a README claim, to confirm the exact package names and Fedora release build exist.
4. Extract the exact RPM artifact URLs and verify them with `rpm -Kv` after download.
5. Record the signing key id / digest result and keep the install/staging decision separate from the verification step.
6. If the current session is unprivileged and cannot mutate the rpm-ostree deployment, stop at verified staging notes rather than pretending the packages were installed.

Practical rule:
- verification evidence can be enough to recommend a narrow next host command for the user to run with sudo later
- do not blur “artifact verified” into “deployment updated”; on Atomic these are distinct milestones

## 4b) Triage local RPM ABI drift before retrying the same `rpm-ostree install`
A common Atomic ricing failure mode is that the user already has local RPMs, but they were built against an older Hyprland/Qt ABI than the current host. When a first `rpm-ostree install` fails, do not keep retrying the same artifacts.

Triage sequence:
1. Query the host ABI surface first (`rpm -q` for likely providers such as `qt6-qtbase`, `hyprland`, `hyprutils`, `hyprlang`).
2. Check missing library providers directly (`rpm -q --whatprovides 'lib…so.N()(64bit)'`).
3. If the local RPM requires an unavailable SONAME or an older/newer Qt private API, treat it as an artifact/version mismatch rather than a generic dependency failure.
4. Prefer Fedora-release-matched rebuilt RPMs from a verified COPR/repodata source over downgrading the host or forcing obsolete local artifacts.
5. Verify the replacement artifacts with `rpm -Kv`, then run `rpm-ostree install -n ...` on the exact local files before recommending the real transaction.
6. If the dry-run resolves, keep the real install command identical to the verified file set.

Practical rule:
- local possession of an RPM is not evidence of compatibility on Silverblue/Atomic
- a successful `rpm-ostree install -n` with the exact replacement file set is the confidence gate before asking for live sudo

## 4c) Interactive sudo handoff: separate package discovery from the privileged transaction
When the user starts the investigation from a session that cannot satisfy an interactive sudo prompt (for example a chat bridge or remote messenger session), finish the discovery there but move the final `rpm-ostree install` to a live terminal session.

Workflow:
1. Do all unprivileged work first: provider checks, repodata inspection, artifact download, `rpm -Kv`, and `rpm-ostree install -n`.
2. Preserve the exact verified file paths and the exact install command.
3. In the live CLI session, run the same command with sudo instead of re-solving from scratch.
4. After the privileged run, verify whether a new deployment was staged and whether reboot/switchover is required before calling the package step done.

Practical rule:
- the durable lesson is the handoff pattern, not that a specific chat surface lacked sudo
- discovery, staging, and dry-run verification can happen unprivileged; only the final deployment mutation needs the live sudo-capable session

## 4d) Restore native desktop utilities before expanding fallback glue
When a copied Hyprland/Waybar rice already contains a launcher script with a native-first branch and a fallback branch, prefer restoring the missing native utility over further customizing the fallback.

Workflow:
1. Inspect the launcher script and confirm whether it already does `command -v native_tool || fallback`.
2. Query host availability with `rpm-ostree search <package>` and verify with `rpm-ostree install -n <package>` before editing more config.
3. If the package is in enabled Fedora repos, keep the launcher logic intact; do not rewrite it just to hardcode the fallback path.
4. Check current deployment metadata (`rpm-ostree status --json`) to see whether the desired package is merely absent from `requested-packages` rather than blocked by repo availability.
5. If the privileged install must be handed off, preserve the exact `sudo rpm-ostree install --idempotent <package>` command and note that a reboot is typically required before the launcher resolves to the native branch.

Practical rule:
- for small session helpers like `wlogout`, `waybar`, or similar desktop utilities already present in Fedora repos, the narrowest Atomic-safe fix is often to layer the missing package and let the existing launcher prefer it automatically
- treat fallback launchers as continuity paths, not the final state, when native support is straightforwardly available

## 5) Pre-reboot priorities
Before reboot, optimize for a clean first session.

Prioritize:
- compositor/session package availability
- portal package availability
- lock/idle helpers
- terminal, launcher, notification center, bar
- basic wallpaper path validity

Defer until after first successful boot:
- display-manager replacement
- SDDM theming
- broad COPR expansion
- eye-candy extras
- alternate shells and secondary utilities not needed to log in and test

## 5a) GDM + Hyprland session-management pitfall
On Fedora Atomic systems using GDM, do not assume portal failures mean you should force-start session targets from Hyprland config.

If logs show:
- repeated `graphical-session.target - Current graphical user session is inactive`
- repeated `xdg-desktop-portal.service ... failed with result 'dependency'`
- `start-hyprland` aborting with `std::system_error` / `Resource deadlock avoided`

Then treat it as a likely plain-session bootstrap problem, not an `exec-once` problem.

Rules:
- keep `dbus-update-activation-environment --systemd ...` and `systemctl --user import-environment ...` if needed
- do not add `systemctl --user start graphical-session.target` because Fedora marks that target `RefuseManualStart=yes`
- do not force-start `xdg-desktop-portal` from Hyprland startup just to suppress the dependency noise
- check whether `Hyprland (uwsm-managed)` is available and whether `uwsm` itself is installed
- if the plain `Hyprland` session keeps failing with the pattern above, pivot to installing/using `uwsm` rather than adding more startup nudges

## 6) Post-reboot verification checklist
Verify binaries and core behaviors, not just files on disk.

Typical checks:
- compositor/session: `Hyprland`, `hyprctl`
- session helpers: `hyprlock`, `hypridle`, portal packages
- UX: `waybar`, `rofi`, `swaync`, terminal
- support apps: `cliphist`, `fastfetch`, `cava`, `playerctl`
- wallpaper/theming: backend command present, wallust outputs exist if referenced

If the config references generated theme files, confirm they exist before calling the setup done.

## 6a) After session recovery, separate "desktop is healthy" from "ricing stack is complete"
Once Hyprland/UWSM/portals are stable, do not keep treating the remaining work as a session bug. Pivot to a UI-stack audit and classify gaps by impact:

1. Session-critical and already healthy
- compositor launches
- `graphical-session.target` / portals are active
- main UX tools like Waybar/Rofi/SwayNC launch

2. Enhancement-only runtime gaps
- wallpaper/theme daemons such as `wallust`, `swww`, `swww-daemon`
- Qt theming helpers such as `kvantummanager`
- optional effects like animated or rainbow borders

3. Broken live references vs safe fallbacks
- read current GTK/icon/cursor settings with `gsettings get ...`
- check whether referenced user assets actually exist under `~/.themes`, `~/.icons`, `~/.config/Kvantum`, and any generated `wallust` targets
- if live settings are still on safe defaults like Adwaita/default, report the missing packages as incomplete enhancement work rather than breakage

Practical rule:
- if the desktop is running and active settings point to existing files or safe defaults, missing ricing packages are not blockers; present them as optional next-stage installs
- if active settings point to nonexistent assets or styles import missing generated files, fix those references or stage the missing assets before claiming the UI pass is clean

## 6b) When a setup insists "GUI utils" are missing, verify commands before chasing package names
Some Hyprland ricing repos and helper scripts use distro-specific package-name checks and then report a vague missing dependency like "Hyprland GUI utils" even when the actual helper applications are already installed.

Verification order:
1. Check whether the session is already healthy (`Hyprland`, `hyprctl`, portals, main bar/launcher/notification tools).
2. Check for the actual helper commands on PATH, not just a guessed package name. Common examples:
   - `nwg-look`
   - `nwg-displays`
   - `qt5ct`
   - `qt6ct`
   - `kvantummanager`
3. Only after the command-level audit, check whether a claimed package name is real in current host repos.
4. If the commands exist but the warning persists, clear stale notification state before widening the diagnosis. On Sway Notification Center setups, reset the current backlog/display state first (for example `swaync-client -C` and `swaync-client -R`) so you can distinguish an old popup from a still-firing startup hook.
5. If the commands still exist and the popup reappears after the reset, treat it as a bad installer/helper check and patch the script or app logic rather than telling the user the tools are absent.
6. When patching the checker, prefer a reusable wrapper that:
   - exports a known-good PATH for GUI launch contexts
   - tries one or more real command names
   - emits the warning only after command lookup fails
   - is syntax-checked with `bash -n` after the edit

Atomic/Fedora-specific note:
- package names like `hyprland-qtutils` may not exist in enabled Fedora repos even though the practical GUI helpers are present via separate packages
- in that case, the durable lesson is to verify command availability and fix the checker, not to keep retrying the nonexistent package name

## 6c) Patch missing-theme assumptions with stock fallbacks before chasing eye-candy packages
Third-party Hyprland rice often hardcodes non-stock GTK, icon, cursor, Kvantum, or Qt color-scheme assets that are simply not present on a fresh Fedora Atomic host.

Workflow:
1. Read the active startup/theme scripts and identify the exact theme names they expect.
2. Check whether those assets really exist under user and system paths such as:
   - `~/.themes`
   - `~/.icons`
   - `~/.config/Kvantum`
   - `/usr/share/themes`
   - `/usr/share/icons`
   - `/usr/share/Kvantum`
3. If the preferred assets are absent, patch the scripts to degrade cleanly to stock installed assets before attempting any new package-source hunt.
4. Guard Qt theme updates so `qt5ct.conf`, `qt6ct.conf`, or color-scheme files are only edited when they actually exist.
5. Re-run `bash -n` on every edited shell helper before calling the hardening complete.

Good fallback targets on Fedora Atomic:
- GTK/icons: `Adwaita`
- cursor: `Adwaita` or another installed stock cursor theme
- Kvantum: `KvDark` or `KvGnome`

Practical rule:
- if the desktop is usable and only optional theme assets are missing, prefer graceful degradation in user-local scripts over turning the task into a broad repo/COPR hunt.
- classify wallpaper/theming daemons such as `swww`, `wallust`, and `hyprsunset` as enhancement-stage work unless the current session truly depends on them to boot or remain usable.

## 6d) Treat wallust as optional unless the live config truly requires palette generation
A common Hyprland-rice failure mode on Fedora Atomic is that several user-local wallpaper/theme scripts call `wallust` directly and abort if it is missing, even though the desktop can function fine without regenerated palettes.

Workflow:
1. Search the copied helper scripts for direct `wallust` assumptions such as:
   - `require_or_notify wallust ...`
   - `command -v wallust || exit ...`
   - `wallust run ... || exit 1`
   - `wallust theme ...` in user-facing selectors
2. Replace hard requirements with one of two models:
   - wrapper model: route regeneration through a script like `WallustSwww.sh` that exits cleanly when prerequisites are absent
   - optional model: keep `wallust` behind a boolean/`command -v` guard and continue without palette regeneration
4. Re-run `bash -n` on every modified shell helper.
5. Audit the callers of any guarded wrapper too — wallpaper randomizers, selectors, refresh scripts, dark/light toggles, and theme choosers often still hard-fail via `|| exit 1`, `set -e`, or `&&` chaining even after the wrapper itself is safe.
6. Report clearly that wallpaper/theme switching now degrades gracefully when `wallust` is absent.

Practical rule:
- if `wallust` cannot be sourced cleanly from Fedora repos, Flatpak, or a verified RPM path, prefer optionalization over adding an unverified package source.
- keep user-visible warnings low-noise: a single notification that palette regeneration was skipped is better than repeated hard failures.

## 6e) Distinguish `hyprland-qt-support` from `hyprland-qtutils` before recommending installs
When a Hyprland config sets `QT_QUICK_CONTROLS_STYLE=org.hyprland.style`, do not assume the matching package is `hyprland-qtutils`.

Audit sequence:
1. Search the live config and helper scripts for real uses of:
   - `hyprland-dialog`
   - `hyprland-update-screen`
   - `hyprland-donate-screen`
   - `QT_QUICK_CONTROLS_STYLE=org.hyprland.style`
2. If only the style env var is present, inspect package contents (repo metadata or RPM file list) before recommending anything.
3. Treat the results as separate concerns:
   - `hyprland-qt-support` provides the `org.hyprland.style` QML style provider
   - `hyprland-qtutils` provides optional Qt utility executables
4. If the style provider is absent, comment out the env var or switch back to stock Qt styling rather than claiming the desktop is missing required GUI utilities.

Practical rule:
- recommend `hyprland-qt-support` only when the style plugin is actually referenced
- recommend `hyprland-qtutils` only when its binaries are actually used

## 6f) When SwayNC theming is broken, fix CSS parser errors and missing widget stanzas before chasing packages
A copied Hyprland rice can have an otherwise healthy session while `swaync` alone is degraded by bad CSS or an incomplete user config.

Workflow:
1. Read the live journal first with `journalctl --user -u swaync.service ...`.
2. If the journal reports GTK CSS parser errors like `Expected a valid selector`, inspect `~/.config/swaync/style.css` for malformed selector lists, especially stray `,;` sequences left by bad edits or upstream typos.
3. Repair the selector syntax, restart `swaync`, and re-check the journal before touching theme packages.
4. If logs still say `notifications: Config not found! Using default config...`, compare the user config with `/etc/xdg/swaync/config.json` and merge the minimal missing `widget-config.notifications` block into `~/.config/swaync/config.json` instead of replacing the full file.
5. After the notification-center fix is clean, reload Hyprland if the wider ricing pass also changed session env/theme settings.

Practical rule:
- trust the live journal over visual guessing for `swaync`
- fix parser errors and missing widget stanzas before expanding the package search
- prefer minimal config merges over overwriting a user-customized `swaync` config

## 6g) If wallust is genuinely wanted on Atomic, prefer a user-space release binary plus template migration over broad system package hunting
Once the core session is healthy, `wallust` can be added cleanly without turning the task into a host-mutation project.

Workflow:
1. Confirm the user actually wants live palette generation rather than just safe fallback behavior.
2. Check host-friendly sources in order:
   - `rpm-ostree search wallust`
   - `flatpak search wallust`
   - upstream release artifacts
3. If Fedora/Flatpak sources are absent, install the upstream release binary into user space rather than layering ad-hoc packages:
   - keep a versioned install dir such as `~/.local/opt/wallust/<version>/`
   - expose it via `~/.local/bin/wallust`
   - verify with `wallust --version`
4. Audit the existing `wallust.toml` and template targets before the first run.
5. For wallust v3, migrate repo-local template assumptions to real Jinja2 templates under `~/.config/wallust/templates/`.
6. Trim targets to components that are actually present and safe to overwrite.
7. Be especially careful with tools like `cava`: do not aim a template target at a full hand-maintained config file unless the template is meant to generate the whole file.
8. Run `wallust run -s <wallpaper>` against a real local image and verify the exact generated outputs on disk.
9. Reload only the affected UI pieces afterward (for example Waybar, SwayNC, Hyprland) and check logs rather than assuming the palette was applied cleanly.

Practical rule:
- on Silverblue/Atomic, manual user-space installation is often the narrowest successful path for optional theming tools that are missing from repos
- the durable fix is not just "install wallust"; it is aligning `wallust.toml`, v3 templates, output targets, and post-run reloads so the generated theme files are actually consumed

## 6h) After a large ricing pass, do conservative cleanup by proving obsolescence before deletion
Copied or evolved Hyprland rice often accumulates version markers, old compatibility fragments, backup-like alternates, and duplicate config variants. Clean them up, but only with reference and runtime evidence.

Workflow:
1. Limit scope to the ricing tree first (for example `~/.config/hypr`, `~/.config/waybar`, `~/.config/rofi`, `~/.config/swaync`, `~/.config/wallust`, `~/.config/qt5ct`, `~/.config/qt6ct`) before touching unrelated backups elsewhere under `~/.config`.
2. Search for obvious stale candidates by name patterns and by exact duplicate content, but treat the results as leads rather than auto-delete rules.
3. For each candidate, verify whether it is still referenced by:
   - live Hyprland includes/source lines
   - helper scripts
   - theme/wallpaper selectors
   - toolkit config paths
4. For version-gated config fragments, check the live runtime version first (for example Hyprland version) and only prune compatibility files that are clearly below the active floor.
5. Distinguish template vs generated-output pairs before calling them duplicates. Placeholder templates under `wallust/templates/` are often supposed to coexist with rendered outputs under app config directories.
6. Treat wallpaper state/cache files as live state unless proven otherwise. Files like `.current_wallpaper`, `.wallpaper_current`, or `.wallpaper_modified` are commonly read by multiple scripts and should not be removed just because they are large or hidden.
7. If two files are byte-identical but occupy separate functional paths (for example Qt5 vs Qt6 theme files, default-vs-active user config targets, or manual resolution presets), prefer leaving them unless there is strong evidence a symlink/consolidation will preserve behavior.
8. After deletion, re-run the searches and confirm the surviving source-of-truth files still exist.

Practical rule:
- only remove files that are both unreferenced and obsolete for the current runtime
- exact duplication alone is not enough when the duplicate path itself carries meaning for helper scripts or toolkit lookup

# Common pitfalls
- Repos marketed as “Fedora” may still assume mutable Workstation rather than Silverblue/Atomic.
- Display-manager scripts (`sddm`, theme installers, `systemctl enable`) are not first-pass actions.
- For a true dropdown/power menu from Waybar on Hyprland/Wayland, prefer Waybar's built-in `menu` / `menu-file` / `menu-actions` support over rofi or a standalone GTK popup window. Rofi and transient GTK windows can look close but often fail the user's expectation of a real anchored dropdown because they are not parented to the bar module.
- When tuning Waybar GTK menu placement with CSS, verify the direction empirically on the live session before applying larger adjustments. Near the screen edge, pure margin math can stop matching perceived movement because GTK/Waybar may re-place the popup to keep it visible. Use small 1-5px increments, move one axis at a time, and if a horizontal nudge suddenly causes a large vertical jump, suspect edge-avoidance/re-anchoring before concluding the vertical control is inverted.
- If the right-edge border crowds the `Power` label, adjust the right cluster padding separately from the dropdown offsets (`.modules-right` padding/margin and `#custom-power` right padding/margin) so text legibility is fixed without disturbing the dropdown anchor.
- Toolboxes can confirm package names, but host package reality is determined by `rpm-ostree`.
- Flatpak preference does not mean every missing ricing dependency should be forced through Flatpak; many Hyprland helpers are not published there and are poor sandbox fits anyway.
- Wallpaper/theming stacks are often internally inconsistent across forks (`swww`, `hyprpaper`, `wallust`, custom scripts). Do not rewrite to a new backend until the core session boots.
- If a config expects generated files such as wallust outputs, verify those exact files exist or note the gap explicitly.

# Output expectations
When reporting back to the user:
- state clearly whether the repo is compatible, adaptable, or a poor fit
- separate what is already staged from what still needs reboot/verification
- call out any system-level actions you intentionally did NOT take
- give a short next-step list ordered by risk and importance

# Session-specific references
Store one-off package lists, COPR artifact URLs, or repo-specific notes under `references/` when a future revisit is likely.

Current supporting references:
- `references/waybar-bottom-dock-taskbar-compaction.md` — icon-only Waybar dock/taskbar compaction pattern: edit shared `wlr/taskbar` module formatting, tighten `#taskbar button` CSS, widen `#taskbar` only as needed, and verify whether the active `config` is a standalone file or a symlinked layout target before expecting layout-switcher scripts to affect the live bar.
- `references/hyprland-helper-script-syntax-sweep.md` — session-tested pattern for sweeping all Hypr helper scripts with `bash -n` and for fixing self-embedded data blocks that bash still parses after `exit`.
- `references/hyprland-wallpaper-runtime-hardening.md` — example of fixing helper scripts that edited the wrong startup file and assumed optional wallpaper binaries were present.
- `references/hyprland-helper-script-hardening-checklist.md` — session-tested checklist for auditing UserScripts helpers for dependency guards, empty-state handling, focused-monitor assumptions, and post-edit syntax verification.
- `references/hyprland-gdm-portal-session-bootstrap.md` — journal-driven triage for plain GDM Hyprland sessions where `graphical-session.target` stays inactive, portals fail by dependency, and the fix path is to stop forcing targets and move toward `uwsm`.
- `references/hyprland-gui-utils-false-positive.md` — exact pattern for Fedora Hyprland setups that complain about missing "GUI utils" because a helper script uses brittle command/package checks instead of verifying the real installed helper commands.
- `references/hyprland-theme-fallback-hardening.md` — script-level fallback pattern for missing upstream GTK/icon/cursor/Kvantum/qtct assets on Fedora Atomic, using stock themes before widening package-source scope.
- `references/hyprland-copr-artifact-staging.md` — session-tested pattern for validating direct COPR RPM artifacts (repodata, exact URLs, `rpm -Kv`, signing key id) before recommending a narrow rpm-ostree staging command.
- `references/hyprland-wallust-optional-and-qt-support-audit.md` — session-tested pattern for making `wallust` non-fatal in Hyprland helper scripts and for distinguishing `hyprland-qt-support` from `hyprland-qtutils` before recommending installs.
- `references/hyprland-wallust-caller-hardening.md` — follow-up pattern for patching caller scripts that still abort on optional wallust wrapper steps via `set -e`, `|| exit 1`, or `&&` chaining.
- `references/hyprland-rpm-abi-drift-and-sudo-handoff.md` — Fedora Atomic pattern for diagnosing local Hyprland RPM ABI drift, validating replacement COPR artifacts, and handing the final verified `rpm-ostree` command off to a live sudo-capable CLI session.
- `references/hyprland-swaync-css-and-widget-config.md` — journal-driven repair pattern for `swaync` CSS parser errors and missing `widget-config.notifications` stanzas in copied Hyprland rice.
- `references/hyprland-wallust-user-space-install-and-template-migration.md` — user-space wallust v3 install pattern for Fedora Atomic plus template migration, target trimming, and safe output verification.
- `references/hyprland-ricing-cleanup-and-pruning.md` — conservative post-setup cleanup pattern for Hyprland rice: prove references, version-gate compatibility files, and keep functional duplicates/state files unless obsolescence is clear.
- `references/flatpak-gui-autostart-visible-launch.md` — troubleshooting pattern for desktop Flatpak utilities that appear not to launch because a wrapper or app config forces minimized/tray-only startup.
- `references/waybar-vpn-tray-and-passive-items.md` — Waybar cleanup pattern for VPN tray-first apps: remove leftover `network` / `network#speed` fragments, verify DBus `StatusNotifierItem` export, and enable passive tray items when the icon is hidden.
- `references/hyprland-waybar-rofi-desktop-ux-polish.md` — session-tested pattern for turning an intrusive Hyprland rice into a cleaner daily-driver UX: compact rofi power dropdown, bottom-anchored launcher, Waybar dock with pinned apps, wallpaper restore, Super single/double-tap behavior, and Proton VPN minimized autostart verification.
- `references/hyprland-rofi-pinned-super-launcher.md` — narrow pattern for keeping existing Hyprland Super-key timing logic while swapping single-tap behavior to a one-row pinned rofi launcher with search and click-away dismissal.
- `references/hyprland-super-dock-vs-waybar-taskbar-disambiguation.md` — quick check for whether the user's "dock" is the Super-key rofi launcher or a Waybar `wlr/taskbar`, plus the correct file targets for each.

# Overlap note
This overlaps with broader Fedora Atomic and verification skills. If both exist, keep this one focused on desktop ricing / dotfiles adaptation and let the curator consolidate later.
