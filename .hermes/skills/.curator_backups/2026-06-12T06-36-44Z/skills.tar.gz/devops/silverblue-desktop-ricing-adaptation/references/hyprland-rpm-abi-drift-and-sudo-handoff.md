# Hyprland RPM ABI drift and sudo handoff on Fedora Atomic

Use this when a Hyprland rice ships local RPMs that fail on Silverblue/Atomic and the user first asks from a session that cannot complete interactive sudo.

## Durable pattern

1. Treat the first failed `rpm-ostree install` as an ABI triage signal, not a cue to blindly retry.
2. Check the host versions that define the dependency surface:
   - `qt6-qtbase`
   - `hyprland`
   - `hyprutils`
   - `hyprlang`
3. Check missing providers directly with `rpm -q --whatprovides 'lib…so.N()(64bit)'`.
4. If the local RPM wants an unavailable SONAME or mismatched Qt private API, replace the artifact rather than trying to coerce the host.
5. Inspect verified COPR repodata for Fedora-release-matched rebuilds.
6. Download the exact RPMs locally and verify them with `rpm -Kv`.
7. Run `rpm-ostree install -n` against the exact local file set.
8. Only after the dry-run resolves, hand the exact same command to a live sudo-capable CLI session for the real transaction.

## Example mismatch shape

Common failure signatures:
- package requires `libhyprutils.so.N` that no installed or enabled-host package provides
- package requires `libQt6Core.so.6(Qt_6.10_PRIVATE_API)` but the host is on Qt 6.11.x

Interpretation:
- the local RPMs were built for an older Hyprland/Qt stack than the current Atomic host
- the fix is usually a Fedora-release-matched rebuild, not host downgrades

## Reporting pattern

Keep these milestones distinct in the user update:
- artifact compatibility diagnosed
- replacement RPMs downloaded
- digests/signatures checked with `rpm -Kv`
- `rpm-ostree install -n` resolved successfully
- real sudo install still pending or completed in the live session

Do not collapse "dry-run resolved" into "installed."