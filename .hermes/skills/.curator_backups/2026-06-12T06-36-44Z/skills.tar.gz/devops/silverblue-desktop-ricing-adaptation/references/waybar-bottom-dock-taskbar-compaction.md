# Waybar bottom dock / taskbar compaction

Use when a Hyprland/Waybar rice has a bottom dock-like `wlr/taskbar` that wraps to two rows, shows unwanted app names, or feels too wide/noisy.

## What to inspect first
1. Read the active top-level bar config (`~/.config/waybar/config` or the selected file under `~/.config/waybar/configs/`).
2. Confirm the dock really uses `"wlr/taskbar"` in one of the module arrays.
3. Read the shared module bank `~/.config/waybar/Modules`; the taskbar text/icon behavior usually lives there, not in the top-level layout.
4. Read `~/.config/waybar/style.css` for `#taskbar`, `#taskbar button`, and any global button sizing rules.
5. Verify whether `~/.config/waybar/config` is a symlink or a standalone file. Layout switchers such as `~/.config/hypr/scripts/WaybarLayout.sh` often assume `config` is symlinked into `configs/`, but the live setup may be reading a regular copied file instead.

## Minimal working compaction pattern
Shared module change in `~/.config/waybar/Modules`:
- change `"format": "{icon} {name}"` to `"format": "{icon}"`
- lower `"icon-size"` a little (for example 16 -> 14)

CSS change in `~/.config/waybar/style.css`:
- reduce `#taskbar button` left/right padding
- add small horizontal margins if buttons touch
- reduce button `min-width` if present
- widen `#taskbar` only after button compaction if the row still wraps

Example values that worked in this session:
- `icon-size`: `14`
- `#taskbar button` padding-left/right: `2px`
- `#taskbar button` margin: `0 1px`
- `#taskbar button` min-width: `24px`
- `#taskbar` min-width: `820px`

## Verification pattern
1. Run Waybar against the active config and CSS with trace logging to confirm the config still parses.
2. If the user's visible dock may come from an alternate layout file, also test the likely layout file directly (for example `[BOT] Camellia`) instead of assuming the current top-level `config` matches it.
3. Reload the live bar only after the parse check is clean.

## Pitfall
If the user says "bottom dock" but the current `~/.config/waybar/config` is actually a top bar, do not claim the visible dock is fixed everywhere just because the shared `Modules` fragment was updated. Say explicitly that the taskbar behavior is changed globally, but the active live layout may still need to be switched to a bottom-dock config for the user to see it there.
