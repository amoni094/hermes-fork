# Hyprland wallust on Fedora Atomic: user-space install and v3 template migration

Use this when a Hyprland rice already references wallust outputs and the user wants working palette generation on Silverblue/Atomic without broad host changes.

## Situation pattern
- Session is already healthy: Hyprland, Waybar, SwayNC, portal stack are up.
- `wallust` is missing from enabled Fedora repos and absent from Flatpak.
- Existing dotfiles assume wallust-generated files such as:
  - `~/.config/waybar/wallust/colors-waybar.css`
  - `~/.config/rofi/wallust/colors-rofi.rasi`
  - `~/.config/hypr/wallust/wallust-hyprland.conf`
  - `~/.config/swaync/wallust/colors-wallust.css`
- The copied config may still reflect older wallust naming/layout assumptions.

## Recommended install path
1. Install upstream release binary in user space:
   - versioned dir: `~/.local/opt/wallust/<version>/`
   - user-facing symlink: `~/.local/bin/wallust`
2. Verify command resolution and version:
   - `command -v wallust`
   - `wallust --version`
3. Keep this separate from any rpm-ostree work; this is an enhancement-stage user-space tool.

## Config migration pattern
1. Read `~/.config/wallust/wallust.toml` first.
2. Inspect which targets are real and should remain active.
3. For wallust v3, store templates under:
   - `~/.config/wallust/templates/`
4. Create or migrate templates for the components actually present:
   - `colors-waybar.css`
   - `colors-rofi.rasi`
   - `colors-hyprland.conf`
   - `colors-swaync.css`
5. Use v3 Jinja2 variables/filters like:
   - `{{background}}`
   - `{{foreground}}`
   - `{{color0}}` … `{{color15}}`
   - filters such as `strip`, `rgb`, `xrgb`
6. Retarget `wallust.toml` to those local templates and their output files.
7. Remove or disable targets that are unsafe or incomplete.

## Important pitfall: do not overwrite full app configs accidentally
If `wallust.toml` points a template target at a full config file for another tool, verify that the template is meant to generate the whole file.

Concrete example:
- a stale `cava.template = 'colors-cava'` plus `target = '~/.config/cava/config'` is dangerous if the template only emits a color block or if the template file no longer exists
- safer move: remove that target until a real full-file Cava template exists

## Verification sequence
1. Pick a real local wallpaper file.
2. Run:
   - `wallust run -s <wallpaper>`
3. Confirm the exact target files were written.
4. Read back at least one or two outputs to confirm non-empty values and plausible colors.
5. Reload consumers only after generation succeeds, for example:
   - send Waybar reload signal
   - restart `swaync.service`
   - `hyprctl reload`
6. Check logs after reload, especially `journalctl --user -u swaync.service ...`.

## Durable lesson
On Fedora Atomic, the tricky part is usually not obtaining the wallust binary. It is reconciling repo-local expectations with wallust v3 template layout, trimming unsafe targets, and verifying that the generated files are actually the ones consumed by Hyprland, Waybar, Rofi, and SwayNC.
