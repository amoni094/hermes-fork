# Hyprland COPR artifact staging on Fedora Atomic

Use this when a small set of Hyprland enhancement packages is missing from enabled Fedora repos, but you want a narrow, evidence-backed Atomic staging path instead of enabling broad new repos blindly.

## Session pattern
1. Confirm the packages are absent from enabled host repos.
2. Identify an already-referenced or plausibly relevant COPR project.
3. Query the COPR project metadata/API to confirm scope.
4. Inspect live repodata to confirm the exact package names and Fedora release builds exist.
5. Extract exact artifact URLs.
6. Download candidate RPMs and verify with `rpm -Kv`.
7. Separate "artifact verified" from "deployment updated".

## Session-tested example: solopasha/hyprland
COPR project scope returned by API:
- "A collection of Hyprland and related packages"

Confirmed Fedora 44 x86_64 artifacts:
- `swww-0.11.2-1.fc44.x86_64.rpm`
- `hyprsunset-0.3.3-2.fc44.x86_64.rpm`
- `hyprland-qtutils-0.1.5-3.fc44.x86_64.rpm`

Exact URLs captured in-session:
- `https://download.copr.fedorainfracloud.org/results/solopasha/hyprland/fedora-44-x86_64/09585939-swww/swww-0.11.2-1.fc44.x86_64.rpm`
- `https://download.copr.fedorainfracloud.org/results/solopasha/hyprland/fedora-44-x86_64/09645582-hyprsunset/hyprsunset-0.3.3-2.fc44.x86_64.rpm`
- `https://download.copr.fedorainfracloud.org/results/solopasha/hyprland/fedora-44-x86_64/09645565-hyprland-qtutils/hyprland-qtutils-0.1.5-3.fc44.x86_64.rpm`

## Verification outcome recorded in-session
For downloaded `swww` and `hyprsunset` RPMs:
- header SHA256 digest: OK
- payload SHA256 digest: OK
- signing key id observed: `9ffaf9362961581b`
- local verification state: `NOKEY` until the relevant key is imported/trusted on-host

## Interpretation rule
- `rpm -Kv` with OK digests plus a stable signing key id is enough to say the artifact itself is consistent with the referenced COPR build.
- It is NOT enough to say the package is installed.
- On Fedora Atomic, host mutation still requires a real `rpm-ostree install ...` success path and often sudo / policy authorization.

## Recommendation shape
When verification succeeds but install is not possible from the current session, report:
- exact verified URLs
- what was checked (`repodata`, `rpm -Kv`, signing key id)
- that deployment mutation did not occur yet
- the narrowest user-run `sudo rpm-ostree install ...` command worth trying next

## Pitfall avoided
Do not let a vague missing-feature warning push you into globally enabling extra repos before you have:
- checked whether the package is enhancement-only rather than session-critical
- confirmed the package actually exists for the target Fedora release
- verified the exact artifact you plan to stage
