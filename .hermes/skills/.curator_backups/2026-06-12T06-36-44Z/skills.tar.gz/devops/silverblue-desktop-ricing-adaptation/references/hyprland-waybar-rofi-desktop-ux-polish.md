# Hyprland / Waybar / Rofi desktop UX polish on Fedora Atomic

Use when the desktop basically works but the user wants the interaction model cleaned up without replacing the whole rice.

What this session added:
- Prefer small user-local edits in active files (`~/.config/hypr/UserConfigs/...`, `~/.config/waybar/config`, `~/.config/waybar/UserModules`, `~/.config/rofi/...`) rather than swapping to a different upstream preset.
- If the current power action opens an intrusive full-screen `wlogout` view, a compact `rofi -dmenu` power dropdown is a valid end state, not just a fallback.
- When switching to a compact rofi power menu, explicitly set selected-row foreground/background contrast; otherwise wallust/theme colors can make the active entry unreadable.
- Prefer launcher behavior that matches the user’s requested ergonomics instead of the rice default: bottom-anchored app launcher, visible dock/taskbar, and close-on-cancel/click-away behavior.
- For single-key launchers like Super, use a tiny helper script to distinguish single tap vs double tap so one key can open the launcher on single tap and toggle a Hyprland special workspace (desktop) on double tap.
- On Waybar, a bottom dock can be assembled cheaply by combining `wlr/taskbar` in the center with pinned `custom/*` launcher modules on the left and tray on the right.
- Persist wallpaper by restoring the current wallpaper state file at startup (`swww img ~/.config/hypr/wallpaper_effects/.wallpaper_current`) once `swww-daemon` is already guarded elsewhere.
- For Proton VPN Flatpak autostart, set both the app config flag (`start_app_minimized=true`) and the launch flag (`--start-minimized`); the launch wrapper may otherwise override the saved app preference.

Verification pattern used here:
1. Validate Hyprland config with `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf`.
2. Validate Waybar JSON with a real parser before restart.
3. Restart/reload the live components only after syntax passes.
4. For desktop-app autostart behavior, verify both persisted config and actual launch command rather than trusting only one of them.

Files that were typically touched in this shape of task:
- `~/.config/hypr/UserConfigs/UserKeybinds.conf`
- `~/.config/hypr/scripts/Wlogout.sh`
- `~/.config/hypr/scripts/<custom helper>.sh`
- `~/.config/hypr/configs/Startup_Apps.conf`
- `~/.config/waybar/config`
- `~/.config/waybar/UserModules`
- `~/.config/waybar/style.css`
- `~/.config/rofi/config-power-menu.rasi`
- `~/.config/rofi/config-app-launcher.rasi`
- `~/.local/bin/protonvpn-autostart`

Pitfalls:
- Do not assume the app-level minimized preference is sufficient if the wrapper launches the Flatpak without `--start-minimized` (or with conflicting flags).
- Do not patch only the top-level Waybar config if styling or module definitions live in included fragments.
- Do not swap the whole bar preset when the request is only about launch ergonomics; a small two-bar config is easier to verify and revert.
- When editing Hypr keybinds, keep customizations in the user override file and re-run config verification before reload.
