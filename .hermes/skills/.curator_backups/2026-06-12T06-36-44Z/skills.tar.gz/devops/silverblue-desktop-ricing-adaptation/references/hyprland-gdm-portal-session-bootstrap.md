# Hyprland GDM portal/session bootstrap triage on Fedora Atomic

Use this when a copied Hyprland setup launches briefly, black-screens, or drops back to GDM and the logs mention portal/session startup rather than plain config syntax errors.

Observed durable pattern:
- `gdm-wayland-session` launches `/usr/bin/start-hyprland` from the plain `Hyprland` desktop entry.
- The user session then logs repeated:
  - `graphical-session.target - Current graphical user session is inactive`
  - `xdg-desktop-portal.service: Job ... failed with result 'dependency'`
- `start-hyprland` later aborts with `std::system_error` / `Resource deadlock avoided`.
- On Fedora, `xdg-desktop-portal.service` has `Requisite=graphical-session.target` and `After=graphical-session.target`.
- On Fedora, `graphical-session.target` is `RefuseManualStart=yes`, so `systemctl --user start graphical-session.target` is refused and is not a valid fix.

What to do first:
- Keep only the safe environment export/import lines in Hyprland startup config:
  - `dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP`
  - `systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP`
- Do not add startup hacks that manually start:
  - `graphical-session.target`
  - `xdg-desktop-portal.service`
  - `xdg-desktop-portal-hyprland.service`
- Re-test after removing those manual-start lines.

Interpretation rule:
- If the plain GDM `Hyprland` session still shows inactive `graphical-session.target`, portal dependency failures, and `Resource deadlock avoided`, stop iterating on `exec-once` nudges.
- Escalate to proper session management instead of forcing systemd user targets from compositor config.

Preferred next step:
- Check whether `/usr/share/wayland-sessions/hyprland-uwsm.desktop` exists.
- If it exists but `uwsm` is not installed, treat `uwsm` installation as the likely fix path.
- After install, reboot and choose `Hyprland (uwsm-managed)` in GDM instead of the plain `Hyprland` entry.

Why this belongs in the playbook:
- It prevents a misleading fix pattern: manually starting `graphical-session.target` or portals from `exec-once`.
- It distinguishes a real session-management problem from optional startup-app failures.
- It points the next effort at the higher-value fix: a managed Hyprland session.

Extra debugging step worth keeping during triage:
- Temporarily enable Hyprland logs with:
  - `debug { disable_logs = false }`
- Remove or relax later if the config intentionally suppresses logs.

Verification standard:
- Do not claim success from config edits alone.
- Require a fresh reboot/login attempt plus post-attempt journal review.
