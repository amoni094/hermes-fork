# Waybar anchored GTK dropdowns

Use this when a top-bar button must behave like a real dropdown under Hyprland/Wayland rather than as a separate popup window.

## Core lesson
If a custom power/menu button needs true dropdown mechanics, prefer Waybar's built-in GTK menu support over launching rofi or a freestanding GTK window.

Working pattern:
- in the module config, replace `on-click` launcher behavior with:
  - `"menu": "on-click"`
  - `"menu-file": "$HOME/.config/waybar/<menu>.ui"`
  - `"menu-actions": [ ... ]`
- define the menu in a GTK `.ui` file with `GtkMenu` and `GtkMenuItem`s
- send actions through a small wrapper script so the UI stays declarative and the behavior stays easy to patch

Why this matters:
- separate GTK popup windows may render, but under Wayland they are not the same thing as an anchored dropdown
- even if a popup looks visually similar, the user may reject it because the mechanics feel wrong
- Waybar's own menu support attaches the popup to the module, which gives the correct dropdown feel

## Placement polish loop
For a dropdown at the far top-right corner, treat placement as a combined geometry problem.

Tune these together:
1. Waybar config
   - `margin-right`
   - `margin-top`
2. Right module group CSS
   - `.modules-right` right padding
   - `.modules-right` right margin
   - right-side border radius
3. Trigger module CSS
   - `#custom-power` right padding
   - `#custom-power` right margin
   - right-side border radius
4. Menu CSS
   - `menu { margin-top: ...; margin-right: ...; }`
   - use small negative `margin-right` if the menu is still too far left
   - use a small positive `margin-top` if the menu is slightly too high; small negative if too low
5. GTK menu hints
   - `halign=end` in the `.ui` file can help signal right-edge alignment

Practical lesson from this session:
- the first visually acceptable dropdown still failed the user's placement requirement
- the fix was not another launcher swap; it was iterative right-edge and vertical offset tuning in Waybar CSS
- expect a final micro-adjust pass measured in only a few pixels

## Styling pattern
To make the dropdown match the top toolbar capsule, style GTK menu widgets in `style.css` using the same theme variables as Waybar:
- `menu`
- `menuitem`
- `menuitem:hover`
- `separator`

Good defaults:
- background from `@theme_base_color`
- border from `@blue`
- text from `@foreground`
- hover from `@surface0`

## Anti-pattern to avoid
Do not keep escalating from rofi to a custom freestanding GTK popup if the user's complaint is specifically that it is not a real dropdown. Once the mechanics complaint is clear, move to Waybar's built-in menu path.
