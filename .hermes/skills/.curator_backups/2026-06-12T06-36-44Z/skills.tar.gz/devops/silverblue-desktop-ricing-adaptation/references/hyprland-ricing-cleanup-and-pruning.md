# Hyprland ricing cleanup and pruning

Use this after a big adaptation pass when the config tree has accumulated backups, compatibility fragments, generated outputs, and near-duplicates.

## Safe cleanup sequence
1. Restrict inspection to the ricing surface first:
   - `~/.config/hypr`
   - `~/.config/waybar`
   - `~/.config/rofi`
   - `~/.config/swaync`
   - `~/.config/wallust`
   - `~/.config/qt5ct`
   - `~/.config/qt6ct`
2. Search for:
   - backup-like names: `*.bak`, `*.old`, `*.orig`, `*.disabled`, `*backup*`
   - exact duplicate content groups
   - large hidden wallpaper/state files
3. For every candidate, verify references in:
   - `hyprland.conf` include/source lines
   - helper scripts under `scripts/` and `UserScripts/`
   - Waybar/Rofi/SwayNC/wallust configs
4. Check runtime version gates before pruning compatibility fragments.
5. Delete only files that are both:
   - unreferenced in the live tree
   - obsolete for the current runtime
6. Re-run searches after deletion and confirm the surviving source-of-truth files still exist.

## Session-tested examples

Safe removals when Hyprland is already new enough:
- `~/.config/hypr/configs/WindowRules-pre-53.conf`
- `~/.config/hypr/v2.3.20`

Why they were safe:
- live Hyprland version was `0.55.2`
- no live references were found for either path
- current rule source remained present:
  - `~/.config/hypr/configs/WindowRules.conf`
  - `~/.config/hypr/configs/WindowRules-config-v3.conf`

## Important non-removals

Do not remove just because they look redundant:
- `~/.config/hypr/wallpaper_effects/.wallpaper_current`
- `~/.config/hypr/wallpaper_effects/.wallpaper_modified`
- `~/.config/rofi/.current_wallpaper`

Reason:
- these may be active state shared by wallpaper selectors, SDDM wallpaper sync, rofi previews, and theme scripts

Do not remove exact duplicates blindly:
- `~/.config/hypr/hyprlock.conf`
- `~/.config/hypr/hyprlock-2k.conf`

Reason:
- byte-identical now, but the path names may still serve manual preset switching or monitor-specific workflows

Do not collapse active target + default source pairs:
- `~/.config/hypr/UserConfigs/UserAnimations.conf`
- `~/.config/hypr/animations/00-default.conf`

Reason:
- current equality does not mean redundancy; one can be the mutable active target while the other is the default seed/source

Do not treat template/rendered wallust pairs as duplicates:
- `~/.config/wallust/templates/...`
- rendered files under app-specific config dirs

Reason:
- placeholders and generated outputs are intentionally different roles, even when filenames are similar

Do not treat same-content Qt theme files as waste:
- `~/.config/qt5ct/colors/wallust.conf`
- `~/.config/qt6ct/colors/wallust.conf`

Reason:
- separate toolkits expect separate lookup paths

## Cleanup rule of thumb
Exact duplication is only a deletion signal when the file path itself does not encode a separate role.