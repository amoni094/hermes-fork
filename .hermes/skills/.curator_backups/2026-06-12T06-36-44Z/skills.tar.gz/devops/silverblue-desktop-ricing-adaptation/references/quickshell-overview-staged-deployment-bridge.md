# Quickshell overview on Silverblue before reboot

Use when a Hyprland rice expects Quickshell/`qs` for overview/dock behavior, `rpm-ostree install quickshell` has staged the package, but the current live deployment has not rebooted yet.

## Durable pattern
1. Verify the package path problem before rewriting launcher logic:
   - `command -v qs`
   - `command -v quickshell`
   - if absent, check the staged deployment under `/sysroot/ostree/deploy/.../usr/bin/quickshell`
2. Keep the user's existing Hyprland Super-key wrapper when possible; restore the overview backend rather than replacing the whole binding model.
3. Create a narrow user-space wrapper such as `~/.local/bin/qs` that:
   - prefers `/usr/bin/quickshell` after reboot
   - falls back to the staged deployment binary in `/sysroot/ostree/deploy/.../usr/bin/quickshell` for current-session verification
   - exits clearly if neither path exists
4. Put the overview config where Quickshell expects it:
   - `~/.config/quickshell/overview/`
   - include `shell.qml` plus `config.json`
5. Use user startup overlays for autostart instead of editing vendor defaults directly. Example Hyprland pattern:
   - `exec-once = sh -lc 'command -v qs >/dev/null && qs -c overview -n -d'`
6. For toggle actions, prefer the project-documented IPC path:
   - `qs ipc -c overview call overview toggle`
7. If the current rice uses optional overview on double-tap Super, make the overview toggle fail quietly when the backend is absent so single-tap dock behavior still feels correct.
8. Re-verify:
   - `bash -n` on touched shell wrappers
   - `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf`
   - start Quickshell once against the config and confirm logs show `Configuration Loaded`

## Why this matters
On Silverblue/Atomic, the package can be correctly staged yet still missing from the live PATH until reboot. The durable lesson is to bridge the staged deployment for verification, not to conclude Quickshell is unsupported or to redesign the keybinding workflow prematurely.

## Notes
- Non-fatal Quickshell warnings about portals, blank colors, or fallback icons are not the same as a failed overview launch.
- After reboot, `/usr/bin/quickshell` should become the normal path and the wrapper naturally collapses to the native binary.
