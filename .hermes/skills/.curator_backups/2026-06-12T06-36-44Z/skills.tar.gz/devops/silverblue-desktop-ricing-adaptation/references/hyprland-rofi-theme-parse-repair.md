# Hyprland rofi dock launcher: theme-parse repair

Use this when the Super/Windows key is already bound to a dock/pinned-app launcher script, but pressing it shows a rofi error instead of the launcher.

## Symptom shape
- Hyprland bind is already correct (for example `bindr = $mainMod, SUPER_L, exec, $scriptsDir/SuperLauncher.sh`).
- The wrapper script is tiny and just execs a pinned launcher script.
- The pinned launcher script itself syntax-checks cleanly with `bash -n`.
- The visible failure is a rofi error when the launcher opens.

## High-yield checks
1. Verify the active Super binding before editing it.
2. Read the wrapper script and the real launcher payload script.
3. Syntax-check the scripts with `bash -n`.
4. Validate the rofi theme directly instead of guessing:
   - `rofi -no-config -theme ~/.config/rofi/config-app-launcher.rasi -dump-theme`
   - if stderr shows `Failed to parse theme`, fix the theme before touching Hyprland binds
5. Verify the launch targets referenced by the pinned launcher:
   - check that each desktop id exists under `/usr/share/applications`, `~/.local/share/applications`, `/var/lib/flatpak/exports/share/applications`, or `~/.local/share/flatpak/exports/share/applications`
6. Re-run Hyprland config verification after the repair:
   - `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf`

## Durable lesson
Treat `Super opens rofi error` as a launcher-theme validation problem before treating it as a Hyprland keybind or script-routing problem.

## Rofi 2.0 theme parser pitfall
On rofi 2.0.0, a compact power-menu or dock theme can fail to parse even when the surrounding Hyprland bind and shell wrapper are correct.

High-yield suspect:
- `alpha(@color, 95%)` / `alpha(@background-color, 94%)` style expressions inside `.rasi`

Safe repair pattern:
- validate with `rofi -no-config -theme <theme> -dump-theme`
- if parse fails, replace the `alpha(...)` expressions with known-good fixed colors first (for example `#1A191Dea` or another explicit RGBA hex)
- re-run the dump check before touching Hyprland bindings or launcher scripts

Practical rule:
- when the only visible symptom is `Failed to parse theme`, prefer a minimal valid color substitution over a larger launcher redesign

## Safe repair pattern
If the dock theme is broken and the original syntax problem is not obvious, replace it with a minimal known-good one-row rofi theme first, then iterate on styling later.

Useful properties for the fallback dock:
- bottom anchored window
- `lines: 1`
- `columns` equal to pinned app count ceiling
- icons enabled
- hidden element text for icon-first dock behavior
- click-away dismissal enabled

## Evidence from this session
- Hyprland config was valid.
- `SuperLauncher.sh` and `PinnedLauncher.sh` were valid.
- The failure was the rofi theme file `~/.config/rofi/config-app-launcher.rasi`.
- Replacing it with a simpler valid theme restored the dock launcher path without changing the binding.