# Hyprland helper script hardening checklist

Use this when a third-party Hyprland config already has guarded `exec-once` lines, but user-triggered helpers under `UserScripts/` or similar can still fail noisily on first boot.

## Goal
Turn optional desktop helpers into clean degradations instead of noisy breakage.

## Audit order
1. Wallpaper helpers
   - selectors
   - randomizers
   - effects menus
   - auto-rotation scripts
2. Rofi wrappers
   - calculator
   - music picker / radio launcher
   - theme switchers
3. Dispatch helpers
   - scripts that call `hyprctl`, `jq`, or workspace/window matching logic

## What to check
- Required commands are validated before first use.
- Missing dependency exits are early and quiet, preferably with `notify-send` plus stderr.
- Content directories are checked for emptiness before opening a picker or iterating files.
- Generated state files are checked before reading them.
- Focused-monitor detection is validated before calling `swww` or other monitor-targeted commands.
- Config/theme paths passed to rofi are quoted.
- Scripts that launch command strings use a shell entrypoint (`bash -lc "$APP"`) when the variable may contain more than a bare executable name.
- File iteration is narrowed to expected media types instead of traversing arbitrary files.

## Session-tested examples
- `WallpaperAutoChange.sh`
  - exit if no focused monitor
  - exit if target wallpaper directory has no image files
  - iterate only image files
- `RofiCalc.sh`
  - require `rofi`, `qalc`, and `wl-copy`
  - quote the rofi theme path
- `RofiBeats.sh`
  - require `rofi` and `mpv`
  - exit cleanly when `~/Music` has no playable files
- `ZshChangeTheme.sh`
  - require `rofi`
  - exit cleanly if `~/.oh-my-zsh/themes` is missing or empty
- `Tak0-Autodispatch.sh`
  - require `hyprctl` and `jq`
  - use `bash -lc "$APP"` for launch strings

## Verification
Run syntax checks immediately after patching:
- `bash -n <script>`

For a batch:
- `bash -n script1 && bash -n script2 && ...`

## Scope note
This pattern is for user-space resilience before first reboot/login verification. It is not a substitute for installing the real runtime dependencies later.