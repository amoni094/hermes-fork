# Hyprland rofi pinned Super launcher

Use when a Hyprland rice already has Super-key helper scripts and the user wants a cleaner dock-like launcher instead of a generic app grid.

Session-tested pattern:
- inspect the active `SUPER_L` binding first; many configs already route it through a helper such as `SuperLauncher.sh`
- preserve any existing single-vs-double-tap timing logic instead of replacing the whole keybinding model
- change only the single-tap action to call a dedicated pinned-launcher script
- leave the broad launcher on its own shortcut (for example `Super+D`) unless the user asked to remove it
- build the pinned app list from verified desktop entry ids
- for a dock feel in rofi, use a bottom-anchored layout with `lines: 1` and `columns` set to the pinned-item ceiling
- keep the search bar visible so the launcher stays minimal but searchable
- make the launcher dismiss on focus loss / outside click so it behaves like a lightweight dock popup
- syntax-check every edited helper with `bash -n`
- verify each pinned desktop id exists before claiming success

Pinned-app verification checklist:
- Firefox: `org.mozilla.firefox.desktop`
- Files: `org.gnome.Nautilus.desktop`
- Kitty: `kitty.desktop`
- Proton VPN: `com.protonvpn.www.desktop`
- Settings: `org.gnome.Settings.desktop`
- Writer: `org.libreoffice.LibreOffice.writer.desktop`
- Obsidian: `md.obsidian.Obsidian.desktop`
- VS Code: `com.visualstudio.code.desktop`
- Software: `org.gnome.Software.desktop`
- Thunderbird: `net.thunderbird.Thunderbird.desktop`
- Telegram: `org.telegram.desktop.desktop`
- VLC: `org.videolan.VLC.desktop`

Why this pattern is durable:
- it preserves the rice's existing keyboard UX
- it limits change scope to launcher content and layout
- it avoids fragile rewrites of unrelated Hyprland bindings
- it gives the user both a curated dock and a separate full launcher path
