# Hyprland wallust optionalization and Qt support audit

Use this reference when a Fedora Atomic Hyprland rice keeps insisting that optional theming helpers are missing, or when the config mentions `org.hyprland.style` and it is unclear which package actually provides it.

## Session-tested findings

### 1) Make wallust optional in user-local helpers
If `wallust` is absent, do not let wallpaper/theme scripts abort the whole flow.

Prefer this pattern:
- required: `hyprctl`, `swww`, `swww-daemon`, `jq`, `magick` only where each is truly required
- optional: `wallust`
- funnel palette regeneration through a wrapper like `WallustSwww.sh` that exits 0 when prerequisites are missing
- replace hard failures like:
  - `require_or_notify wallust ...`
  - `wallust run ... || exit 1`
  with:
  - guarded `command -v wallust` checks, or
  - `WallustSwww.sh ... || true`

Good targets to audit first:
- `DarkLight.sh`
- `WallpaperAutoChange.sh`
- `WallpaperRandom.sh`
- `WallpaperSelect.sh`
- `WallpaperEffects.sh`
- `GameMode.sh`
- `Refresh*.sh`

Verification step:
- run `bash -n` on every edited shell script

### 2) Distinguish hyprland-qt-support from hyprland-qtutils
Do not assume `hyprland-qtutils` provides the Qt Quick Controls style plugin.

Observed package contents from verified COPR RPMs:
- `hyprland-qt-support` provides `org/hyprland/style` QML assets and shared libraries
- `hyprland-qtutils` provides utility executables such as:
  - `hyprland-dialog`
  - `hyprland-donate-screen`
  - `hyprland-update-screen`

Practical rule:
- if the config only sets `QT_QUICK_CONTROLS_STYLE=org.hyprland.style`, the needed package is `hyprland-qt-support`
- if that package is not installed, comment out the env var rather than claiming `hyprland-qtutils` is required
- treat `hyprland-qtutils` as optional unless the config or scripts actually invoke its binaries

### 3) Prefer narrow COPR artifact verification over broad repo enablement
For Silverblue/Atomic:
- inspect COPR repodata directly
- confirm the exact Fedora release build exists
- verify downloaded RPMs with `rpm -Kv`
- record the signing key id and digest result
- keep verification separate from installation if `rpm-ostree` mutation is sudo- or D-Bus-gated in the session

### 4) What not to do
- do not keep chasing a vague "GUI utils" package name after command-level checks already passed
- do not force wallust installation from an unverified source just to suppress optional-theme warnings
- do not leave `QT_QUICK_CONTROLS_STYLE=org.hyprland.style` enabled when the style provider package is absent
