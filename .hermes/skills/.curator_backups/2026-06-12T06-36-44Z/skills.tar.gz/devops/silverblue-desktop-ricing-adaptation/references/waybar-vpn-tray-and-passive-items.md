# Waybar VPN tray cleanup on Hyprland / Fedora Atomic

Problem pattern:
- User wants ProtonVPN or another tray-first VPN app represented by its tray icon, not by a separate network widget.
- Waybar still shows ugly interface-derived text such as `ipv6leakintrf0` or similar.
- The VPN app is running, but the tray icon still does not appear.

What to verify:
1. Confirm the app is actually exporting a tray item on DBus.
   - Look for `StatusNotifierItem` ownership, e.g. ProtonVPN exporting something like `com.protonvpn.www.StatusNotifierItem-*`.
2. Confirm Waybar is hosting the KDE status notifier watcher/host.
   - Typical names: `org.kde.StatusNotifierWatcher` and `org.kde.StatusNotifierHost-*`.
3. Re-read all active Waybar fragments, not just the top-level `config`.
   - `config`
   - `Modules`
   - `ModulesGroups`
   - `ModulesCustom`

Durable fix pattern:
- Remove `network` from `modules-right` when the user wants tray-only VPN presence.
- Also remove `network#speed` from any active group fragments such as `group/motherboard` or drawer variants; this is a common place for leftover interface text.
- Enable passive tray items in Waybar when the app exports a notifier item but no icon is shown:
  - `"show-passive-items": true`
- Keep spacing tight by adjusting both:
  - top-level Waybar `spacing`
  - tray `spacing`
  - surrounding module margins in CSS
- If brightness is clutter, remove `backlight` from the active group instead of only changing its display format.

Why this matters:
- A VPN app can be healthy and exporting a tray icon while Waybar still hides it because the item is passive.
- Separately, a leftover grouped `network#speed` module can keep surfacing tunnel/interface-derived labels even after the main `network` widget is removed.

Good report-back shape:
- Say whether the tray item exists on DBus.
- Say whether Waybar is hosting the notifier watcher.
- Say exactly which fragments still referenced `network` / `network#speed`.
- Distinguish `app not running` from `tray icon exported but hidden`.
