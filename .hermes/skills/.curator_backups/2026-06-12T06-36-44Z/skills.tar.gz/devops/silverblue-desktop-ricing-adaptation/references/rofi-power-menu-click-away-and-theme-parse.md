# Rofi power menu: parse repair + click-away dismissal

Use this when a Hyprland/Waybar power button launches a rofi-based power menu that either throws a visible rofi error or refuses to dismiss when clicking outside.

## High-yield triage
1. Find the real launcher script (commonly something like `~/.config/hypr/scripts/Wlogout.sh`) and read the exact rofi invocation.
2. Read the active power-menu theme file (commonly `~/.config/rofi/config-power-menu.rasi`).
3. Validate the theme directly before changing bindings or scripts:
   - `rofi -no-config -theme ~/.config/rofi/config-power-menu.rasi -dump-theme`
4. If rofi reports `Failed to parse theme`, inspect for unsupported expressions before blaming the launcher logic.

## Durable rofi 2.0 pitfall
On rofi 2.0, theme expressions like:
- `alpha(@background-color, 94%)`
- `alpha(@color0, 95%)`
can fail to parse in some copied rice themes.

Repair pattern:
- replace the `alpha(...)` expressions with concrete colors
- then re-run `rofi -no-config -theme <theme> -dump-theme`

Example safe substitutions from this session:
- window background -> `#1A191D`
- selected row background -> `#404044`
- selected text -> `#f5f5f5`
- border -> `#89b4fa`

## Click-away dismissal rule
If the menu only closes with Esc and ignores outside clicks, inspect the launcher flags.

For a small dropdown-style power menu:
- keep `-click-to-exit`
- remove `-normal-window`
- remove `-steal-focus`

Reason:
- `-normal-window` / `-steal-focus` can make the menu behave like a regular focused window instead of a transient click-away popup.

## Styling alignment pattern
When the goal is to visually match a Waybar top-right module cluster:
- reuse the same font family as Waybar
- prefer the same weight/size class (for example JetBrainsMono Nerd Font Bold 10 when the bar is bold JetBrainsMono)
- set selected text to a light color for readability on dark highlight rows
- keep the menu compact and top-right anchored if it acts like a toolbar dropdown

## Verification
1. `bash -n` the launcher script after edits.
2. `rofi -no-config -theme <theme> -dump-theme` must succeed.
3. If Hyprland config was touched indirectly, re-run `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf`.
4. Live-check that clicking outside dismisses the menu.
