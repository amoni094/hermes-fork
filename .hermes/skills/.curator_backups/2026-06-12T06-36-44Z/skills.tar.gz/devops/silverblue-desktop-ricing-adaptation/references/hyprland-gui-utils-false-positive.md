# Hyprland "GUI utils" false-positive on Fedora Silverblue

Use this when a Hyprland dotfiles setup claims GUI utilities are missing even though helper apps are installed.

What happened
- The user-facing warning came from `~/.config/hypr/scripts/Kool_Quick_Settings.sh`, launched from `SUPER+SHIFT+E` via `~/.config/hypr/configs/Keybinds.conf`.
- The script checked helper commands directly and emitted "Install ... first" notifications.
- Fedora did not provide a package named `hyprland-qtutils`, but the practical GUI helper commands were already present.

Verified helper commands/packages
- `/usr/bin/nwg-displays` -> `nwg-displays`
- `/usr/bin/nwg-look` -> `nwg-look`
- `/usr/bin/qt5ct` -> `qt5ct`
- `/usr/bin/qt6ct` -> `qt6ct`
- `/usr/bin/kvantummanager` -> `kvantum`

Durable troubleshooting pattern
1. Verify the actual helper commands on PATH before chasing package names.
2. Search keybinds and helper scripts to find the exact launcher or notification source.
3. Patch the helper script to be robust in minimal session environments:
   - normalize PATH early (`/usr/bin:/usr/local/bin:${PATH:-}`)
   - use a reusable launcher helper that tries command names and only notifies on true absence
4. Run `bash -n` after shell-script edits.

Concrete patch pattern
```bash
export PATH="/usr/bin:/usr/local/bin:${PATH:-}"

run_gui_helper() {
    local label="$1"
    shift
    local cmd
    for cmd in "$@"; do
        if command -v "$cmd" >/dev/null 2>&1; then
            "$cmd"
            return 0
        fi
    done
    notify-send -i "$iDIR/error.png" "E-R-R-O-R" "$label is not installed or not on PATH"
    return 1
}
```

Then replace repeated blocks like:
- `command -v nwg-look ...`
- `command -v qt6ct ...`
- `command -v qt5ct ...`
- `command -v nwg-displays ...`

with:
- `run_gui_helper "nwg-look" nwg-look`
- `run_gui_helper "qt6ct" qt6ct`
- `run_gui_helper "qt5ct" qt5ct`
- `run_gui_helper "nwg-displays" nwg-displays`

Key lesson
- On Fedora Atomic desktops, a missing distro-specific package name is weaker evidence than a present executable. Prefer command-level verification and patch the checker when the tools exist.