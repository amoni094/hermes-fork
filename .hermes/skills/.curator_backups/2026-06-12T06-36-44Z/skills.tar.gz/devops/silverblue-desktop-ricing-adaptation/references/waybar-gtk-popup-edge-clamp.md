# Waybar GTK popup edge clamp and top-right micro-tuning

Use when a Waybar built-in GTK menu (for example a power dropdown) is visually attached to the top-right cluster and small requested nudges behave unpredictably.

## Symptom pattern
- The user asks for a tiny vertical move like `1px down`.
- A recent horizontal move pushed the popup farther toward the physical right edge.
- The next reload makes the menu appear to jump up or re-anchor instead of following the requested nudge.

## Root cause
GTK/Waybar popup menus are kept on-screen. Near the top-right screen edge, larger horizontal shifts can trigger edge-avoidance / re-anchoring. When that happens, the visible movement is no longer a simple reading of `margin-top` / `margin-right`, so a tiny follow-up change can appear to move the popup in the wrong direction or by a much larger amount.

## Durable workflow
1. Do not assume the vertical control is inverted.
2. If a tiny vertical request causes a large jump after a horizontal move, suspect edge clamp first.
3. Undo or reduce the last aggressive horizontal shift.
4. Re-establish a stable baseline where the popup is comfortably on-screen.
5. Prefer moving the module anchor first (`#custom-power` or the right-edge cluster) instead of pushing the popup itself off the screen edge.
6. Once the anchor is stable, do one-axis micro-tuning on the popup CSS only:
   - vertical: `menu { margin-top: ... }`
   - horizontal: `menu { margin-right: ... }`
7. Keep the user-facing loop terse and explicit about direction mapping before each patch.

## Safer tuning pattern
For a top-right Waybar power menu:
- keep `menu { margin-right: 0px; }` or near-zero while finding the stable anchor
- shift the anchor with `#custom-power { margin-right: ... }` and, if needed, `.modules-right` spacing
- once the popup opens in the right neighborhood without re-anchoring, use 1-5px menu nudges

## Verification
- Read back the live CSS after every patch.
- Reload the running Waybar instance.
- If mechanics were recently changed, run `waybar -c ... -s ... -l trace` first and only then continue geometry tuning.

## Session note
In this session, a requested `1px down` appeared to move the popup sharply upward because the prior `20px right` style push had likely tripped GTK edge-avoidance. The reliable recovery was to stop fighting the screen edge directly, reset the popup horizontal offset, and move the anchor instead.
