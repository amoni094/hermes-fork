# Hyprland theme-fallback hardening on Fedora Atomic

Problem shape:
- Upstream Hyprland dotfiles assume non-stock theme assets (for example Flat-Remix, Bibata, Catppuccin Kvantum/qtct files).
- On a Silverblue/Fedora Atomic host, those assets may be absent even when Hyprland itself is healthy.
- Startup/theme scripts then fail noisily or leave the user with misleading "something is broken" symptoms.

What worked:
1. Read the actual startup/theme scripts rather than guessing from the README.
2. Extract the exact expected asset names from variables in the scripts.
3. Check both user-local and system theme locations before changing package sources:
   - `~/.themes`
   - `~/.icons`
   - `~/.config/Kvantum`
   - `/usr/share/themes`
   - `/usr/share/icons`
   - `/usr/share/Kvantum`
4. Patch user-local scripts to fall back to stock installed themes:
   - GTK/icons -> `Adwaita`
   - cursor -> `Adwaita` if the preferred cursor theme is absent
   - Kvantum -> `KvDark` (or `KvGnome` for light mode)
5. In dark/light switchers, only edit `qt5ct.conf`, `qt6ct.conf`, or color-scheme paths if those files actually exist.
6. Syntax-check every edited shell script with `bash -n`.

Durable lesson:
- For Atomic ricing work, missing theme assets are usually enhancement gaps, not evidence the desktop install failed.
- Prefer graceful degradation in `~/.config/hypr` scripts before widening scope to new repos/COPRs or source builds.

Related runtime gaps often found in the same pass:
- `swww`
- `wallust`
- `hyprsunset`

Treat those as optional enhancement-stage dependencies unless the current session actually requires them for a usable desktop.
