# Flatpak GUI autostart visible-launch triage

Use when a desktop utility on Fedora Atomic/Hyprland is reported as "not launching" but is started via Flatpak plus a user service or wrapper.

## Pattern
A visible window may be suppressed by either:
- wrapper flags such as `--start-minimized`
- the app's own persisted config (`start_app_minimized`, tray-only start, auto-start hidden)
- duplicate launch paths where a desktop file and a user service race each other

## Triage checklist
1. Identify the chosen source of truth:
   - `~/.config/systemd/user/*.service`
   - `~/.config/autostart/*.desktop`
   - helper/wrapper under `~/.local/bin/`
2. Inspect the exact Flatpak invocation:
   - app id
   - command override
   - visibility flags (`--start-minimized`, `--background`, etc.)
3. Read the app's live config under `~/.var/app/<app-id>/config/...` and align it with the intended launch mode.
4. If a user service is authoritative, disable duplicate desktop autostart entries instead of leaving both active.
5. Syntax-check edited wrappers with `bash -n`.
6. Restart the user service and verify all three layers:
   - config on disk reflects visible launch
   - process is alive (`flatpak ps`, process list)
   - recent logs show a steady-running app rather than a crash loop
7. Only after process-level verification, investigate Hyprland workspace/focus/tray behavior.

## Session example distilled
- App process existed, but the launcher and config both forced minimized startup.
- Fix was to remove the minimized CLI flag and set the app config's minimized key to false.
- Verification depended on process/runtime evidence, not just whether a window was immediately obvious.

## Durable rule
For tray-oriented VPN/chat/sync apps, treat "no visible window" as a two-branch problem:
1. hidden/minimized launch path
2. real startup failure

Prove which branch you are in before changing compositor behavior or blaming Flatpak.
