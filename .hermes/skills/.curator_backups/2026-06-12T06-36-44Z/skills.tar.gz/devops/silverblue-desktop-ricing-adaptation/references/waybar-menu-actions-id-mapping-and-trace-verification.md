# Waybar menu-actions id mapping and trace verification

Use when a built-in Waybar GTK menu appears, but clicking menu items does nothing.

Observed durable pattern on Waybar v0.15:
- `menu-file` points to a GtkBuilder XML with a `GtkMenu` id `menu`
- each clickable `GtkMenuItem` has its own id, e.g. `lock`, `suspend`, `logout`, `reboot`, `shutdown`
- `menu-actions` must map those ids to commands

Working shape:

```jsonc
"custom/power": {
  "format": "Power",
  "menu": "on-click",
  "menu-file": "$HOME/.config/waybar/power-menu.ui",
  "menu-actions": {
    "lock": "$HOME/.config/hypr/scripts/PowerAction.sh lock",
    "suspend": "$HOME/.config/hypr/scripts/PowerAction.sh suspend",
    "logout": "$HOME/.config/hypr/scripts/PowerAction.sh logout",
    "reboot": "$HOME/.config/hypr/scripts/PowerAction.sh reboot",
    "shutdown": "$HOME/.config/hypr/scripts/PowerAction.sh shutdown"
  }
}
```

Failure shape that can still look visually "fine":
- `menu-actions` supplied as a positional array
- separators represented by empty strings in the action list

Symptom signature during verification:
- `waybar -c ~/.config/waybar/config -s ~/.config/waybar/style.css -l trace`
- repeated GLib/GObject messages like:
  - `invalid (NULL) pointer instance`
  - `g_signal_connect_data: assertion 'G_TYPE_CHECK_INSTANCE (instance)' failed`

Repair workflow:
1. Read the live `menu-file` XML and capture the exact `GtkMenuItem` ids.
2. Convert `menu-actions` from any positional array into an object keyed by those ids.
3. Re-run `waybar ... -l trace` and confirm the GLib/GObject menu-binding errors disappear.
4. Reload the live Waybar process.
5. Only after the mechanics are fixed, continue the visual polish pass for `.modules-right`, `#custom-power`, and `menu` CSS offsets.

Placement note from this session:
- a stale large `menu { margin-right: 71px; }` can leave the dropdown visibly detached from the top-right toolbar cluster even when the menu mechanics are otherwise correct
- tightening all three together worked better than moving only the popup: `.modules-right` right margin/padding, `#custom-power` right margin/padding, and `menu` right/top margins

This is a mechanics-first debugging pattern: fix action wiring before spending time on pixel alignment.
