# Hyprland Super launcher: pinned dock + double-tap overview without regressions

Use this when a Hyprland rice binds `SUPER_L` to a helper script and the user wants:
- single tap Super -> pinned/searchable rofi dock
- double tap Super -> overview/workspace action
- no noisy failure if optional overview backends are missing

## Failure pattern from this session
A first implementation used an inline background subshell to delay the single-tap launcher. In practice the user reported:
- double tap surfaced an AGS/Quickshell error popup
- single tap stopped showing the dock reliably

The durable lesson was not the exact error text. It was the control-flow fix:
- detached delayed launch for single tap
- pending-state file to suppress the delayed launch if a second tap arrives
- quiet failure for optional overview helpers

## Safer pattern

### 1) Keep the live bind and wrapper structure
Verify the active binding first and preserve the existing route if possible:
- user override file
- actual `bindr`/`bind` for `SUPER_L`
- wrapper script path

Do not redesign the whole binding tree if the real issue is launcher control flow or a broken rofi theme.

### 2) Use a runtime state directory
Store transient state under `${XDG_RUNTIME_DIR:-/tmp}`.
Recommended files:
- `last-tap-ms`
- `pending`

These are enough for a simple two-path state machine.

### 3) Double tap path
On each invocation:
1. read `last-tap-ms`
2. compare current time against a threshold such as 320ms
3. if inside the threshold:
   - remove the `pending` marker
   - reset or overwrite the last-tap marker
   - close rofi if needed
   - run the overview helper

Important:
- the overview helper should return non-zero quietly if AGS/Quickshell is absent
- do not notify on every miss when the overview backend is optional

### 4) Single tap path
If not a double tap:
1. write current timestamp to `last-tap-ms`
2. write the same timestamp to `pending`
3. spawn a detached shell (`nohup bash -lc '...' >/dev/null 2>&1 &`)
4. inside the detached shell:
   - sleep for the threshold window
   - re-read `pending`
   - only launch the pinned dock if the pending value still matches the original timestamp
   - remove the pending marker before launch

Why detached matters:
- with `bindr`/release-triggered wrappers, an inline delayed background subshell can be fragile in real desktop use
- a detached helper process makes the single-tap launch independent from the original keybinding process lifetime

## Minimal behavior contract
- single tap opens the dock after a short delay
- second tap inside threshold suppresses the dock and triggers overview
- if overview support is missing, the user should not get repeated noisy popups just for trying the shortcut
- rofi can still be closed normally without poisoning the next tap

## Verification
After changes:
1. `bash -n` every touched script
2. `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf`
3. confirm the active binding still points to the wrapper you edited
4. test both user-visible paths:
   - single tap shows dock
   - double tap does not launch dock first

## Pitfalls
- Do not infer that AGS/Quickshell is available just because the rice ships an `OverviewToggle.sh`.
- Do not leave a `notify-send` failure path in an optional overview helper bound to a frequently used key.
- Do not assume `PinnedLauncher.sh` is broken if the dock stops appearing after timing changes; the regression may be in the tap-control wrapper.
- Do not replace the whole Super-key design when the root cause is a broken rofi theme or a fragile delay mechanism.
