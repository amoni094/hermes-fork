# Waybar popup vs toolbar-anchor separation

Use this when a user is visually micro-tuning a top-right Waybar dropdown and says the wrong thing moved.

Core distinction:
- `#custom-power` and `.modules-right` change the visible toolbar anchor/capsule at the top-right.
- `menu` changes the attached GTK dropdown.

Practical workflow:
1. Get the toolbar/capsule flush and visually correct first.
2. Freeze `#custom-power` and `.modules-right` once the user says the toolbar is right.
3. After that, make dropdown-only moves in `menu { margin-top; margin-right; }`.
4. If a requested dropdown move instead shifts the toolbar, revert the anchor change immediately and continue only with `menu`.
5. Near the screen edge, expect GTK edge-clamp/re-anchoring. Large horizontal moves can produce apparent vertical jumps.
6. When that happens, back out the last large horizontal move and resume with 1-5px one-axis steps.
7. If observed movement contradicts CSS sign intuition, trust the live screen and restate the corrected mapping before the next patch.

Good user-facing loop:
- keep replies terse
- say exactly which selector changed
- preserve the already-correct toolbar geometry unless the user explicitly asks to move it again

This is a geometry-polish workflow lesson, not a generic CSS truth: the durable rule is to separate anchor edits from popup edits and to trust empirical movement near screen edges.
