# Hyprland / SwayNC CSS and widget-config repair on Fedora Atomic

Use when a copied Hyprland rice launches `swaync` but journal logs show GTK CSS parser errors or widget fallback messages.

Observed durable pattern:
- `journalctl --user -u swaync.service` reports errors like `Theme parser error: style.css:... Expected a valid selector`
- or repeated warnings like `Expected ';' at end of block`
- or `notifications: Config not found! Using default config...`

What to check:
1. Read the user CSS file actually loaded by swaync, usually `~/.config/swaync/style.css`.
2. Look for malformed selector lists introduced by bad edits or upstream typos, especially stray `,;` sequences such as:
   - `.control-center .notification-row:focus,;`
   - `.notification-default-action:hover,;`
3. Fix the selector list first, then restart `swaync` and re-check the journal.
4. If logs still say `notifications: Config not found! Using default config...`, compare the user config with `/etc/xdg/swaync/config.json` and ensure `widget-config.notifications` exists, for example:

```json
"widget-config": {
  "notifications": {
    "vexpand": true
  }
}
```

5. Restart `swaync` again and verify the log is clean.
6. If the Hyprland session owns related env/theme changes, run `hyprctl reload` after the swaync fix so the session picks up the wider ricing state.

Verification commands:
- `systemctl --user restart swaync.service`
- `journalctl --user -u swaync.service -n 20 --no-pager`
- `hyprctl reload`

Practical rule:
- for notification-center theming issues, trust the live journal over visual guessing
- fix CSS parser errors before chasing theme packages
- when a user config omits a widget stanza that the packaged default includes, merge the minimal missing block instead of replacing the whole config
