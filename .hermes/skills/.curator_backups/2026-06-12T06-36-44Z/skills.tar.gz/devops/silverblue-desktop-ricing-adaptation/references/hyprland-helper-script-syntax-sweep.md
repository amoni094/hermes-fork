# Hyprland helper script syntax sweep on Fedora Atomic

Use this when a Hyprland rice is mostly working but random launchers or quick-settings actions still fail in confusing ways.

## Why this matters
Many Hyprland dotfiles repos ship dozens of shell helpers under paths like:
- `~/.config/hypr/scripts/*.sh`
- `~/.config/hypr/UserScripts/*.sh`

A session can look healthy overall while one helper remains syntactically broken. This produces narrow feature failures that are easy to misdiagnose as missing packages or compositor bugs.

## Session-tested sweep
Run a non-executing syntax pass over every helper script first:

```bash
python - <<'PY'
from pathlib import Path
import subprocess
for p in sorted(Path('~/.config/hypr'.replace('~', __import__('os').path.expanduser('~'))).rglob('*.sh')):
    r = subprocess.run(['bash','-n',str(p)], capture_output=True, text=True)
    print(f'{p}:', 'OK' if r.returncode == 0 else 'FAIL')
    if r.returncode != 0:
        print(r.stderr.strip())
PY
```

## Concrete failure pattern found
A helper may embed a large free-form emoji/data list directly after `exit`. Bash still parses the whole file, so raw data lines can trigger syntax errors even though they look like inert payload.

Example symptom:
- `bash -n ~/.config/hypr/scripts/RofiEmoji.sh`
- failure near a plain data line such as an emoji entry containing `:)` or other shell-significant text

## Durable fix pattern
If a helper script self-extracts embedded data with `sed`/`awk`, wrap the trailing data block inside a quoted no-op heredoc so bash treats it as inert text while the extractor can still read it from the script source.

Pattern:

```bash
sed '1,/^# # DATA # #$/d;/^__DATA_END__$/d' "$0" | ...
exit

: <<'__DATA_END__'
# # DATA # #
...payload lines...
__DATA_END__
```

## Verification
After editing:
1. re-run `bash -n` on the changed helper
2. if practical, run a sweep across all Hypr scripts again
3. keep reporting separate from package audits — syntax failures are a different class of problem

## Interpretation rule
If the session is healthy (`graphical-session.target`, portals, compositor, bar, launcher) but one menu/helper still fails, do a syntax sweep before widening package-source hunts.