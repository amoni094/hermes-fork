# Waybar / Hyprland toolbar polish on Silverblue

Session-specific pattern for polishing a JaKooLit-style Waybar on Fedora Silverblue:

- Read both the top-level Waybar config and the included module fragments before editing.
- Many visible items are controlled in `ModulesGroups`, not only in `config`.
- For cleanup, edit the active group definitions rather than only changing the top-level bar layout.
- Good UI simplifications that stayed stable:
  - memory -> `Mem {percentage}%`
  - battery -> `Bat {capacity}%`
  - backlight -> `Bright {percent}%`
  - power profile indicator removed when it adds noise
  - notification indicator removed when not wanted
  - disk slot repurposed to a download-speed readout
- For network cleanup, prefer label text over interface-name/icon output if the user wants a cleaner bar.
- If a module still shows raw interface labels or icons, check for alternate module variants such as `network#speed` or other included fragments.
- After edits, reload Waybar and verify the layout visually/logically rather than assuming the top-level config alone controls the final bar.