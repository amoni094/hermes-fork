When a Hyprland rice binds `SUPER_L` to a wrapper such as `~/.config/hypr/scripts/SuperLauncher.sh`, perceived dock lag is often just the single-vs-double-tap guard window, not a rofi or Waybar failure.

Observed working pattern
- `bindr = $mainMod, SUPER_L, exec, $scriptsDir/SuperLauncher.sh`
- wrapper stores a last-tap timestamp and a pending marker under `$XDG_RUNTIME_DIR`
- first tap sleeps briefly, then opens `PinnedLauncher.sh`
- second tap inside the threshold cancels the pending launch and runs the double-tap action

Useful tuning rule
- inspect `threshold_ms` and `launch_delay_s` first
- conservative values around `320ms / 0.32s` can feel sluggish
- a faster preserved-double-tap range is roughly `120-180ms`
- session-tested change: `threshold_ms=180`, `launch_delay_s=0.12`

Verification
- `bash -n ~/.config/hypr/scripts/SuperLauncher.sh`
- `bash -n ~/.config/hypr/scripts/PinnedLauncher.sh`
- `Hyprland --verify-config -c ~/.config/hypr/hyprland.conf`

Use this before redesigning the keybind or replacing the launcher stack.