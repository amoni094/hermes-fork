# Hyprland Super-key dock vs Waybar taskbar disambiguation

Use this when a user says "dock" in a Hyprland rice and the first instinct is to edit Waybar.

Key lesson:
- "dock" may refer to two different surfaces:
  1. Waybar's `wlr/taskbar` / app buttons inside the top or bottom bar
  2. a separate launcher opened by a keybind, often a rofi dock triggered by `SUPER_L`

Fast disambiguation checks:
1. Ask what opens it, or inspect the keybinds first.
2. If the user says "it appears when I press the Windows key", inspect Hyprland binds before touching Waybar.
3. In this class of rice, the likely path is:
   - `~/.config/hypr/UserConfigs/UserKeybinds.conf` binds `SUPER_L`
   - wrapper: `~/.config/hypr/scripts/SuperLauncher.sh`
   - payload: `~/.config/hypr/scripts/PinnedLauncher.sh`
   - rofi theme/layout: `~/.config/rofi/config-app-launcher.rasi`

If the target is the rofi dock, common one-row/icon-only edits belong in `config-app-launcher.rasi`:
- widen `window`
- set `listview { columns: N; lines: 1; }`
- shrink `element-icon`
- tighten `element` padding/spacing
- set `element-text { enabled: false; }` to remove labels

If the target is Waybar instead, the app-name text usually comes from `~/.config/waybar/Modules` under `wlr/taskbar` format, and crowding is handled in Waybar CSS.

Pitfall:
- Do not switch the active Waybar layout just because the user said "dock". Confirm the trigger surface first or you may accidentally replace the user's top toolbar while leaving the real Super-key dock unchanged.
