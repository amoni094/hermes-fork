# Waybar right-edge dropdown micro-tuning

Use this when the mechanics already work and the user only wants the visible geometry nudged by a few pixels.

## Context
A Hyprland/Waybar power dropdown was moved from rofi/standalone popup approaches to Waybar's built-in GTK menu (`menu`, `menu-file`, `menu-actions`). The remaining work was pure placement polish: flush-right alignment, top edge under the toolbar, and toolbar/popup palette matching.

## High-yield tuning surfaces
Adjust these together, not one at a time in isolation:
- top-level Waybar `margin-right`
- `.modules-right` CSS `padding-right`, `margin-right`, and right-side border radius
- `#custom-power` CSS `padding-right`, `margin-right`, and right-side border radius
- `menu` CSS `margin-right` and `margin-top`

## Direction pitfall
For a right-anchored cluster, it is easy to reverse the sign mentally.

Practical note from this session:
- making `margin-right` more negative on the right-side cluster/popup moved the element farther left into the screen
- making `margin-right` less negative (or more positive) moved it back toward the physical right edge
- `margin-top` behaved normally: larger positive values moved the popup lower

So when the user says:
- `move left` -> usually make right-side `margin-right` more negative
- `move right` -> usually make right-side `margin-right` less negative / more positive
- `move down` -> increase `margin-top`
- `move up` -> decrease `margin-top`

## Workflow
1. Lock the architecture first: keep Waybar's built-in menu if dropdown mechanics and outside-click dismissal are already correct.
2. Confirm which element the user means:
   - top toolbar/right cluster
   - power button capsule
   - popup menu itself
3. Echo the requested direction in plain geometry terms before editing if there is any risk of sign confusion.
4. Make only the requested pixel change.
5. Reload Waybar immediately.
6. Stay in micro-adjust mode until the user is satisfied; do not re-litigate toolkit choice.

## User-communication pattern
Once the layout is close, respond with compact delta summaries only:
- `top toolbar: 3 px left`
- `power dropdown: 2 px right, 1 px down`

Do not switch back to broad explanations once the task has entered visual-tuning mode.
