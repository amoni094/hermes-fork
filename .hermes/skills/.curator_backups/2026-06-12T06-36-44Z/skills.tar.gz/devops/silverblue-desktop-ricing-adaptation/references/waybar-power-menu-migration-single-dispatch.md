# Waybar power menu migration with single-dispatch action routing

Use when a Hyprland/Waybar rice has a broken or visually wrong power button launcher and the user wants a true top-bar dropdown rather than a separate popup app.

## Durable pattern

1. Treat launcher UI and power actions as separate layers.
2. Keep one dispatcher script for the actual actions:
   - lock
   - suspend
   - logout
   - reboot
   - shutdown
3. Move the visible menu to Waybar built-in menu support on the `custom/power` module:
   - `"menu": "on-click"`
   - `"menu-file": ".../power-menu.ui"`
   - `"menu-actions": [...]`
4. Keep any older entrypoint such as `Wlogout.sh` as a thin compatibility wrapper to the dispatcher instead of deleting it immediately.
5. Put styling and geometry polish in `waybar/style.css`, not inside the dispatcher script.

## Why this helps

- fixes the UI surface without forking the action logic
- makes Waybar clicks, fallback scripts, and future launchers share the same behavior
- keeps pixel-level dropdown tuning isolated to CSS/UI files
- reduces regression risk during launcher swaps

## Good file split

- `~/.config/hypr/scripts/PowerAction.sh` -> authoritative action dispatcher
- `~/.config/waybar/power-menu.ui` -> dropdown structure
- `~/.config/waybar/ModulesCustom` -> Waybar menu hookup
- `~/.config/waybar/style.css` -> dropdown visual alignment
- `~/.config/hypr/scripts/Wlogout.sh` -> compatibility/fallback wrapper only

## Verification

- syntax-check shell wrappers with `bash -n`
- parse-check the GTK menu XML
- reload Waybar and confirm the process remains alive
- when placement follow-ups become pixel tweaks only, change CSS margins directly and avoid reopening the launcher architecture
