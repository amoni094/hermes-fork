# Hyprland wallust caller hardening

Use this when a Fedora Atomic / Silverblue Hyprland setup already has a guarded `WallustSwww.sh` wrapper, but higher-level helpers still abort because they treat palette regeneration as mandatory.

## Problem pattern
Even after `WallustSwww.sh` exits cleanly when `wallust` is missing, callers may still break the user workflow by doing one of these:
- `"$SCRIPTSDIR/WallustSwww.sh" "$img" || exit 1`
- `"$SCRIPTSDIR/WallustSwww.sh" "$image_path"` inside a `set -e` script
- `require wallust` in a theme chooser that should instead notify and exit cleanly
- chaining with `&&` so wallpaper/theme refresh stops when palette regeneration is skipped

## Hardening pattern
Treat wallpaper application as the primary action and palette regeneration as optional enhancement work.

### Safe caller edits
- Change hard failure calls to optional calls:
  - `"$SCRIPTSDIR/WallustSwww.sh" "$img" || true`
- In `set -e` scripts, explicitly tolerate the optional step rather than relying on implicit shell behavior.
- Replace chains like:
  - `${SCRIPTSDIR}/WallustSwww.sh &&`
  with:
  - `${SCRIPTSDIR}/WallustSwww.sh || true`
- If a helper is specifically for wallust theme switching, exit `0` with a short notification when `wallust` is absent instead of throwing a hard dependency error.

## Audit targets
Check these first because they commonly wrap wallpaper or theme flows:
- wallpaper randomizers
- wallpaper selectors
- automatic wallpaper changers
- refresh helpers
- dark/light mode switchers
- theme choosers

## Verification
After patching caller scripts:
1. run `bash -n` across every edited script
2. grep for remaining hard-failure patterns around `WallustSwww.sh`
3. confirm the remaining uses are either already guarded with `|| true` or intentionally wallust-specific

## Reporting guidance
State clearly that:
- wallpaper switching now works even if `wallust` is absent
- palette regeneration is skipped gracefully rather than treated as a session failure
- wallust-specific theme switching may remain unavailable, but should fail softly rather than abort the desktop workflow
