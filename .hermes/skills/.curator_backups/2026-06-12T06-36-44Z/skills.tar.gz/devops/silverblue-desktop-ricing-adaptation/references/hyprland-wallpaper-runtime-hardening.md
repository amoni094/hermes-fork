Context: Adapting a JaKooLit-derived Hyprland setup on Fedora Silverblue where the core session was mostly ready but wallpaper/theming helpers were brittle.

Durable lessons
1. Verify the active startup file before patching helper scripts.
   - In this case, the live startup lines were in `~/.config/hypr/configs/Startup_Apps.conf`.
   - `~/.config/hypr/UserConfigs/Startup_Apps.conf` existed but was mostly empty.
   - A wallpaper-selection helper was editing the wrong file, so mode changes did not persist.

2. Match the real startup syntax, not an idealized upstream form.
   - The active wallpaper startup used a guarded line like:
     `exec-once = sh -lc 'command -v swww-daemon >/dev/null && swww-daemon --format xrgb'`
   - Helper-script toggles must match wrapped/guarded forms, not just a bare `swww-daemon` token.

3. Guard optional wallpaper/theme dependencies inside helper scripts.
   - Add reusable dependency checks for tools like `rofi`, `hyprctl`, `jq`, `bc`, `swww`, `swww-daemon`, `wallust`, and `magick` as appropriate to the script.
   - Fail early with a notification instead of partially editing config and then dying later.

4. Keep core session readiness separate from wallpaper/theming completeness.
   - It is acceptable for Hyprland, waybar, rofi, swaync, hyprlock, hypridle, kitty, cliphist, fastfetch, cava, and playerctl to be green while `swww`, `wallust`, `hyprsunset`, or `mpvpaper` remain unresolved.
   - Report those as non-fatal extras unless the user explicitly wants full wallpaper/video/night-light functionality before reboot.

5. After any shell-script patch, run syntax verification.
   - `bash -n` on each changed helper script is a cheap, high-value check before claiming the fix is ready.

Good reporting pattern
- Distinguish "core session should boot" from "optional shortcuts/widgets will still do nothing".
- Name the exact missing runtime pieces without turning them into permanent negative lore.
- Explain whether the next blocker is config logic, package sourcing, or reboot verification.