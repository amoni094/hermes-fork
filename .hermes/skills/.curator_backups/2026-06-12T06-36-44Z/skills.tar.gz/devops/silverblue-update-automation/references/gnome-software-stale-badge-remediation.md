# GNOME Software stale system-update badge remediation

Use this after confirming there is no real pending host or Flatpak update.

## Fast diagnosis

1. Check host reality with `rpm-ostree upgrade`.
   - If it returns `No upgrade available`, there is no new host deployment to stage.
2. Inspect `rpm-ostree status --json`.
   - If `cached-update` exists but `cached-update.ref-has-new-commit = false`, treat the cached entry as metadata/layered-package state, not a new Silverblue base commit.
   - If `cached-update.checksum` matches the booted deployment checksum, the host is already on that deployment.
3. Check Flatpaks with `flatpak update --assumeyes`.
   - If it reports `Nothing to update`, there is no real Flatpak backlog.
4. Check for an offline update marker.
   - If `/system-update` is absent, there is no pending offline apply marker.

## User-space remediation

Prefer a reversible reset by moving GNOME Software state aside instead of deleting it immediately.

Paths:
- `~/.cache/gnome-software`
- `~/.local/state/gnome-software`
- `~/.local/share/gnome-software`

Example pattern:

```bash
ts=$(date +%Y%m%d-%H%M%S)
for d in "$HOME/.cache/gnome-software" \
         "$HOME/.local/state/gnome-software" \
         "$HOME/.local/share/gnome-software"; do
  [ -e "$d" ] && mv "$d" "${d}.bak-$ts"
done
flatpak update --appstream --assumeyes || true
```

Then reopen GNOME Software. If needed, log out and back in once so it rebuilds against fresh state.

## Escalation

If GNOME Software still shows a system update badge after the user-space reset and both `rpm-ostree upgrade` and `flatpak update --assumeyes` show nothing to do, clear host-side rpm-ostree metadata next.

Typical command:

```bash
sudo rpm-ostree cleanup -m
```

This often requires broader sudo than unattended `rpm-ostree upgrade`, so do not assume the same sudo rule set covers it.

## Verification

- `rpm-ostree upgrade` -> `No upgrade available`
- `flatpak update --assumeyes` -> `Nothing to update`
- `/system-update` absent
- GNOME Software cache/state directories absent before relaunch, or recreated fresh afterward
- Badge clears after relaunch or next login
