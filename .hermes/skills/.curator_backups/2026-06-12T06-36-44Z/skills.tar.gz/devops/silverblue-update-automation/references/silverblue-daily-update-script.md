# Sample Silverblue daily update script

Use a standalone shell script for Hermes `no_agent` cron jobs so the scheduler runs deterministic maintenance instead of asking the LLM to reconstruct commands.

## Core pattern

- Log each phase with timestamps.
- Keep user Flatpak updates separate from privileged work.
- Wrap privileged phases with `sudo -n true` checks.
- Use `toolbox run --container <name> ...` rather than `toolbox enter`.
- Make toolbox name configurable with `TOOLBOX_NAME`.

## Minimal example

```bash
#!/usr/bin/env bash
set -u

log() {
  printf '[%s] %s\n' "$(date --iso-8601=seconds)" "$*"
}

need_sudo_msg='passwordless sudo is not configured, so unattended privileged updates cannot run yet'
TOOLBOX_NAME="${TOOLBOX_NAME:-fedora-toolbox-44}"

log 'Starting daily update sweep'

if sudo -n true 2>/dev/null; then
  log 'Running rpm-ostree upgrade'
  sudo -n rpm-ostree upgrade
else
  log "Skipping rpm-ostree upgrade: ${need_sudo_msg}"
fi

log 'Running user Flatpak update'
flatpak update -y --user

if sudo -n true 2>/dev/null; then
  log 'Running system Flatpak update'
  sudo -n flatpak update -y --system
else
  log "Skipping system Flatpak update: ${need_sudo_msg}"
fi

if toolbox list --containers 2>/dev/null | awk '{print $2}' | grep -Fxq "$TOOLBOX_NAME"; then
  log "Running toolbox DNF upgrade in ${TOOLBOX_NAME}"
  toolbox run --container "$TOOLBOX_NAME" bash -lc 'if sudo -n true 2>/dev/null; then sudo -n dnf upgrade --refresh -y; else echo "passwordless sudo is not configured inside toolbox"; exit 2; fi'
else
  log "Skipping toolbox DNF upgrade: toolbox container ${TOOLBOX_NAME} not found"
fi

log 'Daily update sweep finished'
```

## Cron creation note

When creating the Hermes cron job, the `script` field must be the filename relative to `~/.hermes/scripts/`, for example:

```json
{
  "action": "create",
  "name": "daily-silverblue-update-sweep",
  "schedule": "0 3 * * *",
  "script": "daily-silverblue-update.sh",
  "no_agent": true,
  "enabled_toolsets": ["terminal"],
  "deliver": "local"
}
```

Do not pass an absolute script path to the cron tool.
