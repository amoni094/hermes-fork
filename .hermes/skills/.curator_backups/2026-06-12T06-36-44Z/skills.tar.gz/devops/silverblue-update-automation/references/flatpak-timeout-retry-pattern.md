# Flatpak timeout retry pattern for login-triggered Silverblue updates

Use this when a daily Silverblue update wrapper ran at login, `rpm-ostree` and other phases may have succeeded, but the day remained unstamped because a system Flatpak fetch failed with a transient network-looking timeout.

## Durable lesson

Flatpak remote failures may present as curl/libcurl transfer errors rather than explicit DNS failures. In unattended update scripts, classify these as retryable network failures:

- `[28] Timeout was reached`
- `Operation too slow`
- `Recv failure`
- `Connection reset by peer`
- plus the usual DNS/connectivity strings such as `Could not resolve`, `Network is unreachable`, `Failed to connect`, `Connection timed out`

If the classifier misses these strings, the script can bypass its network retry path and fail the entire day on a one-off Flathub hiccup.

## Recommended script behavior

1. Wait for network once before the whole sweep when NetworkManager is present (`nm-online`).
2. Capture stderr from each phase and classify the failure cause.
3. Route curl-style Flatpak timeout strings into the same `network` class as DNS/connectivity failures.
4. Retry at least twice for unattended login-triggered flows.
5. Leave the daily stamp absent on final failure so a later login/manual rerun can recover the same day.

## Verification pattern

To verify safely without touching the real daily stamp:

1. Run the login-trigger wrapper with a temporary `XDG_STATE_HOME`.
2. Set `AUTO_REBOOT=0`.
3. Confirm success writes:
   - `daily-silverblue-update/latest.log`
   - `daily-silverblue-update/last-run-date`
4. Confirm the log contains phase-complete lines such as:
   - `System Flatpak update completed`
   - `Toolbox DNF upgrade completed`
   - `login trigger marked successful`
5. For classifier verification, test the regex against a representative Flatpak error string containing `[28] Timeout was reached`.

## Why this belongs in the skill

This is not a one-off Firefox issue. It is a class-level robustness rule for unattended Flatpak update automation on Silverblue: retry logic must recognize Flatpak’s real timeout vocabulary, not just generic network phrasing.
