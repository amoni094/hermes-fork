For this workspace/user, a routine Silverblue maintenance pass should treat Hermes as part of the same sweep as rpm-ostree, Flatpak, and snf/toolbox updates unless the user explicitly narrows scope.

What to encode in future runs:
- When the user asks for "the updates" or references the usual rpm-ostree/Flatpak/snf pass, include a Hermes update step.
- Keep Hermes as a separately reported phase so failures are attributable and do not get conflated with host or Flatpak issues.
- Discover the live Hermes update command/path on the machine before scripting or automating it; do not assume it from stale memory.

Why this matters:
- The user explicitly corrected the maintenance scope so Hermes is not forgotten during routine update passes.
