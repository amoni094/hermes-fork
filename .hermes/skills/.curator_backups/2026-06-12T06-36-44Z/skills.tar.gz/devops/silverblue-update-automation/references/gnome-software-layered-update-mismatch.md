# GNOME Software layered-update mismatch on Silverblue

Use this when GNOME Software says "system updates available" or offers restart/apply, but the user believes `rpm-ostree` and Flatpak are already current.

## Fast triage

1. Check host state:
   - `rpm-ostree status`
   - `rpm-ostree status --json`
2. Check Flatpak separately:
   - `flatpak remote-ls --updates`
   - or `flatpak update` dry-run equivalent for the environment
3. Check offline-update markers:
   - `/system-update`
   - `systemctl status system-update.target`
4. Refresh the interpretation using `cached-update` from `rpm-ostree status --json`.

## Key interpretation

If `rpm-ostree status` shows `AvailableUpdate`, do not assume that means a new Silverblue base image.

Look at `cached-update`:

- `ref-has-new-commit = true`
  - New ostree base commit exists.
- `ref-has-new-commit = false` and `rpm-diff.upgraded` is non-empty
  - No new base image; only layered RPM updates are pending.
- No `cached-update`, no Flatpak updates, no offline marker
  - Suspect stale GNOME Software metadata/state.

## Example symptom shape

Observed durable pattern:
- GNOME Software says updates are available
- clicking download/restart is unreliable or does nothing
- reboot does not consume any offline update
- after reboot GNOME Software still shows updates
- `rpm-ostree status --json` reveals only layered RPM package diffs in `cached-update.rpm-diff`

## Practical remediation

Prefer direct verification over the GUI path:
1. `rpm-ostree upgrade`
2. reboot normally
3. re-check `rpm-ostree status`

If the GUI still shows stale updates afterward, clear only GNOME Software user metadata/state:
- `~/.cache/gnome-software`
- `~/.local/state/gnome-software`
- `~/.local/share/gnome-software`

This is a cache/UI reset, not package removal.

## Notes

- On Hyprland or other non-GNOME sessions, GNOME Software restart/apply integration may be less reliable than on a standard GNOME desktop.
- Do not over-attribute this class of issue to PackageKit on Silverblue when `gnome-software-rpm-ostree` is the relevant backend path.
- Separate three categories in the user-facing explanation: base ostree update, layered RPM update, and Flatpak update. The confusion usually comes from collapsing them together.