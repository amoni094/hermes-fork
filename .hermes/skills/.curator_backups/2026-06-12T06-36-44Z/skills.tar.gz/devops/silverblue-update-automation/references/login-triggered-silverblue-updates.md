# Login-triggered Silverblue updates

Use this reference when the machine updates at first login of the day via a user systemd oneshot service rather than a wall-clock cron.

## Audit existing setup

Check these items before changing anything:

1. Service unit exists under `~/.config/systemd/user/`
   - Example: `daily-silverblue-update.service`
2. The service is enabled in the user manager.
3. `systemctl --user cat <service>` points to the wrapper script you expect.
4. `systemctl --user status <service> --no-pager` shows the current state.
   - `inactive (dead)` is normal for a completed `Type=oneshot` service.
5. The wrapper state directory exists under `${XDG_STATE_HOME:-$HOME/.local/state}/<name>/`.
   - Expect a date stamp such as `last-run-date`
   - Expect a stable log such as `latest.log`

## Readback pattern

When verifying an existing login-triggered updater, inspect all of:

- the unit file via `systemctl --user cat`
- the wrapper script
- the main update script
- the state stamp file
- the latest log file

This proves:
- what triggers the run
- whether once-per-day gating exists
- what commands actually execute
- whether it already ran today
- whether the last run succeeded or skipped privileged phases

## Interpreting results

Typical healthy pattern:
- service: enabled
- service active state: inactive/dead
- stamp file: today's date
- log shows rpm-ostree, Flatpak, and toolbox phases finishing without hanging

Typical blocked pattern:
- log shows privileged phases skipped because `sudo -n <exact command>` was not permitted
- service exists but no stamp/log files exist yet, meaning it has not run successfully

## Cleanup and reboot audit

After an update sweep, verify separately:

- `rpm-ostree status --json` for staged/pending deployments and rollback count
- `rpm-ostree cleanup -m` to clear rpm-md metadata cache if desired
- `rpm-ostree cleanup -r` only when the user wants to remove the rollback deployment

Important: rollback cleanup may require an additional sudoers rule even when unattended `rpm-ostree upgrade` already works. Treat rollback removal as a separate privileged capability to verify, not as implied by upgrade success.
