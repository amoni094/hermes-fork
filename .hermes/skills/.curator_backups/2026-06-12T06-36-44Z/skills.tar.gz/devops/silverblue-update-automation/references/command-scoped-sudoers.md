# Command-scoped sudoers for unattended Silverblue updates

Use this when a Hermes cron job should run privileged update commands unattended without granting blanket passwordless sudo.

## Core lesson

A script-level gate like `sudo -n true` is too broad when sudoers only permits specific commands with `NOPASSWD`. In that setup:

- `sudo -n true` can fail
- `sudo -n /usr/bin/rpm-ostree upgrade` can succeed
- `sudo -n /usr/bin/flatpak update -y --system` can succeed
- inside toolbox, `sudo -n /usr/bin/dnf upgrade --refresh -y` can succeed

So test or run the exact command you intend to allow.

## Host sudoers example

```sudoers
Defaults:USERNAME !requiretty
USERNAME ALL=(root) NOPASSWD: /usr/bin/rpm-ostree upgrade
USERNAME ALL=(root) NOPASSWD: /usr/bin/flatpak update -y --system
USERNAME ALL=(root) NOPASSWD: /usr/bin/dnf upgrade --refresh -y
```

Validate before install:

```bash
visudo -cf /path/to/file
sudo install -m 440 /path/to/file /etc/sudoers.d/name
sudo visudo -cf /etc/sudoers.d/name
```

## Toolbox sudoers example

If toolbox updates also need unattended sudo, install a sudoers file inside the toolbox container too:

```sudoers
Defaults:USERNAME !requiretty
USERNAME ALL=(root) NOPASSWD: /usr/bin/dnf upgrade --refresh -y
```

Validate and install from the host:

```bash
toolbox run --container CONTAINER bash -lc 'visudo -cf /shared/path/file'
toolbox run --container CONTAINER bash -lc 'sudo install -m 440 /shared/path/file /etc/sudoers.d/name && sudo visudo -cf /etc/sudoers.d/name'
```

## Verification

Prefer exact-command checks over generic sudo probes:

```bash
sudo -n /usr/bin/rpm-ostree upgrade --help >/dev/null 2>&1
sudo -n /usr/bin/flatpak update -y --system --help >/dev/null 2>&1
toolbox run --container CONTAINER bash -lc 'sudo -n /usr/bin/dnf upgrade --refresh -y --help >/dev/null 2>&1'
```

A broader `sudo -n -l` check is useful for inspection, but the script's control flow should still be based on the exact command it will run.
