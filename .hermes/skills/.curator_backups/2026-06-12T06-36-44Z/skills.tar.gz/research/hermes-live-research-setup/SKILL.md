---
name: hermes-live-research-setup
description: Improve source coverage for live research workflows in Hermes, especially when an upstream research skill is installed but underpowered due to missing search, extract, X auth, or media backends.
---

# Hermes live research setup

Use this when a user wants better recent-news or social-signal coverage from Hermes-based research workflows and the current setup is source-limited.

## Triggers
- A research skill is installed but diagnostics show only partial source coverage.
- Hermes has no working web search/extract backend.
- The user wants better coverage for last-30-days briefings, news scans, or topic monitoring.
- X/Twitter or YouTube coverage is missing and the user wants setup help rather than just a one-off briefing.
- The user wants a free-only or generous-free-quota research stack layered across Hermes web search and an upstream research skill.
- The user wants an upstream research skill extended with new source-specific signals, such as short-horizon GitHub trend discovery.

## Goal
Raise real source coverage with small, verifiable setup changes, then re-check diagnostics instead of assuming the setup worked.

## Procedure
1. Diagnose the current state first.
   - Run the research tool's own diagnose command if it has one.
   - Check Hermes web config separately; do not assume the research tool can see Hermes web settings.
   - Record what is already working: Reddit, YouTube, HN, GitHub, X auth, web search, extract.

2. Improve media/source ingestion before changing synthesis.
   - If YouTube coverage depends on `yt-dlp`, install it with the platform-appropriate path and verify the binary is on `PATH`.
   - Re-run diagnostics after install; do not claim success based only on package-manager output.

3. Configure browser-backed auth conservatively.
   - Prefer the research tool's own env file under `~/.config/<tool>/` when it documents one.
   - Add only the minimum durable settings needed for auto-detection, such as `FROM_BROWSER=auto` and completion flags if the upstream tool expects them.
   - Lock permissions on per-tool env files with `chmod 600`.
   - Verify X auth by checking the tool's diagnose output or explicit cookie extraction, not by assuming browser presence implies usable cookies.
   - On Fedora Silverblue / Flatpak Firefox setups, check `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/*.default-release/cookies.sqlite` instead of only `~/.mozilla/firefox/`.
   - If the upstream auto-extractor misses a usable Flatpak Firefox profile, treat direct SQLite inspection of `auth_token` and `ct0` as the fallback verification path, then write those values into the tool-specific env file and re-run diagnostics.

4. Add a real Hermes web backend.
   - If no API keys are available, prefer a local SearXNG instance for search.
   - Verify the search backend directly with a live query returning JSON results.
   - Set Hermes config via `hermes config set ...`, not by hand-editing `~/.hermes/config.yaml` when the CLI supports the setting.
   - Add required env vars to `~/.hermes/.env` and then verify with both a direct backend probe and Hermes config inspection.
   - Treat Hermes web search and an upstream research tool's own web/source backends as separate layers; verify each independently.
   - For free-first setups, use this default layering: Hermes search via local SearXNG, then upstream native sources such as Reddit/HN/YouTube/X/GitHub, and only then optional paid web backends like Brave or Serper if the user needs stronger grounding.

5. When extending upstream source coverage, add source-native signals instead of forcing everything through web search.
   - For Git/GitHub use cases, prefer the upstream tool's GitHub module and authenticated GitHub API access over generic web search.
   - If the user wants "what's new this week" rather than only issue/PR chatter, add a short-horizon repo-trend pass separately from discussion search.
   - A practical pattern is two 7-day repo searches: newly created repos sorted by stars for "popular now" and recently pushed repos sorted by updated time for "emerging now".
   - Normalize those repo-trend hits into the existing pipeline with explicit labels such as `repo-trend`, `weekly-popular`, and `weekly-emerging` so downstream ranking and summaries can distinguish them from issue/PR items.
   - Reuse one resolved GitHub token at the pipeline boundary so search, enrichment, and trend discovery do not each repeat env/CLI token resolution.

6. Keep search and extract distinct.
   - SearXNG is search-only.
   - If better extraction is needed later, add Firecrawl, Tavily, Exa, or Parallel as a separate extract backend rather than over-claiming what SearXNG provides.

6. Report coverage honestly.
   - Distinguish between "Hermes web search now works" and "the upstream research script's own diagnose output recognizes a native web backend".
   - If the upstream script does not introspect Hermes web config, say so explicitly and show the independent verification path.

## Verification checklist
- Research-tool diagnose output captured before and after changes.
- `yt-dlp` present and versioned if YouTube support depends on it.
- Per-tool env file exists with safe permissions if created.
- Browser cookie extraction checked explicitly before claiming X auth.
- Hermes web backend responds to a live search query.
- `hermes config show` or `hermes config set` confirms the intended backend values.

## Pitfalls
- Do not equate Chrome/Chromium profile directories with usable X cookies.
- Do not stop at `~/.mozilla/firefox/` on Flatpak Firefox systems; the real profile may live under `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/`.
- Do not claim that a research script gained a native web backend just because Hermes now has one.
- Do not patch `~/.hermes/config.yaml` directly when `hermes config set` can make the same change safely.
- Do not stop after starting SearXNG; JSON output must be enabled and verified.
- Do not leave per-tool env files world-readable.
- Do not summarize broad "latest developments" topics from free local sources without first narrowing query packs by domain; politics, finance, music, and cars become noisy much faster than tech/GitHub.
- Do not rely on generic web search for GitHub trend work when authenticated GitHub API queries can supply cleaner 7-day popularity and emergence signals.

## Support files
- `references/last30days-source-coverage.md` — concrete commands, config deltas, and verification notes from a real last30days + Hermes coverage upgrade session.
