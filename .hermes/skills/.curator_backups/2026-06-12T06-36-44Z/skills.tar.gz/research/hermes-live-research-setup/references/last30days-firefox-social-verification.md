# last30days social-source verification via Firefox

Use this when a live-research workflow needs stronger source coverage from X, Reddit, and GitHub on a Fedora Silverblue workstation using Firefox Flatpak.

What worked in this session
- Firefox cookies were available under the Flatpak profile root:
  `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/`
- X session cookies (`auth_token`, `ct0`) were present in the Firefox cookie DB and compatible with the last30days local `.env` flow.
- `~/.config/last30days/.env` existed with mode `0600` and contained:
  - `FROM_BROWSER=auto`
  - `AUTH_TOKEN=...`
  - `CT0=...`
- `python3.14 /tmp/last30days-skill/skills/last30days/scripts/last30days.py --diagnose` confirmed:
  - `available_sources`: reddit, x, youtube, hackernews, polymarket, github
  - `bird_authenticated: true`
  - `has_github: true`
  - `x_backend: bird`
- `gh auth status` verified GitHub auth was already present and usable for repo verification.

Reddit-specific note
- Browser/account presence in Firefox does not automatically mean the pipeline is using logged-in Reddit scraping.
- In this session, the durable working verification path was Reddit RSS/public discovery, not authenticated Reddit JSON.
- `reddit_public.search(...)` hit `403` on `reddit.com/search.json`.
- `reddit_rss.search_rss(...)` returned results successfully, so treat RSS as the fallback verification path when JSON blocks.

Git topic pattern that worked
Add a dedicated watchlist topic for repo momentum with explicit 24h/7d intent, e.g.
- Topic: `Popular GitHub repos - last 24h and 7 days`
- Queries:
  - `github trending`
  - `popular github repos today`
  - `popular github repos this week`
  - `newly created github repos with most stars`
  - `recently pushed github repos`

Verification checklist
1. Confirm Firefox cookie location, especially on Flatpak Firefox.
2. Confirm `~/.config/last30days/.env` exists and is `0600`.
3. Run `last30days.py --diagnose` from the skill repo path and verify X + GitHub availability.
4. Run `gh auth status` for GitHub.
5. Test Reddit via both JSON and RSS helpers; if JSON 403s, keep RSS as the live verification path.
6. Add and run a dedicated GitHub-popularity topic so news briefings can include 24h and 7d repo momentum.
