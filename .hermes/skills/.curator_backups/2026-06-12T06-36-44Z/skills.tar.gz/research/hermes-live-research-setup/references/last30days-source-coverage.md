# last30days source-coverage upgrade notes

Use these notes when a Hermes research workflow needs more than Reddit/HN-only coverage.

## Session pattern
A real session improved source coverage for `last30days` and Hermes in two layers:
1. improve the upstream skill's direct sources
2. separately wire Hermes web search so the agent can do broader live discovery

## Commands and outcomes

### 1) Improve YouTube coverage for last30days
Install `yt-dlp` via `uv` and verify it is callable:

```bash
uv tool install --force yt-dlp
export PATH="$HOME/.local/bin:$PATH"
command -v yt-dlp
yt-dlp --version
python3.14 /tmp/last30days-skill/skills/last30days/scripts/last30days.py --diagnose
```

Observed outcome in the session:
- before: `available_sources` lacked `youtube`
- after: `available_sources` included `youtube`

### 2) Prepare last30days local env for browser-backed auth
Create the tool-specific env file and lock permissions:

```bash
python3.14 - <<'PY'
from pathlib import Path
p = Path('/var/home/rainbow/.config/last30days/.env')
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text('FROM_BROWSER=auto\nSETUP_COMPLETE=true\n')
PY
chmod 600 /var/home/rainbow/.config/last30days/.env
```

Important: this only enables auto-detection. It does not prove X auth works.

### 3) Verify X cookie availability explicitly
Use the upstream extractor instead of guessing from browser install state:

```bash
python3.14 - <<'PY'
import sys
sys.path.insert(0, '/tmp/last30days-skill/skills/last30days/scripts')
from lib import cookie_extract
print(cookie_extract.extract_cookies_with_source('auto', '.x.com', ['auth_token','ct0']))
PY
```

Observed outcome in the session:
- extractor returned `None`
- `last30days.py --diagnose` still reported:
  - `bird_authenticated: false`
  - `x_backend: null`

Practical lesson:
- browser profile directories alone are insufficient evidence
- verify cookie extraction or diagnose output before claiming X coverage

### 3b) Flatpak Firefox fallback for X auth
If the extractor returns `None` but Firefox is installed via Flatpak, inspect the Firefox cookie DB directly instead of assuming X auth is unavailable:

```bash
python3.14 - <<'PY'
import sqlite3, tempfile, shutil
from pathlib import Path
src=Path('/var/home/rainbow/.var/app/org.mozilla.firefox/config/mozilla/firefox/a1f8jsqv.default-release/cookies.sqlite')
tmp=Path(tempfile.mkstemp(suffix='.sqlite')[1])
shutil.copy2(src,tmp)
con=sqlite3.connect(tmp)
cur=con.cursor()
rows=cur.execute("select host,name,length(value) from moz_cookies where (host like '%x.com%' or host like '%twitter.com%') and name in ('auth_token','ct0')").fetchall()
print(rows)
con.close()
tmp.unlink(missing_ok=True)
PY
```

Observed outcome in the session:
- the Flatpak Firefox profile did contain both required cookies:
  - `.x.com` / `auth_token`
  - `.x.com` / `ct0`

When that happens, promote the cookie values into the tool env and re-run diagnose:

```bash
python3.14 - <<'PY'
import sqlite3, tempfile, shutil
from pathlib import Path
src=Path('/var/home/rainbow/.var/app/org.mozilla.firefox/config/mozilla/firefox/a1f8jsqv.default-release/cookies.sqlite')
tmp=Path(tempfile.mkstemp(suffix='.sqlite')[1])
shutil.copy2(src,tmp)
con=sqlite3.connect(tmp)
cur=con.cursor()
rows=cur.execute("select name,value from moz_cookies where host='.x.com' and name in ('auth_token','ct0')").fetchall()
con.close()
tmp.unlink(missing_ok=True)
vals=dict(rows)
p = Path('/var/home/rainbow/.config/last30days/.env')
lines = p.read_text().splitlines() if p.exists() else []
updates = {
    'FROM_BROWSER':'auto',
    'SETUP_COMPLETE':'true',
    'AUTH_TOKEN':vals['auth_token'],
    'CT0':vals['ct0'],
}
out=[]
seen=set()
for line in lines:
    if '=' in line and not line.lstrip().startswith('#'):
        k,_ = line.split('=',1)
        if k in updates:
            out.append(f"{k}={updates[k]}")
            seen.add(k)
            continue
    out.append(line)
for k,v in updates.items():
    if k not in seen:
        out.append(f"{k}={v}")
p.write_text('\n'.join(out)+'\n')
p.chmod(0o600)
PY
python3.14 /tmp/last30days-skill/skills/last30days/scripts/last30days.py --diagnose
```

Observed outcome in the session:
- `available_sources` gained `x`
- `bird_authenticated: true`
- `x_backend: "bird"`

Practical lesson:
- a failed auto-extractor does not rule out usable X auth on Flatpak Firefox systems
- direct SQLite inspection is a valid fallback verification path when the browser path layout is the real problem

### 4) Add a local Hermes web-search backend with SearXNG
Start a local SearXNG container using Podman:

```bash
mkdir -p /var/home/rainbow/searxng/searxng
podman rm -f searxng >/dev/null 2>&1 || true
podman run -d --name searxng \
  -p 8888:8080 \
  -v /var/home/rainbow/searxng/searxng:/etc/searxng:rw,z \
  -e SEARXNG_BASE_URL=http://localhost:8888/ \
  --restart=unless-stopped \
  docker.io/searxng/searxng:latest
sleep 8
podman cp searxng:/etc/searxng/settings.yml /var/home/rainbow/searxng/searxng/settings.yml
```

Enable JSON in `/var/home/rainbow/searxng/searxng/settings.yml`:

```yaml
formats:
  - html
  - json
```

Then copy it back and restart:

```bash
podman cp /var/home/rainbow/searxng/searxng/settings.yml searxng:/etc/searxng/settings.yml
podman restart searxng
```

Verify the backend directly:

```bash
python3.14 - <<'PY'
import json, urllib.request
url='http://localhost:8888/search?q=test&format=json'
with urllib.request.urlopen(url, timeout=20) as r:
    data=json.load(r)
print('results=', len(data.get('results', [])))
PY
```

Observed outcome in the session:
- live JSON query succeeded
- result count was non-zero (`results=30` in one check, `results=12` in another topic-specific check)

### 5) Wire Hermes to the SearXNG backend
Set the env var and use Hermes config commands rather than editing the YAML directly:

```bash
# ~/.hermes/.env
SEARXNG_URL=http://localhost:8888

hermes config set web.search_backend searxng
hermes config set web.extract_backend ''
hermes config set web.backend ''
```

Verify with:

```bash
hermes config show
```

Expected config shape:

```yaml
web:
  backend: ''
  search_backend: searxng
  extract_backend: ''
```

## Important caveat
Even after Hermes search was working, the upstream `last30days.py --diagnose` output still showed:
- `native_web_backend: null`

Interpretation:
- Hermes web search was genuinely working
- the upstream script simply did not introspect Hermes web-tool configuration in its own diagnose path

Treat these as separate verification planes.

## What to do next
If coverage still needs improvement after this baseline:
1. enable real X auth by supplying usable `auth_token` + `ct0` or logging into a browser path the tool can read
2. add an extract-capable Hermes backend such as Firecrawl, Tavily, Exa, or Parallel
3. use Hermes for discovery plus the research skill for source-specific synthesis
