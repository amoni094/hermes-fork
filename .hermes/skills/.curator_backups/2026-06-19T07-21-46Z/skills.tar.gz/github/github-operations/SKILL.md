---
name: github-operations
description: Broad GitHub workflow skill for authentication, repository bootstrap, PR lifecycle, code review, follow-up automation, and issue triage.
version: 1.0.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  tags: [github, gh, git, auth, clone, fork, pull-request, review, issues, workflow]
---

# GitHub Operations

Use this when the task involves GitHub as a workflow surface rather than a single narrow action: logging in, cloning or forking repositories, creating or reviewing pull requests, triaging issues, or automating follow-up around a PR.

## Core idea
Treat GitHub work as one lifecycle:
1. authenticate
2. locate or bootstrap the repository
3. make a scoped branch change
4. open or review the PR
5. monitor CI/review state
6. follow up until the branch is stable

## When to use
- User needs GitHub auth or `gh` setup.
- User wants to clone, fork, or manage remotes.
- User wants to open, review, or follow up on a PR.
- User wants issue triage or repository hygiene around GitHub objects.
- User wants a single playbook that spans repo setup, review, and delivery.

## Workflow

### 1) Authenticate first
- Prefer the narrowest working auth path for the environment.
- Verify `gh auth status` or the equivalent git credential path before assuming access.
- If a credential helper or token is missing, solve that before blaming GitHub APIs.

### 2) Bootstrap or inspect the repository
- Clone/fetch the repo.
- Confirm remotes, default branch, and working branch state.
- Read repo instructions before modifying anything.
- If the user wants a fork-based workflow, keep upstream and origin separate and explicit.

### 3) PR lifecycle
- Create a branch with a scoped change.
- Commit only intended files.
- Open the PR or locate the existing PR.
- Re-read review comments after every push.
- Separate branch regressions from baseline repository failures.

### 4) Code review and follow-up
- Review the diff and surrounding context, not just the comment thread.
- Validate review comments against the live branch state.
- Keep generated or unrelated files out of follow-up commits.
- If the user wants automation, use a follow-up loop that checks for new comments, reruns CI, and reports only the new actionable items.

### 5) Issues
- Use issues for triage, scope, and lightweight tracking.
- Keep issue work separate from branch patching unless the issue explicitly drives a PR.
- When an issue references a PR, verify whether the live branch or the historical PR snapshot is the source of truth.

## Practical rules
- Always confirm the live ref/branch state before concluding a PR is fixed.
- Do not assume historical PR metadata still matches the current branch tip.
- Do not widen scope to unrelated repo failures.
- Do not push without verifying the branch contains only the intended changes.
- Do not confuse auth problems with repository or CI failures.

## Verification
- Auth works.
- Repo state is known.
- Branch/PR identity is verified.
- Review or issue state is re-queried after changes.
- Final report names the exact PR, branch, or issue state that was observed.

## Notes
More specific GitHub workflows that fit under this umbrella include auth setup, repository management, PR workflow, code review, and PR follow-up automation.
