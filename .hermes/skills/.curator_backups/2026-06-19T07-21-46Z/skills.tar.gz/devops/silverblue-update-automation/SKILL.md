---
name: silverblue-update-automation
description: Automate Fedora Silverblue update workflows with Hermes cron, separating user-level updates from privileged host/toolbox upgrades and verifying the schedule end to end.
version: 1.0.0
author: Hermes Agent
created_by: agent
license: CC0-1.0
platforms: [linux]
metadata:
  tags: [fedora, silverblue, rpm-ostree, flatpak, toolbox, cron, maintenance]
---

# Silverblue Update Automation

Use this when the user wants recurring maintenance on a Fedora Silverblue host, especially a daily or periodic flow involving `rpm-ostree`, `flatpak`, `snf`/toolbox package updates, and related user-space maintenance such as Hermes self-update.

Workspace convention: if the user refers to a combined maintenance pass covering `rpm-ostree`, Flatpak, and `snf`, include Hermes update in the same sweep unless they explicitly scope it out.

## What this skill is for

Silverblue update automation is different from a normal Linux package cron because the stack spans three privilege domains:

1. Host immutable OS updates via `rpm-ostree`
2. User or system Flatpak updates
3. Mutable package updates inside one or more toolbox containers

The reliable pattern depends on the trigger the user actually wants:

- For periodic wall-clock automation, put the real commands in a reusable script under `~/.hermes/scripts/` and schedule that script with a Hermes `no_agent` cron job.
- For "first login of the day" automation, use a systemd user `oneshot` service enabled under `default.target`, with a small wrapper script that enforces once-per-day execution via a state stamp and lock file.

In both cases, verify by forcing one safe run and checking the resulting state/logs.

## When to use

- User asks whether such a cron already exists
- User wants to add a daily or periodic Silverblue update job
- User wants update coverage across host OS + Flatpaks + toolbox containers
- User wants a combined maintenance pass that should also include Hermes update
- User wants an unattended maintenance script rather than an agent-written summary
- User wants the updates to run at first login of the day rather than at a fixed clock time
- User wants an automatic reboot only when `rpm-ostree` actually staged a new deployment

## Procedure

1. Check existing automation first.
   - If the user asked about a cron, list cron jobs and look for anything already covering `rpm-ostree`, `flatpak`, `toolbox`, or `dnf` updates.
   - Also inspect existing user systemd units when the user asked for login-triggered behavior.
   - Do not create a duplicate if an existing job or unit already does the same work.

2. Discover the live environment before writing automation.
   - Confirm `toolbox`, `rpm-ostree`, and `flatpak` exist.
   - If the maintenance pass is meant to include Hermes, determine the local Hermes update path before scripting it rather than assuming a command from memory.
   - Check whether passwordless sudo is available on the host with exact-command tests.
   - Check available toolbox containers and pick the intended one.
   - If toolbox updates are part of the request, also test non-interactive sudo inside the toolbox.
   - If auto reboot is requested, inspect `rpm-ostree status --json` so you know what staged/pending state looks like on this host.

3. Write a standalone main script under `~/.hermes/scripts/`.
   - Log timestamps and each phase.
   - For login-triggered flows, wait for network readiness before the first privileged fetch, not only after a classified network failure; `nm-online` is a good preflight when NetworkManager is present.
   - Run user Flatpak updates directly.
   - If the user's maintenance convention includes Hermes, add Hermes update as its own user-space phase in the same script and report it separately from OS/Flatpak/toolbox phases.
   - Gate privileged steps (`rpm-ostree`, system Flatpak, toolbox `dnf`) behind command-specific `sudo -n <exact command>` checks so the script stays unattended and does not hang.
   - Do not use `sudo -n true` as the gate when sudoers grants only command-scoped `NOPASSWD`; that test can fail even though the actual allowed command works unattended.
   - Parameterize the toolbox name with an environment variable like `TOOLBOX_NAME` when practical.
   - If reboot-on-update is required, compare the non-booted deployment before and after `rpm-ostree upgrade` and/or check for staged/pending deployments in `rpm-ostree status --json`.
   - When the user is debugging GNOME Software on Silverblue, inspect `rpm-ostree status --json` before assuming a stale GUI badge means a new base image. Distinguish these cases explicitly:
     - `cached-update.ref-has-new-commit = true`: new ostree base commit exists
     - `cached-update.ref-has-new-commit = false` with non-empty `cached-update.rpm-diff.upgraded`: only layered RPM updates are pending
     - no `cached-update` and no Flatpak updates: likely stale GNOME Software metadata/UI state rather than a real host update

4. Choose the trigger mechanism that matches the user request.
   - Fixed periodic schedule: create a Hermes `no_agent=true` cron job that runs the script.
   - First login of the day: create a small wrapper script under `~/.hermes/scripts/` that:
     - stores state in `${XDG_STATE_HOME:-$HOME/.local/state}/...`
     - writes a `last-run-date` stamp only after the wrapped update run succeeds
     - removes or leaves absent the stamp when the wrapped run fails, so a later login or manual retry the same day is still allowed
     - uses `flock` to prevent duplicate concurrent runs
     - appends script output to a stable log file such as `latest.log`
     Then create a systemd user `oneshot` service in `~/.config/systemd/user/` and enable it under `default.target`.

5. If the trigger mechanism changed, remove the old one.
   - If replacing cron with login-triggered systemd behavior, remove the old cron job so both do not fire.
   - Likewise, do not leave a stale enabled user service behind when moving back to cron.

6. Verify immediately.
   - Execute the wrapper or main script once directly to confirm behavior.
   - For login-triggered mode, suppress reboot during verification if needed with an env var such as `AUTO_REBOOT=0`.
   - Confirm the service is enabled or the cron job is present, depending on the chosen trigger.
   - For an existing login-triggered setup, also inspect `systemctl --user cat <service>`, `systemctl --user status <service> --no-pager`, the wrapper script, the main script, the date stamp, and the latest log file.
   - Re-run the wrapper a second time and verify the log/state did not change, proving the once-per-day guard works.
   - Report exactly which phases ran, which were skipped, and whether a reboot would have been triggered.

## Important pitfalls

- Match the trigger and maintenance scope to the request.
  - If the user says "daily" but also specifies "at first login" or equivalent, do not default to cron.
  - Use a user systemd service plus a date-stamped wrapper for "first login of the day" behavior.
  - If the user's maintenance sweep convention includes Hermes, do not silently omit it when performing the `rpm-ostree`/Flatpak/`snf` pass.

- Hermes cron script paths must be relative to `~/.hermes/scripts/`.
  - Do not pass `/abs/path/to/script.sh` to the cron tool.
  - Use `script: "script-name.sh"`.

- Unattended privileged updates require passwordless sudo, often scoped to exact commands.
  - `rpm-ostree upgrade` needs sudo on the host.
  - `flatpak update -y --system` needs sudo on the host.
  - Toolbox `dnf upgrade --refresh -y` usually needs sudo inside the toolbox.
  - If auto reboot is part of the flow, `/usr/sbin/reboot` also needs unattended permission.
  - If sudoers grants command-specific `NOPASSWD`, `sudo -n true` may still fail while `sudo -n /usr/bin/rpm-ostree upgrade` succeeds.
  - Prefer testing the exact command you intend to run and branch on its exit code.
  - Do not map every privileged-step exit code `1` to "sudo is not configured". Capture stderr and distinguish authentication failures from real command failures such as DNS resolution errors, repo fetch failures, or missing refs. Otherwise a login-triggered run can falsely look like a sudoers problem when networking or remotes were the real cause.
  - Flatpak network failures often surface as curl-style transfer strings rather than obvious DNS errors.
    - Treat messages like `[28] Timeout was reached`, `Operation too slow`, `Recv failure`, `Failure when receiving data from the peer`, TLS `unexpected eof while reading`, and `Connection reset by peer` as retryable network-class failures when building unattended update flows.
    - If your wrapper only retries on `Could not resolve` or `Connection timed out`, a transient Flathub fetch can incorrectly hard-fail the whole day instead of using the retry path.
    - When a single app repeatedly fails, verify the exact object URL outside Flatpak with `curl` or `wget` before attempting repo cleanup; if raw downloads also die mid-stream and `flatpak repair --dry-run` is clean, treat it as network/CDN path instability rather than local corruption.
    - If Flatpak reports `[35] SSL connect error` but raw `curl` shows `OpenSSL SSL_read ... unexpected eof while reading` only while a VPN tunnel is active, prefer VPN reconnect or exit-node rotation before any Flatpak cleanup. A healthy HEAD/TLS handshake is not enough; verify a full object GET.
    - If temporarily disconnecting VPN fixes the exact Flathub object fetch and `flatpak update --appstream -v`, classify the incident as a VPN/CDN path issue and restore the VPN afterward.
    - Prefer at least two retry attempts for unattended login-triggered update sweeps so a brief remote hiccup does not leave the day unstamped.

- For login-triggered verification, test the wrapper in an isolated state directory.
  - Run with a temporary `XDG_STATE_HOME` and inspect whether `last-run-date` is written only on success.
  - Set `AUTO_REBOOT=0` during verification so you can exercise the real wrapper path without risking a live reboot.
  - On success, verify the temp `latest.log` contains the expected phase-complete lines and the temp stamp file contains today’s date.
  - On failure, verify the wrapper exits non-zero and the stamp is absent so the same day remains retryable.

- Flatpak or D-Bus failures during privileged system Flatpak updates should not be mislabeled as sudo failures.
  - Keep stderr capture and classification narrow so environment/runtime errors remain visible as their own class.

- Toolbox entry is better done with `toolbox run --container <name> ...` in automation.
  - Do not rely on an interactive `toolbox enter` flow inside cron or a systemd service.

- For reboot detection, do not assume `rpm-ostree upgrade` output alone is enough.

- When wrapping commands for logging in shell, capture the command exit status immediately after the command returns and before any `if`/logging branch mutates `$?`.
  - A common bug is to run `if cmd; then ...; fi` and then record `$?`; by then the status may already be from the conditional branch rather than `cmd`, producing false `exit code 0` failure logs.

- For login-triggered verification, test the wrapper in an isolated state directory.
  - Run with a temporary `XDG_STATE_HOME` and inspect whether `last-run-date` is written only on success.
  - On failure, verify the wrapper exits non-zero and the stamp is absent so the same day remains retryable.

- Flatpak or D-Bus failures during privileged system Flatpak updates should not be mislabeled as sudo failures.
  - Keep stderr capture and classification narrow so environment/runtime errors remain visible as their own class.

- Toolbox entry is better done with `toolbox run --container <name> ...` in automation.
  - Do not rely on an interactive `toolbox enter` flow inside cron or a systemd service.

- For reboot detection, do not assume `rpm-ostree upgrade` output alone is enough.
  - Read `rpm-ostree status --json` and compare booted/non-booted deployment checksums or detect a staged/pending deployment.
  - During verification, disable the final reboot with an env var and confirm only the detection path.

- GNOME Software can mislead on Silverblue by collapsing layered RPM updates into a generic "system updates" or restart prompt.
  - If `rpm-ostree status` shows `AvailableUpdate` but `status --json` reports `cached-update.ref-has-new-commit = false`, the pending work may be only layered RPM packages rather than a new Silverblue base image.
  - Check `cached-update.rpm-diff` to see the exact package names before blaming Flatpak, PackageKit, or a stuck offline update.
  - If manual `rpm-ostree upgrade` + reboot clears the update but GNOME Software still shows it, clear only GNOME Software user cache/state (`~/.cache/gnome-software`, `~/.local/state/gnome-software`, `~/.local/share/gnome-software`) and re-test before attempting broader cleanup.
  - Prefer moving those directories to timestamped `.bak-<ts>` paths instead of deleting them immediately, then refresh appstream metadata and relaunch GNOME Software. This keeps the reset reversible while forcing fresh cache rebuilds.
  - If `rpm-ostree status --json` still shows `cached-update` after `rpm-ostree upgrade` reports `No upgrade available`, verify whether `cached-update.checksum` already matches the booted deployment checksum. If it does and `ref-has-new-commit = false`, treat the remaining badge as stale metadata/UI state before escalating to host cleanup.
  - On non-GNOME sessions such as Hyprland, treat GNOME Software's restart/apply path as less trustworthy than direct `rpm-ostree upgrade` verification when diagnosing repeat prompts.

## Verification checklist

- If using cron:
  - cron list shows either the pre-existing job or the newly created one
  - script path in the job is relative to `~/.hermes/scripts/`

- If using login-triggered systemd:
  - service exists under `~/.config/systemd/user/`
  - `systemctl --user is-enabled <service>` reports `enabled`
  - state directory contains the daily stamp after a run
  - second wrapper invocation the same day does not append new log output

- In all cases:
  - script exists under `~/.hermes/scripts/`
  - direct script or wrapper run finishes without hanging
  - if login-triggered automation already existed, read the stamp file and latest log to confirm whether it already ran today
  - final report distinguishes:
    - completed updates
    - skipped privileged phases
    - missing toolbox containers
    - whether reboot was required, suppressed for test, or actually invoked

## Response pattern

Tell the user:
- whether a matching cron already existed
- the created or existing job name and schedule
- the script path
- whether unattended privileged steps are currently possible
- what needs to change, if anything, for full automation

## Support files

- `references/hermes-maintenance-pass.md` — workspace convention for folding Hermes update into the same Silverblue maintenance sweep as rpm-ostree, Flatpak, and `snf`.
- `references/silverblue-daily-update-script.md` — sample script pattern and explanation for the host/Flatpak/toolbox split.
- `references/command-scoped-sudoers.md` — minimal sudoers patterns and verification steps for command-specific unattended host/toolbox updates.
- `references/login-triggered-silverblue-updates.md` — audit/readback checklist for existing login-triggered services, state stamps, latest logs, and rollback/reboot follow-up.
- `references/update-failure-triage.md` — quick triage patterns for misleading sudo errors, manual `rpm-ostree` layering evidence in journals, and deciding when Flatpak warnings are transient versus cleanup-worthy.
- `references/gnome-software-layered-update-mismatch.md` — how to distinguish a real Silverblue base update from layered RPM-only updates when GNOME Software shows a generic system-update/restart prompt.
- `references/gnome-software-stale-badge-remediation.md` — reversible cache/state reset and verification flow when GNOME Software still shows a system-update badge even though `rpm-ostree upgrade` and `flatpak update` are clean.
- `references/flatpak-timeout-retry-pattern.md` — durable retry/verification pattern for login-triggered Silverblue update flows when Flathub fetches fail with curl-style timeout strings.
- `references/flatpak-vpn-cdn-ssl-eof-recovery.md` — distinguish local Flatpak problems from VPN/CDN path failures when Flathub object downloads die with SSL EOF/connect errors and recover after VPN reconnect.
- `references/flatpak-transfer-error-verification.md` — targeted verification flow for distinguishing stale `No such ref` noise from the real failing Flatpak object fetch and for validating retry classification changes against the wrapper log.
