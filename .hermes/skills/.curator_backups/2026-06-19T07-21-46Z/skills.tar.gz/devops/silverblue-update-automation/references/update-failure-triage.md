# Update Failure Triage

Use this when a Silverblue login-triggered updater appears to have "skipped" work or when logs seem to blame sudo for everything.

## 1) Do not trust exit code 1 by itself

For privileged steps (`rpm-ostree`, system Flatpak, toolbox `dnf`), capture stderr and classify the failure:

- sudo/auth issue:
  - `a password is required`
  - `not allowed to run sudo`
  - other explicit sudo policy text
- real command failure:
  - DNS resolution failure
  - mirrorlist/repo fetch failure
  - missing Flatpak ref in remote
  - rpm-ostree transaction/repo error

If stderr names the real failure, log that instead of a generic "passwordless sudo is not configured" message.

## 2) Separate unattended update runs from manual rpm-ostree deployments

When the user asks why a deployment happened "today" or "automatically":

1. inspect `journalctl` around the deployment timestamp
2. search for `sudo`, `rpm-ostree`, and the relevant session scope
3. look for audit lines containing:
   - `COMMAND=/usr/sbin/rpm-ostree install ...`
   - `COMMAND=/usr/sbin/rpm-ostree upgrade ...`

If those appear under the user's session, treat the deployment as manual/interactice unless other evidence says otherwise.

Important: a failed login-triggered `rpm-ostree upgrade` can happen earlier in the day, and a later manual `rpm-ostree install` can still create the deployment the user notices. Explain both events separately.

## 3) Flatpak warnings: verify before cleaning

Warnings like:
- `No such ref ... in remote flathub`
- `Treating remote fetch error as non-fatal ...`

do not automatically mean the installed refs are stale.

Check current state first:
- `flatpak repair --system --dry-run -v`
- `flatpak update --system`
- `flatpak remote-info --system <remote> <ref>` for spot checks

If those checks are clean, avoid deleting refs just to silence an old warning. Treat the earlier warning as transient remote/metadata state unless current evidence shows a persistent break.

## 4) Flathub object download dies mid-stream: prove network/CDN before "fixing" Flatpak

When `flatpak update` fails on a specific Flathub object with messages such as:
- `[56] Failure when receiving data from the peer`
- `OpenSSL SSL_read ... unexpected eof while reading`
- `Failed to read 102400 bytes ... errno=11` from `wget`

triage it as a transport-path problem first, not repo corruption.

Use this sequence:
1. re-run the failing ref directly, e.g. `flatpak update -y org.telegram.desktop`
2. run `flatpak repair --dry-run` to check for local installation corruption
3. fetch the exact failing object URL outside Flatpak with `curl -L --output /dev/null ...`
4. if needed, retry with `curl -4` and `curl -6` separately to see whether one address family is worse
5. optionally try `wget -c` to confirm repeated partial transfers rather than metadata failure

Interpretation:
- if `flatpak repair --dry-run` is clean and raw `curl`/`wget` also die on the same object, do not remove/reinstall the app as a first step
- classify the issue as upstream/network/CDN path instability for that object
- report which apps already updated successfully so the user knows the Flatpak installation itself is healthy
- recommend later retry, different network path, or VPN toggle rather than destructive cleanup
