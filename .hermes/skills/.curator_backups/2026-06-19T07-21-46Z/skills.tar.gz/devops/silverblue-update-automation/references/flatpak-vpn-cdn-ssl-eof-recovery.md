# Flatpak VPN/CDN SSL EOF recovery

Use this when `flatpak update` or `flatpak update --appstream` fails against Flathub with curl/TLS transport errors such as:

- `[35] SSL connect error`
- `OpenSSL SSL_read: ... unexpected eof while reading`
- mid-transfer TLS EOFs on `dl.flathub.org`

## What this usually means

When `flatpak repair --dry-run` is clean and the same Flathub object succeeds after a VPN reconnect or with the VPN disabled, the durable lesson is not "Flatpak is broken" or "clear caches". The more likely cause is a bad path between the current VPN exit node and the Flathub/Fastly CDN.

## Verification pattern

1. Reproduce with `flatpak update --appstream -v` or `flatpak update -v` and note the exact failing object URL.
2. Test the exact object URL with raw `curl`.
   - If HEAD succeeds but a full GET fails with `SSL_read ... unexpected eof while reading`, treat it as a path/transfer issue, not a CA-store issue.
3. Run `flatpak repair --dry-run`.
   - If clean, avoid destructive cleanup.
4. Retry the same object fetch off-VPN or after reconnecting the VPN.
5. If the object fetch then succeeds, retry `flatpak update --appstream -v` and finally `flatpak update -y`.

## Preferred fix order

1. Reconnect the VPN.
2. If the VPN client chooses a new endpoint/profile name, verify the new tunnel is active before retrying Flatpak.
3. If reconnecting is insufficient, switch VPN server/exit node.
4. As a diagnostic only, test once without VPN.
5. Only consider Flatpak cleanup if raw downloads still fail off-VPN and `flatpak repair` shows a real issue.

## Important pitfalls

- Do not jump straight to clearing Flatpak caches or reinstalling remotes when the failing URL itself becomes healthy after a VPN reconnect.
- A successful TLS handshake/HEAD request does not rule out a mid-stream VPN/CDN transport problem; verify a full object download.
- Some VPN clients recreate the connection with a new profile name after reconnect. Do not assume the old NetworkManager connection name still exists.
- Capture the exact transfer error string; `[35] SSL connect error` from Flatpak may correspond to `unexpected eof while reading` in raw curl output.

## Good final verification

- `flatpak update --appstream -v` completes without the Flathub fetch error
- `flatpak update -y` succeeds or reports `Nothing to update.`
- VPN is reconnected if it was temporarily disabled during diagnosis
