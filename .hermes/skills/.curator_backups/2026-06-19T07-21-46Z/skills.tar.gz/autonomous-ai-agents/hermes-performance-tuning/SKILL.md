---
name: hermes-performance-tuning
description: Tune Hermes for lower latency and lower local CPU/RAM pressure without swinging hard on capability or token spend.
---

# Hermes performance tuning

Use this when Hermes feels slow, CPU-heavy, RAM-heavy, or unusually expensive, and the goal is a conservative optimization pass rather than a radical reconfiguration.

## When to use
- Recent Hermes sessions feel slower than usual.
- Local Ollama / auxiliary model processes are consuming too much CPU or RAM.
- Compression or memory-related background work appears frequently in logs.
- The user wants Hermes a bit faster or lighter, but does not want aggressive cost-cutting or capability loss.

## Goals
1. Reduce local resource pressure first.
2. Avoid increasing token spend unless the user explicitly wants that tradeoff.
3. Prefer reversible config changes.
4. Verify with live config/status output, not guesses.

## Core workflow
1. Inspect current Hermes config and recent logs/status.
   - Check model, auxiliary models, compression settings, resume display, and config version.
   - Look for repeated compression activity, large-context turns, or background memory churn.
2. Identify whether the main cost is:
   - main model latency,
   - auxiliary local model weight,
   - compression frequency,
   - resume/context bloat,
   - or background memory/dashboard activity.
3. Apply conservative changes first:
   - migrate config if outdated;
   - keep the main model unchanged unless the user asked for more aggressive speed/cost tuning;
   - move auxiliary local tasks to a smaller local model if it still has enough context for the job;
   - slightly raise compression threshold to avoid compressing too eagerly;
   - reduce resume verbosity so resumed sessions inject less context by default.
4. Re-run config validation and confirm the exact keys changed.
5. Report tradeoffs plainly.

## Conservative tuning defaults
Use these before considering anything more aggressive:

### 1) Migrate config first
If `hermes config check` shows an outdated config version, run migration before tuning so you are not optimizing stale structure.

### 2) Prefer a smaller local auxiliary model
If auxiliary tasks are on a heavier local Ollama model and a smaller installed local model has enough context, switch auxiliary workloads first.

Good candidates for downshifting:
- compression
- title_generation
- triage_specifier
- profile_describer
- curator

Do this before changing the main model, because auxiliary jobs can generate steady background load.

### 3) Raise compression threshold modestly
If Hermes is compressing often, increase the threshold a little rather than disabling compression.

Default conservative move:
- `compression.threshold`: `0.5 -> 0.6`

Reason: fewer compression passes, less local summarization work, small increase in average prompt size, usually still within a sensible token budget.

### 4) Reduce resume payload
Prefer more compact resume behavior for CLI use when the user wants lower overhead.

Default conservative move:
- `display.resume_display = compact`
- `display.resume_exchanges = 6`

Reason: resumed sessions start with less injected transcript while preserving short continuity.

### 5) Prune unused skills from autoload eligibility
If the user wants Hermes to load less support material by default, audit skill usage and disable skills that have not been used recently, especially newly added update-era skills that have never been touched.

Conservative workflow:
1. Review `~/.hermes/skills/.usage.json`.
2. Compare it against `skills.disabled` in `~/.hermes/config.yaml`.
3. Add skills with no recent `last_used_at` (for example, 14+ days) or no `last_used_at` at all.
4. Verify the config still stores `skills.disabled` as a real YAML list, not a quoted JSON string.

Why this helps:
- reduces candidate skill surface for automatic loading;
- keeps newly introduced bundled/hub skills from adding noise before the user actually needs them;
- is reversible and low-risk.

## Decision rules
- Do not change the main model unless the user wants a stronger speed/cost tradeoff.
- Do not disable memory providers or dashboard processes as a first step unless evidence shows they are the dominant problem and the user is okay with feature reduction.
- Do not over-optimize by stacking many speculative tweaks at once; keep the pass attributable and reversible.

## Verification
Always verify all of the following:
- config version after migration
- exact tuned keys in config
- that chosen auxiliary model is actually installed / available
- if relevant, that the smaller local model still has adequate context length for the auxiliary job

## Diagnosing "Hermes is idle but CPU is hot"
When the user reports high CPU or temperature even though they only see the Hermes terminal open, do not assume the visible CLI process is the real source. Check for Hermes-triggered local auxiliary workloads first.

Recommended workflow:
1. Inspect live top CPU consumers and process trees.
2. If `ollama` or another local model runner is dominant, identify the exact model process.
3. Check Hermes auxiliary routing in `~/.hermes/config.yaml`, especially:
   - `auxiliary.title_generation`
   - `auxiliary.triage_specifier`
   - `auxiliary.profile_describer`
   - `auxiliary.curator`
   - `auxiliary.summarization`
   - `auxiliary.compression`
4. Correlate with recent Hermes logs for auxiliary calls, retries, and fallbacks.
5. If the hotspot is low-value auxiliary work on a local model, reroute those auxiliary tasks to a lightweight remote/main mini model before changing the main agent model.

Important pattern:
- A remote main model does NOT guarantee low local CPU.
- Local auxiliary tasks like title generation can still spin up Ollama in the background and dominate CPU/RAM.
- Repeated timeout/retry/fallback cycles on a small local model can create heat and noise even when the user thinks Hermes is "doing nothing."

Conservative fix pattern:
- Move background-style auxiliary tasks from local Ollama to `main` with a small remote model such as `gpt-5.4-mini`.
- Verify the changed keys after editing.
- Remind the user that an already-running local model process may continue until the in-flight request ends or the process is stopped; config changes mainly affect new sessions / new auxiliary calls.

## Pitfalls
- A very large main-model context can trigger repeated compression and long turns even when the model itself is fine; check logs before blaming only the provider.
- Heavy local auxiliary models can dominate CPU/RAM even when the main model is remote.
- Lowering capability too far on auxiliary tasks can save RAM but degrade summaries/titles; choose the smallest model that still fits the job.
- A smaller local model can still be the wrong compression model if large-summary prompts routinely hit its timeout window. If logs show repeated `Auxiliary compression ... Request timed out` on Ollama followed by failed context summaries, move compression to a more reliable remote mini model and disable `compression.abort_on_summary_failure` so Hermes degrades gracefully instead of surfacing repeated abort messages.
- Hermes Hindsight local_embedded config is two-part: `~/.hermes/hindsight/config.json` stores the provider/model choice, and `~/.hindsight/profiles/<profile>.env` is the daemon env that Hindsight actually launches with. When changing Hindsight away from local Ollama, update both and verify the live daemon env instead of assuming the JSON alone is authoritative.
- Changing persisted Hindsight config does not necessarily retune the already-running Hermes process. A live Hermes parent can keep launching `hindsight-api` with the old in-memory env/provider until Hermes itself is restarted. After editing Hindsight config, inspect the live daemon environment and connections; if it still shows the old provider, plan for a Hermes restart before declaring the switch complete.
- `hermes config set skills.disabled ...` may serialize the disabled-skill list as a quoted JSON string instead of a YAML sequence. If that happens, normalize `skills.disabled` back to a proper YAML list before finishing, then verify the parsed type.
- Do not encode transient setup failures as durable rules.

## Hindsight-specific local heat diagnosis
If the hotspot is `ollama runner` but the main Hermes model is remote, check whether the Hindsight memory provider is the real caller before blaming auxiliary summarization or the visible CLI turn.

Workflow:
1. Confirm `memory.provider: hindsight` in Hermes config/status.
2. Inspect Hindsight persisted config in `~/.hermes/hindsight/config.json` for `mode`, `llm_provider`, and `llm_model`.
3. Inspect `~/.hindsight/profiles/<profile>.env` because local_embedded Hindsight launches from this env file.
4. Check the live `hindsight-api` process environment for `HINDSIGHT_API_LLM_PROVIDER` / `HINDSIGHT_API_LLM_MODEL`.
5. Verify with live evidence: active TCP connections to `127.0.0.1:11434`, metrics labels showing provider/model, or a spawned `ollama runner` process.
6. If reconfiguring to a remote provider, verify support in Hindsight itself, not just Hermes. `openai-codex` is a valid Hindsight provider and maps to `CodexLLM` with default model `gpt-5.4-mini`.
7. After changing config, restart Hermes if the live daemon still inherits old values from the current parent process.

## References
- `references/conservative-local-first-tuning.md` — concrete tuning pattern for local-first Hermes setups with heavy auxiliary Ollama load.
- `references/latency-aware-routing.md` — conservative model-routing adjustments for lower perceived latency without large token-spend increases.
- `references/delegation-escalation.md` — when to put a stronger model on delegation instead of the main session or fallback chain.
- `references/hindsight-local-heat-and-provider-switch.md` — Hindsight-specific diagnosis and reconfiguration notes for moving local_embedded memory off Ollama.

## Latency-aware routing without over-spending
Hermes may not expose a true built-in policy of "switch models mid-task when latency crosses X seconds." For that class of request, use a conservative approximation instead of inventing a nonexistent knob.

Recommended order:
1. Lower default reasoning effort before changing the primary model.
   - Good conservative move: `agent.reasoning_effort = low`
   - Effect: lower average latency and token use on normal turns, with less capability loss than swapping the main model immediately.
2. Reduce retry drag on slow/flaky upstream calls.
   - Good conservative move: `agent.api_max_retries = 1`
   - Effect: Hermes spends less time repeating a slow failing request before surfacing or falling through.
3. Put fast remote fallbacks ahead of heavy local models.
   - If the primary is remote and the first fallback is a heavy local Ollama model, that fallback can worsen perceived slowness by adding local CPU/RAM pressure exactly when the session is already degraded.
   - Prefer a fallback chain such as remote `gpt-5.4-mini` / `gpt-5.3-codex` before a local `qwen3:8b`-class model when the user's goal is responsiveness rather than offline resilience.
4. Keep the main model unchanged unless the user explicitly wants a stronger speed/cost tradeoff.

## Verification for latency-aware tuning
When making the above changes, verify:
- `agent.reasoning_effort`
- `agent.api_max_retries`
- the current fallback chain as actually parsed by Hermes
- recent logs for whether the slower path was retries, large-context latency, or local fallback activation

## Escalation options
Only after the conservative pass, consider:
- switching the default main model to a faster/cheaper sibling (for example a `-mini` class model), or
- trimming/pausing background dashboard or memory activity if logs show it is the sustained hotspot and the user accepts the feature tradeoff.

## Complex-work escalation without slowing the main session
When the user wants stronger handling for rare hard tasks but does not want everyday Hermes turns to get slower or more expensive, prefer delegation-level escalation over changing the primary model or fallback chain.

Recommended order:
1. Keep the main session on the user's normal model.
2. Verify the stronger model/provider is actually usable with a tiny one-shot Hermes call before wiring it into config.
3. Set `delegation.provider` and `delegation.model` to the stronger model.
4. Keep `delegation.reasoning_effort` conservative (`low` is a good default) unless the user explicitly wants max-depth reasoning.
5. If the user is spend-sensitive, reduce `delegation.max_concurrent_children` (for example `3 -> 2`) to cap burst token spend during multi-branch delegation.

Why this is usually better than fallback escalation:
- fallback is failure-based, not complexity-based;
- putting a heavier model into fallback does not mean Hermes will choose it for hard tasks, only that it may try it after errors/rate limits;
- delegation lets only the hard subtask pay the stronger-model cost while the parent session stays faster.

Verification and rollout notes:
- confirm the model works with a real one-shot query before saving the config;
- verify `delegation.provider`, `delegation.model`, `delegation.reasoning_effort`, and `delegation.max_concurrent_children` after changes;
- remind the user that delegation settings may be snapshotted by the running Hermes session/process, so a fresh CLI session or gateway restart may be needed before subagents actually use the new model.

## References
- `references/conservative-local-first-tuning.md` — concrete tuning pattern for local-first Hermes setups with heavy auxiliary Ollama load.
- `references/latency-aware-routing.md` — conservative model-routing adjustments for lower perceived latency without large token-spend increases.
- `references/delegation-escalation.md` — when to put a stronger model on delegation instead of the main session or fallback chain.
