---
name: research-briefing
description: Broad current-events and trend briefing skill covering news synthesis, blindspot scanning, and live source coverage setup.
version: 1.0.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  tags: [research, briefing, news, trends, live-search, blindspots, source-coverage]
---

# Research Briefing

Use this when the user wants a current, synthesized briefing rather than a raw search dump: latest developments, topic monitoring, trend scanning, or a "what am I missing?" pass across multiple domains.

## Core idea
A good briefing has three layers:
1. enough live source coverage to trust the run
2. narrow category query packs instead of one huge search
3. synthesis that highlights the dominant signal, not the top ranked noise

## When to use
- User wants the latest developments across one or more topics.
- User wants a live trend or current-events briefing.
- User wants blindspots or adjacent signals.
- User wants to improve source coverage for a research workflow.

## Workflow

### 1) Verify coverage before synthesis
- Identify what sources are actually available.
- Separate "the tool exists" from "the tool has enough live source coverage."
- If a source is missing, use a compact fallback instead of pretending it is covered.

### 2) Split into narrow query packs
- Build separate probes per topic/category.
- Keep categories distinct: politics, macro/finance, geopolitics, tech/AI, culture, autos, GitHub, etc.
- Avoid an omnibus query unless you explicitly want broad noise.

### 3) Add blindspot scanning
- Surface adjacent items that are popular or important but not centered in the main ranking.
- Treat blindspots as secondary signals, not the main conclusion.
- Use a second pass when the first pass is too narrow or too noisy.

### 4) Synthesize by topic
- State the main development first.
- Then give 2–4 supporting bullets.
- Call out weak or noisy buckets instead of padding them.
- Keep the output concise and readable.

### 5) Include setup improvements when needed
- If the workflow is source-limited, improve the search/extract/auth stack before blaming the briefing logic.
- Distinguish a general live-news workflow from source-specific signals such as GitHub trends or account-derived personalization.
- When the user wants recurring briefings, preserve their established output shape rather than inventing a new one each time.

## Practical rules
- Do not claim comprehensive coverage when the source mix is thin.
- Do not pad a briefing with irrelevant recent items.
- Do not merge blindspots into the main ranked story.
- Do not confuse search success with good coverage.
- Do not forget to label caveats plainly when a source path is missing.

## Verification
- Live sources were checked.
- Query packs were narrowed by topic.
- Briefing output is synthesized, not dumped raw.
- Blindspots or weak buckets are labeled honestly.

## Evaluating external source stacks
Use this when the user asks whether a new retrieval/integration layer would improve news, recommendations, or research coverage.

- Compare the proposed stack against the current local stack before recommending installation.
- Separate access-layer gains from reasoning gains: better source reach can improve inputs without improving synthesis quality by itself.
- Distinguish discussion-layer value from structured-metadata value. Social/community sources can improve sentiment, buzz, and recommendations even when they do not improve canonical metadata lookup.
- Prefer a low-risk trial first: isolated venv or other reversible install path, plus dry-run/status commands before any real setup.
- Check for hidden side effects in verification commands. If an upstream `doctor` or `setup` command writes skills/config automatically, prefer the least side-effecting variant during evaluation.
- Report current gaps in the existing stack separately from the proposed tool's strengths. Sometimes the fastest win is fixing the current extract/search configuration rather than adding a second stack.
- When judging fit for recurring briefings, prioritize source coverage, auth burden, and reversibility over feature-list breadth.
- See `references/external-source-stack-evaluation.md` for a concrete comparison pattern and low-risk trial checklist.

## Fast-briefing fallback rules
When the user asks for a quick news update and the environment has thin extraction coverage:
- Try live search first across a few narrow topic buckets rather than blocking on full-page extraction.
- If a bucket returns stale, generic, or weakly-related results, immediately rerun that bucket with explicit date terms and trusted-source constraints instead of accepting noisy rankings.
- If URL extraction fails because the configured backend is search-only, fall back to search snippets and say so plainly.
- If high-value sources such as Reuters are bot-blocked in the browser, use corroborating search results from Reuters/AP/other mainstream sources instead of pretending you read the full article.
- Stamp the briefing with the current local time and clearly separate "24h signal", "7-day trend", and "weak/noisy buckets".
- When personalization is useful and local browser history is available, add a small separate "personalized signal" section rather than contaminating the main public-news ranking.
- If browser-history signal is mostly entertainment or general browsing rather than news consumption, say that plainly and keep it as lightweight context rather than forcing it into the main briefing.

## Notes
More specific workflows that fit under this umbrella include recent-news briefings, signal-oriented briefings, and live research source-coverage setup.
