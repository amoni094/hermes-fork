---
name: agent-reach-discovery
description: Use locally installed Agent Reach as a sidecar for news, social/community, movie, and music discovery workflows in Hermes.
version: 1.0.0
license: MIT
platforms: [linux]
metadata:
  tags: [research, news, movies, music, social, retrieval, hermes, agent-reach]
---

# Agent Reach discovery

Use this when Hermes needs broader internet reach for news, sentiment, community discussion, or recommendation discovery and a plain web search is not enough.

## When to use
- The user wants richer news/source coverage than generic web search snippets.
- The user wants Reddit/X/Bilibili/Xiaohongshu/community signal.
- The user wants movie or music discovery via reviews, discussion, buzz, or recommendation threads.
- Hermes `web_extract` is unavailable or weak and a sidecar retrieval path is needed.

## Local install verified here
- Wrapper command: `~/.local/bin/agent-reach`
- Venv: `~/.agent-reach-venv`
- Config/data dir: `~/.agent-reach/`
- Upstream auto-installed skill dir: `~/.agents/skills/agent-reach`

## Important local caveat
In this Hermes profile, `web_search` works with SearXNG but `web_extract` is not restorable by config alone unless an extract-capable backend credential is actually configured. Attempting `web.extract_backend=firecrawl` without a real Firecrawl/Exa/Parallel/Tavily credential does not fix the problem. Keep this separate from Agent Reach.

## Safe verification workflow
1. Check version:
   - `~/.local/bin/agent-reach version`
2. Run safe install/status pass:
   - `~/.local/bin/agent-reach install --env=auto --safe`
3. Get machine-readable status:
   - `~/.local/bin/agent-reach doctor --json`
4. Prefer `doctor --json` over plain `doctor` during audits to reduce surprise side effects.

## What was available in this environment when verified
Zero/low-config working:
- GitHub
- Web via Jina Reader
- RSS
- V2EX
- Bilibili basic search
- Exa semantic search via mcporter (`mcporter config add exa https://mcp.exa.ai/mcp` verified by `agent-reach doctor --json`)

Installed but still requiring manual auth/browser completion:
- Twitter/X via `twitter-cli` (installed, but still needs X cookies/login)
- Reddit via `rdt-cli` and/or OpenCLI (installed, but still needs logged-in browser state or extension)
- Xiaohongshu via OpenCLI (package installed, but Chrome extension still needs to be connected)

Also verified working after follow-up setup:
- YouTube via yt-dlp after adding `--js-runtimes node` to `~/.config/yt-dlp/config`

Still off:
- LinkedIn full access
- Xueqiu
- Xiaoyuzhou transcription

## Local pitfalls discovered during verification
- OpenCLI package installation is automatable, but browser extension connection is still manual.
- On this Fedora Silverblue machine, Firefox runs from Flatpak and Agent Reach's browser-cookie import did not find the Firefox profile automatically, so `agent-reach configure --from-browser firefox` was not enough here.
- Practical workaround: use the Flatpak Firefox cookie DB directly with `browser_cookie3.firefox(cookie_file=...)` against `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/<profile>/cookies.sqlite`, then write any discovered tokens into Agent Reach config. This successfully recovered Twitter/X cookies from Firefox in this environment even though the built-in auto-detect failed.
- Local patch verified: `~/.agent-reach-venv/lib/python3.13/site-packages/agent_reach/cookie_extract.py` can be patched to auto-detect Flatpak Firefox cookie DBs, after which `agent-reach configure --from-browser firefox` succeeds again.
- Because of that Firefox-profile limitation, cookie-backed channels should currently be treated as installed-but-not-authenticated until Chrome/OpenCLI or manual cookie configuration is completed.

Reference: `references/firefox-flatpak-cookie-import.md`

## How to use it in practice
### News / live topics
- Use Hermes `web_search` first for a broad scan.
- Use Agent Reach when you need community/native-platform coverage or Jina-style readable page fetches.
- Treat Agent Reach as an access layer, not a reasoning upgrade.

### Movies and music
- Use Agent Reach for discussion-layer discovery:
  - reviews
  - Reddit threads
  - YouTube reactions/explainers
  - social buzz
- Do not treat Agent Reach as canonical metadata. For release dates, credits, runtimes, discographies, and structured catalog facts, use dedicated metadata sources when available.

### Recommended command pattern
- Version/status:
  - `~/.local/bin/agent-reach version`
  - `~/.local/bin/agent-reach doctor --json`
- Safe re-check:
  - `~/.local/bin/agent-reach install --env=auto --safe`
- Optional channel install preview:
  - `~/.local/bin/agent-reach install --env=auto --dry-run --channels=twitter,reddit,xiaohongshu`

## Optional follow-up channels
Only install these when the user wants them and accepts the auth/config burden:
- Twitter/X
- Reddit
- Xiaohongshu
- LinkedIn
- Xueqiu
- Xiaoyuzhou
- Exa via mcporter

## Verification rules
- Do not claim a channel works because Agent Reach supports it in docs.
- Always verify with `doctor --json` after install or config changes.
- Distinguish `ok`, `warn`, and `off` in the final report.
- If a channel needs cookies/login/browser state, say so plainly.

## Output expectations
Report:
- what Agent Reach adds beyond Hermes alone
- which channels are actually working on this machine now
- which channels are merely supported upstream but still off here
- whether the user’s goal is better served by fixing Hermes config first or by enabling additional Agent Reach channels
