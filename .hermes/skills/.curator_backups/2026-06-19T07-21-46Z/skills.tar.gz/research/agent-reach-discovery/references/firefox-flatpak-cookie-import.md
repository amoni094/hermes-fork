# Firefox Flatpak cookie import for Agent Reach

Use when `agent-reach configure --from-browser firefox` finds nothing on Fedora Silverblue or other Flatpak-Firefox setups.

Verified local path pattern:
- `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/profiles.ini`
- `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/<profile>/cookies.sqlite`

Observed result in this environment:
- Direct read of `cookies.sqlite` via `browser_cookie3.firefox(cookie_file=...)` succeeded.
- Twitter/X cookies were present and usable.
- Reddit cookies were present in Firefox.
- Bilibili, Xiaohongshu, and Xueqiu cookies were not present in the tested profile.

Minimal workaround pattern:
1. Locate the active Firefox Flatpak profile under `~/.var/app/org.mozilla.firefox/config/mozilla/firefox/`.
2. Point `browser_cookie3.firefox(cookie_file=...)` at that profile's `cookies.sqlite`.
3. Extract platform-specific cookies:
   - Twitter/X: `auth_token`, `ct0`
   - Bilibili: `SESSDATA`, `bili_jct`
   - Xueqiu/Xiaohongshu: full cookie string if needed
4. Write the recovered values into `~/.agent-reach/config.yaml` using Agent Reach's config keys.
5. Re-run `agent-reach doctor --json` to verify channel status.

Why this matters:
- Agent Reach's built-in browser autodetect can miss Flatpak Firefox profiles.
- The direct `cookie_file=` path is a durable workaround for Firefox-first users who do not want a Chrome/OpenCLI path for cookie-based channels.

Limits:
- This does not make OpenCLI Firefox-native.
- It only helps channels that can work from imported cookies/config, not Chrome-extension-backed flows.
